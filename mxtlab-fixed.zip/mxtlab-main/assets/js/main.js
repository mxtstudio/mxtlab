/* ══════════════════════════════════════════
   DATA — from PNG Agriculture Teacher Guides
   ══════════════════════════════════════════ */

const LESSONS = {

/* ─── GRADE 9 STRAND 1: CROPS ─────────────────────────────── */

'g9-soil-formation': {
  title: 'Soil — Types & Formation',
  strand: 'Strand 1: Crops · Unit 1', grade: 9, icon: '🌱',
  lessons: ['Soil Composition & Components','Physical Properties of Soil','Chemical Properties of Soil','Soil Types Summary'],
  currentLesson: 0,
  objectives: [
    'Describe the different types of soil and how soil is formed',
    'Identify and describe the different components of soil',
    'Classify soils based on their physical and chemical characteristics'
  ],
  content: `
  <div class="lesson-section">
    <h2>What is Soil?</h2>
    <p>Soil is the thin layer of material covering the earth's surface that supports plant life. All soils are different because of where and how they formed. Basically, soil is formed by the weathering or breakdown of rock on the upper layers of the solid earth — and this very rock is called the <strong>parent material</strong>.</p>

    <div class="fact-grid">
      <div class="fact-box"><div class="fact-n">45%</div><div class="fact-l">Mineral matter</div></div>
      <div class="fact-box"><div class="fact-n">25%</div><div class="fact-l">Water</div></div>
      <div class="fact-box"><div class="fact-n">25%</div><div class="fact-l">Air</div></div>
      <div class="fact-box"><div class="fact-n">5%</div><div class="fact-l">Organic matter</div></div>
    </div>
  </div>
  <div class="lesson-section">
    <h2>The Five Factors That Form Soil</h2>
    <p>Five factors interact together to determine what type of soil forms in any location:</p>
    <ol>
      <li><strong>Living organisms</strong> — bacteria, fungi, earthworms, and plant roots all contribute organic material and speed up breakdown of rock</li>
      <li><strong>Climate</strong> — temperature and rainfall determine how fast weathering occurs and what types of minerals form</li>
      <li><strong>Parent material</strong> — the type of rock being broken down determines the mineral content of the soil</li>
      <li><strong>Time</strong> — the longer rock weathers, the more developed the soil becomes</li>
      <li><strong>Topography</strong> — the slope and position of land affects drainage and erosion</li>
    </ol>
  </div>
  <div class="lesson-section">
    <h2>How Weathering Breaks Down Rock</h2>
    <p>Weathering is the process by which rock is broken down into the particles that eventually become soil. It can be mechanical, chemical, or biological:</p>
    <ul>
      <li><strong>Moving water</strong> — streams and rivers move stones, rubbing them together. Small particles break off and eventually become soil particles</li>
      <li><strong>Heat and cold</strong> — rocks expand in heat and contract in cold. Repeated cycles crack and break them</li>
      <li><strong>Wind</strong> — in dry areas, wind blows sand against rock, wearing it down slowly</li>
      <li><strong>Carbon dioxide</strong> — in the air, CO₂ forms weak carbonic acid that can dissolve limestone and chalk rock</li>
    </ul>
    <div class="info-box"><strong>📌 Important:</strong> The activities of plants and animals also contribute to soil formation by adding organic materials as they die and decompose.</div>
  </div>
  <div class="lesson-section">
    <h2>Physical Properties of Soil</h2>
    <p>Physical properties are aspects of the soil that can be seen and touched. These include:</p>
    <h3>Soil Texture</h3>
    <p>Soil is made up of particles categorised into three groups by size: <strong>sand</strong> (largest), <strong>silt</strong> (medium), and <strong>clay</strong> (smallest). Most soils are a mixture of all three. The relative percentages give soil its texture. A soil texture triangle is used to classify the proportions.</p>
    <h3>Soil Structure</h3>
    <p>Individual particles of sand, silt, clay, and organic matter can cement together to form <strong>aggregates</strong> (also called peds). The way these aggregates are arranged gives soil its structure, which affects drainage and air movement.</p>
    <h3>Soil Colour</h3>
    <p>Soil colour is related to its chemical properties, drainage, and organic matter content. Dark soils are usually rich in organic matter. Red or orange soils contain iron oxides. Colour can indicate the different layers (horizons) of a soil profile.</p>
    <h3>Soil Porosity</h3>
    <p>Porosity refers to the spaces or pores between aggregates. These pores can be filled with air or water. The number, size, and shape of pores determines how much water the soil can hold and how quickly water drains through.</p>
  </div>
  <div class="lesson-section">
    <h2>Chemical Properties of Soil</h2>
    <p>The chemical properties of soil affect its ability to supply nutrients to plants. They also affect the activity of micro-organisms living in the soil.</p>
    <p>A key chemical property is <strong>soil pH</strong> — how acidic or alkaline the soil is. Most crops grow best in slightly acidic to neutral soils. If soil becomes too acidic or too alkaline, plants cannot absorb nutrients properly.</p>
    <p>Soils can also lose so many nutrients that they become <strong>lateritic</strong> and barren. Lateritic soils contain so much aluminium and iron that they are toxic to plants — even weeds struggle to grow in them.</p>
  </div>`,
  keyTerms: [
    {word:'Weathering', def:'The process of breaking down rock into smaller particles through physical, chemical, or biological action'},
    {word:'Parent material', def:'The original rock from which soil is formed'},
    {word:'Soil texture', def:'The proportion of sand, silt, and clay in a soil'},
    {word:'Aggregate (ped)', def:'A clump of soil particles held together by organic matter or chemical forces'},
    {word:'Porosity', def:'The spaces between soil particles that can hold air or water'},
    {word:'Lateritic soil', def:'A soil type containing high levels of iron and aluminium, often barren and infertile'},
  ],
  summary: [
    'Soil is formed by the weathering of rock (parent material) over time',
    'Five factors affect soil formation: living organisms, climate, parent material, time, and topography',
    'Soil is made up of mineral matter (45%), water (25%), air (25%), and organic matter (5%)',
    'Physical properties include texture (sand/silt/clay), structure, colour, and porosity',
    'Chemical properties include pH and nutrient content — these determine whether crops can grow'
  ],
  quiz: [
    {q:'What is the correct composition of soil by volume?', opts:['45% mineral, 25% water, 25% air, 5% organic','50% mineral, 25% water, 20% air, 5% organic','40% mineral, 30% water, 25% air, 5% organic','45% mineral, 30% water, 20% air, 5% organic'], ans:0},
    {q:'Which of the following is NOT one of the five factors that affect soil formation?', opts:['Climate','Topography','Rainfall alone','Living organisms'], ans:2},
    {q:'What are the three particle sizes in soil texture, from largest to smallest?', opts:['Sand, silt, clay','Clay, silt, sand','Silt, sand, clay','Sand, clay, silt'], ans:0},
    {q:'What is a lateritic soil?', opts:['A very dark soil rich in organic matter','A soil containing high iron and aluminium that is toxic to most plants','A clay-heavy soil that holds too much water','A sandy soil with poor nutrient content'], ans:1},
    {q:'Which weathering agent dissolves limestone and chalk rocks?', opts:['Moving water','Wind','Carbon dioxide forming carbonic acid','Heat and cold expansion'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/soils-portal/en/',label:'FAO Soils Portal',desc:'Global soil resources, soil health information, and soil management guidelines from the Food and Agriculture Organization.'},
    {url:'https://www.fao.org/soils-portal/soil-degradation-restoration/en/',label:'FAO Soil Degradation',desc:'How soils are degraded and how they can be restored — relevant to farming conditions in Papua New Guinea.'},
  ]
},

'g9-types-crops': {
  title: 'Types of Crops & Their Environments',
  strand: 'Strand 1: Crops · Unit 2', grade: 9, icon: '🌽',
  lessons: ['Types of Crops by Use','Environmental Requirements','Crop Characteristics & Life Cycle'],
  currentLesson: 0,
  objectives: [
    'Identify the different types of crops grown in Papua New Guinea',
    'Examine the environmental requirements of different crops',
    'Classify crops by life span and temperature requirements'
  ],
  content: `
  <div class="lesson-section">
    <h2>Classification of Crops by Use</h2>
    <p>Crops can be grouped by what they are used for. There are six main categories:</p>
    <ul>
      <li><strong>Food crops</strong> — grown for human consumption. Examples: wheat, maize, rice, sweet potato, taro, cassava, tomatoes</li>
      <li><strong>Feed crops</strong> — grown for livestock consumption. Examples: barley, beets, grasses stored as hay or silage</li>
      <li><strong>Fibre crops</strong> — grown for fibres used in clothing, bedding, and industry. Examples: cotton, hemp, flax, bamboo</li>
      <li><strong>Oil crops</strong> — grown for oil manufacturing. Examples: oil palm, coconut, sunflower, olives, canola</li>
      <li><strong>Ornamental crops</strong> — grown for decoration and landscape design. Examples: flowers, garden bushes, pot plants</li>
      <li><strong>Industrial crops</strong> — grown for industrial manufacturing. Examples: rubber, sugar cane, tobacco</li>
    </ul>
    <div class="info-box"><strong>🇵🇬 PNG Context:</strong> Papua New Guinea\'s key food crops include sweet potato, banana, taro, cassava, and yam. Important cash crops include coffee, cocoa, oil palm, copra, and rubber.</div>
  </div>
  <div class="lesson-section">
    <h2>Environmental Requirements of Crops</h2>
    <p>Different crops need different conditions to grow well. The main environmental factors that affect crop growth are:</p>
    <h3>Temperature</h3>
    <p>Crops can be divided into <strong>cool-season crops</strong> (prefer temperatures below 20°C — e.g. peas, lettuce, cabbage) and <strong>warm-season crops</strong> (prefer temperatures above 20°C — e.g. tomatoes, pepper, beans, maize).</p>
    <h3>Rainfall and Water</h3>
    <p>Different crops need different amounts of water. Rice needs flooded fields; drought-resistant crops like sorghum can grow in dry conditions. Most food crops need consistent moisture during their growing period.</p>
    <h3>Soil Type</h3>
    <p>Root crops like sweet potato and cassava grow best in loose, well-drained soils. Rice grows in waterlogged conditions. Most vegetable crops prefer fertile, loamy soils.</p>
    <h3>Altitude</h3>
    <p>In Papua New Guinea, altitude significantly affects what can be grown. Highland areas (above 1000m) suit cool-season crops. Lowland tropical areas suit hot, humid crops like coconut, banana, and oil palm.</p>
  </div>
  <div class="lesson-section">
    <h2>Classification by Life Span</h2>
    <p>Crops are also classified by the number of growing seasons required to complete their life cycle:</p>
    <ul>
      <li><strong>Annuals</strong> — complete their life cycle in one growing season (seed to seed in less than 12 months). Examples: maize, rice, beans, tomatoes. They provide continuous blooms throughout the growing season.</li>
      <li><strong>Biennials</strong> — require two growing seasons to complete their life cycle. They grow leaves in year one and flower and produce seeds in year two. Examples: carrot, onion</li>
      <li><strong>Perennials</strong> — live for more than two years, producing fruit or flowers repeatedly. Examples: fruit trees (mango, coconut, coffee), banana. They bloom for 2–8 weeks or longer per year.</li>
    </ul>
  </div>`,
  keyTerms: [
    {word:'Annual crop', def:'A crop that completes its full life cycle — from seed to producing seeds — within one growing season'},
    {word:'Perennial crop', def:'A crop that lives for more than two years and produces repeatedly'},
    {word:'Subsistence crop', def:'A crop grown primarily to feed the farmer\'s own family, not for sale'},
    {word:'Cash crop', def:'A crop grown specifically to be sold for profit at a market'},
    {word:'Cool-season crop', def:'A crop that grows best in temperatures below 20°C'},
    {word:'Warm-season crop', def:'A crop that grows best in temperatures above 20°C'},
  ],
  summary: [
    'Crops are classified by use into six groups: food, feed, fibre, oil, ornamental, and industrial',
    'Environmental requirements include temperature, rainfall, soil type, and altitude',
    'Cool-season crops prefer temperatures below 20°C; warm-season crops prefer above 20°C',
    'Annual crops complete their life cycle in one season; perennials live and produce for many years',
    'Papua New Guinea\'s key food crops include sweet potato, taro, cassava, banana, and yam'
  ],
  quiz: [
    {q:'Which category does cotton belong to?', opts:['Oil crop','Fibre crop','Food crop','Industrial crop'], ans:1},
    {q:'Which type of crop requires two growing seasons to complete its life cycle?', opts:['Annual','Biennial','Perennial','Seasonal'], ans:1},
    {q:'Oil palm is an important crop in Papua New Guinea. What type of crop is it?', opts:['Food crop','Feed crop','Oil crop','Fibre crop'], ans:2},
    {q:'Which is a warm-season crop?', opts:['Peas','Lettuce','Maize','Cabbage'], ans:2},
    {q:'Which of the following best describes a subsistence crop?', opts:['A crop grown only for export','A crop grown primarily to feed the farmer\'s own family','A crop grown for industrial manufacturing','A crop that needs special irrigation'], ans:1},
  ],
  furtherReading: [
    {url:'https://www.fao.org/crops/en/',label:'FAO Crops & Grasslands',desc:'Information on major food and cash crops, cropping systems, and plant production from the FAO.'},
    {url:'https://www.fao.org/plant-production-protection/en/',label:'FAO Plant Production',desc:'Plant production, crop protection, and farming practice guidelines relevant to the Pacific region.'},
  ]
},

'g9-crop-farming': {
  title: 'Crop Farming Practices & Management',
  strand: 'Strand 1: Crops · Unit 3', grade: 9, icon: '🚜',
  lessons: ['Types of Farming Systems','Crop Management Practices','Improving Crop Farming'],
  currentLesson: 0,
  objectives: [
    'Identify and describe types of crop farming practices used in different contexts',
    'Analyse different crop farming practices in different environments',
    'Propose ways of improving crop farming practices'
  ],
  content: `
  <div class="lesson-section">
    <h2>Types of Farming Systems</h2>
    <p>Crop farmers work the land to produce vegetables, fruits, grains, and other crops. Different farming systems are used around the world and in Papua New Guinea:</p>
    <ul>
      <li><strong>Subsistence farming</strong> — farmers grow food mainly for their own family. Characterised by small, scattered land areas, few resources, and minimal technology. Very common in Papua New Guinea.</li>
      <li><strong>Commercial farming</strong> — farming for profit, where food is produced using advanced technology and sold in the market. Often few workers are employed due to mechanisation.</li>
      <li><strong>Mixed farming</strong> — involves both growing crops and raising livestock on the same farm. This spreads risk and improves soil through animal manure.</li>
      <li><strong>Arable farming</strong> — focuses only on growing crops (no livestock) in warm climates.</li>
      <li><strong>Pastoral farming</strong> — focuses on livestock production — dairy farming, beef cattle, or sheep — rather than crops.</li>
      <li><strong>Intensive farming</strong> — uses high levels of inputs (fertiliser, water, labour) per unit of land to maximise yield. Produces more food per hectare but has higher environmental impact.</li>
      <li><strong>Extensive farming</strong> — uses large areas of land with low inputs and low yields per hectare. Common in areas where land is plentiful.</li>
      <li><strong>Nomadic farming</strong> — livestock are herded from place to place to find fresh pasture. Practised in grassland and savannah regions.</li>
      <li><strong>Shifting cultivation</strong> — a traditional practice where land is cleared, farmed for a few years, then abandoned to recover. Still practised in some parts of Papua New Guinea.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Crop Management Practices</h2>
    <p>Good crop management involves making the right decisions at each stage of production. Key practices include:</p>
    <ul>
      <li><strong>Planting date</strong> — choosing the right time to plant based on season, rainfall, and temperature</li>
      <li><strong>Plant population</strong> — planting the right density so crops are not too crowded (competing) or too sparse (wasting land)</li>
      <li><strong>Irrigation</strong> — supplying water during dry periods to ensure crops get enough moisture</li>
      <li><strong>Fertilising</strong> — adding nutrients (organic or synthetic) to maintain soil fertility</li>
      <li><strong>Weeding</strong> — removing competing plants that reduce yield</li>
      <li><strong>Pest and disease control</strong> — managing insects, fungi, and other organisms that damage crops</li>
      <li><strong>Crop rotation</strong> — alternating different crops on the same land each season to maintain soil nutrients and break pest cycles</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Improving Crop Farming Practices</h2>
    <p>There are many ways to improve crop farming to increase productivity:</p>
    <ol>
      <li><strong>Multiple cropping</strong> — growing more than one crop on the same piece of land during the year. For example, growing sweet potato after harvesting maize.</li>
      <li><strong>Improved inputs</strong> — using quality seeds, fertilisers, and pesticides to improve yield</li>
      <li><strong>Better irrigation</strong> — building or improving water supply systems</li>
      <li><strong>Agricultural education</strong> — training farmers in modern techniques and best practices</li>
      <li><strong>Better transport and markets</strong> — connecting farmers to markets so they can sell produce and earn enough to invest back into their farms</li>
    </ol>
    <h3>Sustainable Farming Practices</h3>
    <p>Sustainable agriculture meets society's present food needs without compromising the ability of future generations to meet their needs. Key sustainable practices include:</p>
    <ul>
      <li><strong>Permaculture</strong> — designing food production systems that mimic natural ecosystems</li>
      <li><strong>Crop rotation and polycultures</strong> — growing multiple crops together to maintain soil health</li>
      <li><strong>Using renewable energy</strong> — solar pumps for irrigation instead of diesel</li>
      <li><strong>Agroforestry</strong> — planting trees among crops to improve soil, shade, and biodiversity</li>
    </ul>
    <div class="info-box"><strong>⚠️ Poor agricultural practices</strong> — such as overuse of chemicals — reduce soil porosity, increase salinity and alkalinity, and disturb the natural nutrient composition of soil. These effects reduce productivity over time.</div>
  </div>`,
  keyTerms: [
    {word:'Subsistence farming', def:'Farming where food is grown mainly for the farmer\'s own family with little surplus for sale'},
    {word:'Crop rotation', def:'Alternating different crops on the same land each season to maintain soil fertility and control pests'},
    {word:'Irrigation', def:'The artificial supply of water to crops when natural rainfall is insufficient'},
    {word:'Multiple cropping', def:'Growing more than one crop on the same piece of land during the same year'},
    {word:'Permaculture', def:'A food production system designed to mimic how plants grow naturally in ecosystems'},
    {word:'Shifting cultivation', def:'A traditional farming practice where land is cleared, farmed for a few years, then left to recover'},
  ],
  summary: [
    'Farming systems include subsistence, commercial, mixed, arable, pastoral, intensive, and extensive',
    'Shifting cultivation and subsistence farming are common traditional practices in Papua New Guinea',
    'Good crop management involves correct planting time, watering, fertilising, weeding, and pest control',
    'Multiple cropping — growing more than one crop per year — increases productivity',
    'Sustainable farming protects soil and ensures land can continue to produce for future generations'
  ],
  quiz: [
    {q:'Which farming system involves both growing crops and raising livestock on the same farm?', opts:['Arable farming','Subsistence farming','Mixed farming','Nomadic farming'], ans:2},
    {q:'What is crop rotation?', opts:['Growing the same crop on the same land every year','Alternating different crops on the same land each season','Planting crops in circles','Growing crops in rotation with livestock'], ans:1},
    {q:'Which is a sustainable farming practice?', opts:['Using maximum chemical fertilisers','Overusing irrigation water','Permaculture','Single cropping only'], ans:2},
    {q:'Shifting cultivation is best described as:', opts:['Moving livestock between pastures','Clearing land, farming it for a few years, then leaving it to recover','Rotating between different commercial crops','Farming using machines only'], ans:1},
    {q:'What does multiple cropping mean?', opts:['Planting many types of seeds at once','Growing more than one crop on the same land during the same year','Using multiple fertiliser types','Farming in multiple locations'], ans:1},
  ],
  furtherReading: [
    {url:'https://www.fao.org/agriculture/crops/thematic-sitemap/theme/spi/en/',label:'FAO Crop Farming',desc:'Farming systems, land management, and sustainable crop practices from the FAO.'},
    {url:'https://www.fao.org/agroecology/en/',label:'FAO Agroecology',desc:'Sustainable and ecological approaches to crop farming, including shifting cultivation and mixed farming.'},
  ]
},

'g9-crop-technology': {
  title: 'Crop Farming Technology',
  strand: 'Strand 1: Crops · Unit 4', grade: 9, icon: '⚙️',
  lessons: ['Technology in Crop Cultivation','Advantages of Agricultural Technology','Disadvantages & Crop Management Tech'],
  currentLesson: 0,
  objectives: [
    'Identify the advantages and disadvantages of technology used in crop cultivation',
    'Describe different types of technologies used in crop management',
    'Analyse the benefits of technology in crop management'
  ],
  content: `
  <div class="lesson-section">
    <h2>Technology in Crop Cultivation</h2>
    <p>Technology has changed farming significantly. Modern machines, irrigation systems, and digital tools allow farmers to produce more food on the same land. However, technology also comes with challenges.</p>
  </div>
  <div class="lesson-section">
    <h2>Advantages of Technology in Crop Cultivation</h2>
    <ul>
      <li>Modern machinery reduces the physical effort required by farmers and saves time</li>
      <li>Irrigation technology supplies water to crops efficiently, even in dry conditions</li>
      <li>Machines help with sowing seeds accurately, at the right spacing and depth</li>
      <li>Technology is used in transportation of produce to markets</li>
      <li>Application of synthetic fertilisers can boost soil nutrients quickly</li>
      <li>Chemical pest control can prevent large crop losses from insects and diseases</li>
      <li>Technology increases the price and demand of products through better marketing</li>
      <li>Online trading and e-commerce helps farmers sell directly to buyers</li>
      <li>Precision farming reduces the use of water and fertiliser, keeping prices down</li>
      <li>Technology reduces the run-off of chemicals into water sources</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Disadvantages of Technology in Crop Cultivation</h2>
    <ul>
      <li>Excessive use of chemicals (through machines) reduces the long-term fertility of the land</li>
      <li>Farmers without training cannot handle machines properly — leading to poor results or accidents</li>
      <li>The cost of purchasing and maintaining machinery is very high</li>
      <li>Overuse of machines can lead to environmental damage — soil compaction, erosion</li>
      <li>Technology has many side effects if not used correctly</li>
      <li>Most farmers in developing countries may lack literacy to use modern technologies</li>
    </ul>
    <div class="info-box"><strong>💡 Key Insight:</strong> The best approach is to combine traditional knowledge with appropriate modern technology. Technology should match the scale and resources of the farmer.</div>
  </div>
  <div class="lesson-section">
    <h2>Precision Farming and Crop Management Technology</h2>
    <p><strong>Precision farming</strong> is a systems approach to managing crops and land selectively according to their specific needs. It integrates information technology with farming to help managers make better decisions about each part of their fields.</p>
    <p>Types of crop management technologies include:</p>
    <ul>
      <li><strong>GPS and mapping systems</strong> — help farmers track and manage different sections of their farm</li>
      <li><strong>Soil sensors</strong> — measure moisture, pH, and nutrient levels in real time</li>
      <li><strong>Drones</strong> — used to survey large crop areas, detect disease, and apply pesticides efficiently</li>
      <li><strong>Drip irrigation systems</strong> — deliver water directly to plant roots, reducing waste</li>
      <li><strong>Weather forecasting tools</strong> — help farmers plan planting and harvesting around expected conditions</li>
    </ul>
  </div>`,
  keyTerms: [
    {word:'Precision farming', def:'A systems approach that uses technology to manage crops and land selectively according to their specific needs'},
    {word:'Irrigation technology', def:'Any system used to supply water artificially to crops — e.g. drip irrigation, sprinkler systems'},
    {word:'Soil compaction', def:'When heavy machinery presses soil particles together, reducing pore space and making it harder for roots to grow'},
    {word:'E-commerce', def:'Buying and selling goods and services over the internet'},
  ],
  summary: [
    'Technology in agriculture includes machinery, irrigation systems, GPS, sensors, and drones',
    'Key advantages: saves labour and time, boosts yield, improves marketing and distribution',
    'Key disadvantages: high cost, potential environmental damage, requires training and literacy',
    'Precision farming uses information technology to manage specific parts of a farm more effectively',
    'The best farming combines appropriate technology with traditional knowledge and sustainable practices'
  ],
  quiz: [
    {q:'What is precision farming?', opts:['Farming that uses only traditional tools','A systems approach using technology to manage crops according to their specific needs','Farming only small plots of land','Growing food in a laboratory'], ans:1},
    {q:'Which is a disadvantage of technology in crop cultivation?', opts:['It reduces the time needed for farming','Excessive chemical use can reduce long-term soil fertility','It improves marketing','It supplies water efficiently'], ans:1},
    {q:'Drip irrigation delivers water:', opts:['From sprinklers above the crop','Directly to the plant roots with minimal waste','Through flooding the entire field','Through large channels between rows'], ans:1},
    {q:'Which technology helps farmers survey large crop areas and detect disease from above?', opts:['GPS systems','Soil sensors','Drones','Weather apps'], ans:2},
  ]
},

'g9-horticulture': {
  title: 'Horticulture — Fruits, Vegetables & Spices',
  strand: 'Strand 1: Crops · Unit 5', grade: 9, icon: '🍅',
  lessons: ['Introduction to Horticulture','Fruit Tree Cultivation','Vegetable & Spice Cultivation','Processing & Marketing'],
  currentLesson: 0,
  objectives: [
    'Explain what horticulture is and identify the types of horticultural plants',
    'Describe how fruit trees, vegetables, and spices are cultivated and processed',
    'Explain how horticultural plant products are preserved and marketed'
  ],
  content: `
  <div class="lesson-section">
    <h2>What is Horticulture?</h2>
    <p><strong>Horticulture</strong> is a branch of plant agriculture that deals with garden crops — fruits, vegetables, and ornamental plants. The word comes from the Latin <em>hortus</em> (garden) and <em>cultura</em> (cultivation).</p>
    <p>Horticultural plants need their seeds planted in a seedbed and are looked after for some weeks before being transplanted to the field. Irrigation and nursery management are very important — crops cannot be successfully produced where water is insufficient.</p>
    <h3>The Three Main Types of Horticultural Plants</h3>
    <ul>
      <li><strong>Fruit trees</strong> — trees which bear fruits consumed by humans and animals. Examples: mango, pawpaw, citrus, avocado, pineapple</li>
      <li><strong>Vegetables</strong> — the edible parts of plants including flower, fruit, stem, or leaf. Examples: tomato, cabbage, beans, pumpkin, spinach</li>
      <li><strong>Spices</strong> — seeds, fruits, roots, bark, or other plant substances used mainly for flavouring, colouring, or preserving food. Examples: ginger, chilli, turmeric, pepper, vanilla</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Importance and Benefits of Horticulture</h2>
    <ul>
      <li>Provides nutritious food — fruits and vegetables supply vitamins, minerals, and fibre</li>
      <li>Provides income — horticultural products are sold at local markets and can be exported</li>
      <li>Can be grown on small plots, making it suitable for subsistence and smallholder farmers</li>
      <li>Improves food security at family and community level</li>
      <li>Provides raw materials for food processing industries</li>
      <li>Ornamental horticulture improves the environment and supports tourism</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Fruit Tree Cultivation</h2>
    <p>Fruit trees are cultivated in different ways depending on the environment:</p>
    <ul>
      <li><strong>Seedling propagation</strong> — growing trees from seeds. Slower but inexpensive</li>
      <li><strong>Grafting</strong> — joining a shoot from a productive tree onto a strong rootstock. Produces fruit faster and maintains desired characteristics</li>
      <li><strong>Budding</strong> — inserting a single bud from one tree into the bark of another. Used for citrus, mango, and avocado</li>
      <li><strong>Cuttings</strong> — using stem sections to grow new plants. Used for cassava, sugarcane, and some fruits</li>
    </ul>
    <p>Good fruit tree cultivation also requires: correct spacing, regular pruning, weed control, fertilising, pest and disease management, and irrigation during dry periods.</p>
  </div>
  <div class="lesson-section">
    <h2>Vegetable Cultivation</h2>
    <p>Vegetables need fertile, well-drained soil with consistent moisture. Key steps in vegetable cultivation:</p>
    <ol>
      <li>Land preparation — clearing, tilling, and improving the soil</li>
      <li>Seedbed preparation — creating a fine, level bed for planting</li>
      <li>Planting — direct seeding or transplanting seedlings raised in a nursery</li>
      <li>Irrigation — especially during dry periods</li>
      <li>Fertilising — organic compost or appropriate fertilisers</li>
      <li>Pest and disease management — monitoring and treating as needed</li>
      <li>Harvesting — at the right stage of maturity for best quality</li>
    </ol>
  </div>
  <div class="lesson-section">
    <h2>Processing, Preserving and Marketing of Horticultural Products</h2>
    <p>After harvest, horticultural products must be handled carefully to maintain quality:</p>
    <ul>
      <li><strong>Processing</strong> — cleaning, sorting, grading, and sometimes cooking or drying products</li>
      <li><strong>Preservation</strong> — extending the shelf life through drying, pickling, freezing, canning, or smoking</li>
      <li><strong>Packaging</strong> — using appropriate containers to protect produce during transport</li>
      <li><strong>Marketing</strong> — selling at markets, roadside stalls, to wholesalers, or through cooperatives</li>
    </ul>
    <div class="info-box"><strong>🇵🇬 PNG Example:</strong> Spice crops like vanilla and ginger are important horticultural exports from Papua New Guinea. They require careful post-harvest handling to maintain quality for export markets.</div>
  </div>`,
  keyTerms: [
    {word:'Horticulture', def:'A branch of agriculture dealing with garden crops including fruits, vegetables, and ornamental plants'},
    {word:'Grafting', def:'A propagation technique where a shoot from one plant is joined onto the rootstock of another to grow as a single plant'},
    {word:'Nursery', def:'A place where young plants are raised from seeds before transplanting to the field'},
    {word:'Processing', def:'Preparing a harvested product for sale or further use — including cleaning, sorting, grading, and packaging'},
    {word:'Preservation', def:'Extending the shelf life of a food product through methods such as drying, freezing, pickling, or canning'},
  ],
  summary: [
    'Horticulture covers fruits, vegetables, spices, and ornamental plants',
    'Horticultural plants provide nutrition, income, and food security',
    'Fruit trees can be propagated by seeds, grafting, budding, or cuttings',
    'Vegetable cultivation requires fertile soil, irrigation, fertilising, and pest management',
    'Post-harvest handling — processing, preservation, packaging — is essential to maintain quality and earn good prices'
  ],
  quiz: [
    {q:'What is horticulture?', opts:['The study of weather and its effects on crops','A branch of agriculture dealing with garden crops including fruits, vegetables, and ornamental plants','The raising of livestock for food','Large-scale commercial grain farming'], ans:1},
    {q:'Which propagation method joins a shoot from a productive tree onto a strong rootstock?', opts:['Direct seeding','Cuttings','Grafting','Budding'], ans:2},
    {q:'Which of the following is a spice crop?', opts:['Tomato','Mango','Ginger','Cabbage'], ans:2},
    {q:'What is the purpose of preservation in horticulture?', opts:['To make fruits grow faster','To extend the shelf life of harvested products','To improve soil quality','To control pests during growing'], ans:1},
    {q:'Why is irrigation particularly important in horticulture?', opts:['It replaces the need for fertiliser','Horticultural crops cannot be produced where water is insufficient','It prevents all pests from attacking crops','Horticultural crops only grow in flooded fields'], ans:1},
  ]
},

/* ─── GRADE 9 STRAND 2: ANIMALS ───────────────────────────── */

'g9-monogastric-polygastric': {
  title: 'Monogastric & Polygastric Animals',
  strand: 'Strand 2: Animals · Unit 1', grade: 9, icon: '🐷',
  lessons: ['What are Monogastric Animals?','What are Polygastric Animals?','Comparison & Benefits'],
  currentLesson: 0,
  objectives: [
    'Define and distinguish between monogastric and polygastric animals',
    'Identify examples of each type found in Papua New Guinea',
    'Explain the purposes and benefits of each type of farm animal'
  ],
  content: `
  <div class="lesson-section">
    <h2>Monogastric Animals</h2>
    <figure class="lesson-figure">
      <img src="Image/animals.webp" alt="Farm animals raised in Papua New Guinea" loading="lazy"/>
      <figcaption>Common farm animals raised in Papua New Guinea, including pigs, cattle, and poultry.</figcaption>
    </figure>
    <p>A <strong>monogastric animal</strong> has a simple, single-chambered stomach. Their digestive system is similar to humans — food passes through the stomach once, enzymes break it down, and nutrients are absorbed.</p>
    <p>Monogastric animals cannot efficiently digest large amounts of plant fibre (cellulose) like grass. They rely mainly on grains, fruits, roots, and concentrates as their feed.</p>
    <h3>Examples of Monogastric Farm Animals</h3>
    <ul>
      <li><strong>Pigs (swine)</strong> — the most important monogastric farm animal in Papua New Guinea. Raised for pork, lard, and cultural ceremonies</li>
      <li><strong>Chickens and poultry</strong> — raised for eggs and meat; also monogastric</li>
      <li><strong>Rabbits</strong> — small monogastric animals raised for meat and fur</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Polygastric Animals (Ruminants)</h2>
    <p>A <strong>polygastric animal</strong> (also called a ruminant) has a stomach with multiple chambers — typically four. This complex digestive system allows them to break down tough plant material like grass and leaves that monogastric animals cannot digest.</p>
    <h3>The Four Stomach Chambers of a Ruminant</h3>
    <ul>
      <li><strong>Rumen</strong> — the largest chamber where food is stored and fermented by micro-organisms. Food is regurgitated from here as "cud" to be chewed again</li>
      <li><strong>Reticulum</strong> — also called the "honeycomb stomach," works with the rumen in fermentation</li>
      <li><strong>Omasum</strong> — absorbs water and further breaks down food particles</li>
      <li><strong>Abomasum</strong> — the "true stomach," works like a monogastric stomach with acid and enzyme digestion</li>
    </ul>
    <h3>Examples of Polygastric Farm Animals</h3>
    <ul>
      <li><strong>Cattle (cows)</strong> — raised for beef, dairy milk, and draught power</li>
      <li><strong>Goats</strong> — raised for meat (chevon), milk, and skins. Very adaptable to different environments</li>
      <li><strong>Sheep</strong> — raised for wool, meat (lamb and mutton), and milk</li>
      <li><strong>Buffalo</strong> — used as draught animals and raised for meat and milk in some countries</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Key Differences Between Monogastric and Polygastric</h2>
    <div class="fact-grid">
      <div class="fact-box"><div class="fact-n">1</div><div class="fact-l">Stomach chamber (monogastric)</div></div>
      <div class="fact-box"><div class="fact-n">4</div><div class="fact-l">Stomach chambers (polygastric)</div></div>
    </div>
    <p>The key practical difference is feeding: polygastric animals can graze on grass and pasture, which is cheap and widely available. Monogastric animals need more concentrated feeds like grain, which are more expensive but result in faster weight gain.</p>
    <div class="info-box"><strong>🇵🇬 PNG Context:</strong> Pigs hold cultural and economic importance in Papua New Guinea — they are central to bride price ceremonies (bridewealth), feasts, and community events. Pig farming is one of the most widespread livestock activities in the country.</div>
  </div>`,
  keyTerms: [
    {word:'Monogastric', def:'An animal with a simple, single-chambered stomach — e.g. pig, chicken, rabbit'},
    {word:'Polygastric (ruminant)', def:'An animal with a complex stomach of four chambers that allows digestion of tough plant fibre — e.g. cattle, goat, sheep'},
    {word:'Rumen', def:'The first and largest stomach chamber of a ruminant where food is fermented by micro-organisms'},
    {word:'Cud', def:'Partially digested food that a ruminant brings back up from the rumen to chew again'},
    {word:'Cellulose', def:'The tough structural fibre in plant cell walls that only ruminants (and some insects) can fully digest'},
  ],
  summary: [
    'Monogastric animals have one simple stomach — examples include pigs, chickens, and rabbits',
    'Polygastric (ruminant) animals have four stomach chambers — examples include cattle, goats, and sheep',
    'Ruminants can digest grass and tough plant material; monogastrics require concentrated feeds like grain',
    'The four chambers of a ruminant stomach are the rumen, reticulum, omasum, and abomasum',
    'Pigs hold significant cultural and economic importance in Papua New Guinea'
  ],
  quiz: [
    {q:'How many stomach chambers does a ruminant have?', opts:['One','Two','Three','Four'], ans:3},
    {q:'Which of the following is a monogastric animal?', opts:['Goat','Cattle','Pig','Sheep'], ans:2},
    {q:'What is cud?', opts:['A type of animal feed made from grain','Partially digested food regurgitated from the rumen for re-chewing','The fourth chamber of a ruminant stomach','A chemical produced in the reticulum'], ans:1},
    {q:'Why can ruminants graze on grass while pigs cannot?', opts:['Pigs do not like the taste of grass','Ruminants have a complex multi-chambered stomach that can break down cellulose','Pigs need a special enzyme found only in grain','Grass contains toxins that harm pig digestion'], ans:1},
    {q:'What is the largest stomach chamber in a ruminant called?', opts:['Omasum','Abomasum','Reticulum','Rumen'], ans:3},
  ]
},

/* ─── GRADE 9 STRAND 3: AQUACULTURE ───────────────────────── */

'g9-intro-aquaculture': {
  title: 'Introduction to Aquaculture',
  strand: 'Strand 3: Aquaculture · Unit 1', grade: 9, icon: '🐟',
  lessons: ['What is Aquaculture?','Types of Aquatic Environments','Importance in Papua New Guinea'],
  currentLesson: 0,
  objectives: [
    'Define aquaculture and explain its historical background',
    'Distinguish between freshwater, brackish water, and saltwater aquaculture environments',
    'Explain the importance of aquaculture in Papua New Guinea'
  ],
  content: `
  <div class="lesson-section">
    <h2>What is Aquaculture?</h2>
    <p><strong>Aquaculture</strong> is the controlled farming of aquatic organisms — fish, shellfish, crustaceans, and aquatic plants — in freshwater, brackish water, or saltwater environments. It is sometimes described as "the underwater equivalent of agriculture."</p>
    <p>Unlike capture fishery (where fish are caught from the wild), aquaculture involves deliberately stocking, feeding, and managing aquatic species to increase production.</p>
    <figure class="lesson-figure">
      <img src="Image/aquaculture.webp" alt="Fish farming pond used in freshwater aquaculture" loading="lazy"/>
      <figcaption>A freshwater fish farming pond — one of the most common forms of aquaculture practised in Papua New Guinea and across the Pacific.</figcaption>
    </figure>
    <h3>Brief History of Aquaculture</h3>
    <p>Aquaculture is one of the oldest forms of food production. Ancient Egyptians farmed fish in ponds along the Nile River. In China, carp farming dates back more than 2,500 years. In Papua New Guinea, traditional communities have practised fish trapping and management in rivers and coastal areas for generations.</p>
  </div>
  <div class="lesson-section">
    <h2>Types of Aquatic Environments</h2>
    <h3>Freshwater Aquaculture</h3>
    <p>Farming in rivers, lakes, ponds, and dams. Fresh water contains less than 0.5 parts per thousand (ppt) of dissolved salt. Common species farmed in freshwater include:</p>
    <ul>
      <li>Tilapia — a hardy, fast-growing fish popular in tropical freshwater farming</li>
      <li>Common carp — one of the oldest farmed fish in the world</li>
      <li>Catfish — farmed widely in tropical regions for food</li>
      <li>Freshwater prawns</li>
    </ul>
    <h3>Brackish Water Aquaculture</h3>
    <p>Brackish water contains between 0.5 and 30 ppt of dissolved salt — a mix between freshwater and seawater. Found in river mouths, mangroves, and coastal lagoons. Common species include:</p>
    <ul>
      <li>Milkfish (bangus) — a major aquaculture species in the Pacific</li>
      <li>Tiger prawns and shrimp</li>
      <li>Mud crab — highly valued in Pacific Island markets</li>
      <li>Barramundi (giant perch)</li>
    </ul>
    <h3>Saltwater (Marine) Aquaculture</h3>
    <p>Farming in the open sea or enclosed coastal areas. Saltwater contains more than 30 ppt dissolved salt. Common species include:</p>
    <ul>
      <li>Sea bass and grouper — high-value fish farmed in sea cages</li>
      <li>Oysters, mussels, and clams — bivalves grown on ropes or in mesh bags</li>
      <li>Sea cucumbers (bêche-de-mer) — highly valued in export markets, particularly to Asia</li>
      <li>Giant clam — farmed in some Pacific Island communities</li>
      <li>Seaweed (Kappaphycus) — farmed for use in food products and cosmetics</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Importance of Aquaculture in Papua New Guinea</h2>
    <p>Papua New Guinea has extraordinary aquatic resources — thousands of kilometres of coastline, major river systems (including the Sepik and Fly Rivers), and rich coral reef ecosystems. Aquaculture is important for several reasons:</p>
    <ul>
      <li><strong>Food security</strong> — fish is a critical source of protein for many communities, especially in coastal and island areas</li>
      <li><strong>Income generation</strong> — fish farming provides a cash income for smallholder farmers</li>
      <li><strong>Reducing pressure on wild fisheries</strong> — aquaculture can supplement capture fishing and reduce overfishing of natural stocks</li>
      <li><strong>Employment</strong> — the aquaculture industry creates jobs in rural communities</li>
      <li><strong>Export earnings</strong> — sea cucumber, coral trout, and other species are exported to international markets</li>
    </ul>
    <div class="info-box"><strong>🐟 PNG Opportunity:</strong> Tilapia ponds are widely promoted in PNG highlands communities as an affordable way to produce protein. Barramundi (locally called "seabass") is farmed in coastal areas for both local markets and export.</div>
  </div>`,
  keyTerms: [
    {word:'Aquaculture', def:'The controlled farming of fish, shellfish, and aquatic plants in freshwater, brackish, or saltwater environments'},
    {word:'Freshwater', def:'Water with less than 0.5 ppt dissolved salt — found in rivers, lakes, and ponds'},
    {word:'Brackish water', def:'Water with 0.5–30 ppt dissolved salt — found in river mouths, mangroves, and coastal lagoons'},
    {word:'Capture fishery', def:'Catching wild fish and other aquatic organisms from natural water bodies, as opposed to farming them'},
    {word:'Tilapia', def:'A hardy, fast-growing tropical freshwater fish widely farmed in Papua New Guinea and across the developing world'},
    {word:'Bêche-de-mer', def:'Sea cucumber — a marine animal dried and exported to Asian markets; an important aquaculture species in the Pacific'},
  ],
  summary: [
    'Aquaculture is the controlled farming of aquatic organisms — fish, shellfish, crustaceans, and plants',
    'The three main environments are freshwater (rivers/ponds), brackish water (mangroves/river mouths), and saltwater (sea)',
    'Common freshwater species include tilapia and carp; brackish water includes milkfish and mud crab; saltwater includes sea cucumber and seaweed',
    'Papua New Guinea has rich aquatic resources including major rivers, extensive coastline, and coral reefs',
    'Aquaculture supports food security, income generation, and reduces pressure on wild fish stocks'
  ],
  quiz: [
    {q:'What is aquaculture?', opts:['Catching wild fish from rivers and oceans','The controlled farming of aquatic organisms in freshwater, brackish, or saltwater','Growing water plants for decoration','Studying the biology of sea animals'], ans:1},
    {q:'What salt content defines freshwater?', opts:['Less than 0.5 ppt','Between 5 and 15 ppt','More than 30 ppt','Between 0.5 and 30 ppt'], ans:0},
    {q:'Which species is commonly farmed in brackish water environments in the Pacific?', opts:['Common carp','Freshwater tilapia','Milkfish (bangus)','Rainbow trout'], ans:2},
    {q:'What is bêche-de-mer?', opts:['A type of freshwater fish','Dried sea cucumber exported to Asian markets','A form of seaweed used in cosmetics','A brackish water prawn species'], ans:1},
    {q:'Which of the following is NOT a reason why aquaculture is important in Papua New Guinea?', opts:['It provides protein for food security','It generates income for smallholder farmers','It completely replaces the need for capture fishing','It creates employment in rural communities'], ans:2},
  ]
},

/* ─── GRADE 9 STRAND 4: NATURAL RESOURCES ─────────────────── */

'g9-forests': {
  title: 'Types of Forests & Forest Resources',
  strand: 'Strand 4: NRM · Unit 1', grade: 9, icon: '🌳',
  lessons: ['Types of Forests','Forest Resources & Products','Importance of Forests'],
  currentLesson: 0,
  objectives: [
    'Identify the different types of forests found in Papua New Guinea',
    'Describe the resources and products provided by forests',
    'Explain the importance of forests to people and the environment'
  ],
  content: `
  <div class="lesson-section">
    <h2>Types of Forests</h2>
    <p>Papua New Guinea has some of the world\'s most biodiverse tropical forests — covering approximately 70% of the country\'s land area. Different forest types exist based on altitude, rainfall, and soil conditions.</p>
    <figure class="lesson-figure">
      <img src="Image/nrm.webp" alt="Tropical rainforest canopy similar to Papua New Guinea forests" loading="lazy"/>
      <figcaption>Tropical rainforest — the dominant forest type in Papua New Guinea, covering vast areas of lowland and highland terrain.</figcaption>
    </figure>
    <h3>Lowland Tropical Rainforest</h3>
    <p>Found below 1,000 metres altitude. Characterised by tall trees (up to 50m), very high rainfall, high biodiversity, and dense canopy. Home to many commercially valuable timber species.</p>
    <h3>Montane (Highland) Forest</h3>
    <p>Found above 1,000 metres. Trees are shorter and often covered in mosses and epiphytes. Higher rainfall and cooler temperatures. Important for water catchment and biodiversity.</p>
    <h3>Mangrove Forest</h3>
    <p>Found in coastal areas where land and sea meet — along river mouths, estuaries, and sheltered coastlines. Mangroves have specialised roots that can grow in saltwater. They are extremely important for coastal protection, fish nurseries, and carbon storage.</p>
    <h3>Swamp Forest</h3>
    <p>Found in low-lying areas with waterlogged soils. Includes sago palm forests, which are a critical food source for many communities in the Sepik and other lowland regions.</p>
    <h3>Grassland / Savannah</h3>
    <p>Open vegetation with grasses and scattered trees, found in drier areas of southern PNG. Home to grazing animals and used for pastoral farming.</p>
  </div>
  <div class="lesson-section">
    <h2>Forest Resources and Products</h2>
    <p>Forests provide a wide range of resources:</p>
    <ul>
      <li><strong>Timber</strong> — logs and sawn timber are among PNG\'s most important exports. Key species include kwila (merbau), rosewood, and PNG teak</li>
      <li><strong>Food</strong> — forests provide fruit, nuts, sago, bush meat, insects, and mushrooms for local communities</li>
      <li><strong>Medicine</strong> — traditional medicine uses many forest plants; modern pharmaceutical research also draws on forest biodiversity</li>
      <li><strong>Water</strong> — forests protect watersheds, regulate water flow, and maintain clean water for rivers</li>
      <li><strong>Carbon storage</strong> — forests store enormous amounts of carbon, helping regulate the global climate</li>
      <li><strong>Building materials</strong> — timber, bamboo, and palm are used for housing and tools</li>
      <li><strong>Non-Timber Forest Products (NTFPs)</strong> — rattan, resin, honey, and many other products harvested without cutting trees</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Importance of Forests</h2>
    <ul>
      <li><strong>Biodiversity</strong> — PNG\'s forests contain around 5–7% of the world\'s species, including unique birds, reptiles, and plants found nowhere else on Earth</li>
      <li><strong>Climate regulation</strong> — forests absorb CO₂ and produce oxygen. Deforestation accelerates climate change</li>
      <li><strong>Soil protection</strong> — forest roots prevent soil erosion and landslides</li>
      <li><strong>Water regulation</strong> — forests act as natural sponges, absorbing rain and slowly releasing it into rivers</li>
      <li><strong>Cultural importance</strong> — forests have deep spiritual and cultural significance for many communities in Papua New Guinea</li>
      <li><strong>Economic value</strong> — logging, ecotourism, and non-timber products all contribute to national and local economies</li>
    </ul>
    <div class="info-box"><strong>⚠️ Threat:</strong> Papua New Guinea is experiencing significant deforestation due to large-scale logging, conversion to oil palm plantations, and subsistence clearing. Sustainable forest management is essential to protect these resources for future generations.</div>
  </div>`,
  keyTerms: [
    {word:'Biodiversity', def:'The variety of living species in an area — including plants, animals, fungi, and micro-organisms'},
    {word:'Watershed', def:'An area of land that drains water into a river, lake, or other body of water'},
    {word:'Mangrove', def:'A forest type found in coastal saltwater environments, with trees having specialised roots adapted to waterlogged, salty conditions'},
    {word:'Non-Timber Forest Products (NTFPs)', def:'Products from forests that do not require cutting down trees — e.g. rattan, honey, resins, and medicinal plants'},
    {word:'Deforestation', def:'The permanent removal of forest through logging, burning, or conversion to other land uses'},
    {word:'Carbon storage', def:'The ability of trees and soil to absorb and hold carbon dioxide, reducing its concentration in the atmosphere'},
  ],
  summary: [
    'Papua New Guinea has several forest types: lowland rainforest, montane forest, mangrove, swamp forest, and grassland',
    'Forests provide timber, food, medicine, water, carbon storage, and building materials',
    'PNG\'s forests contain 5–7% of the world\'s species — extraordinary biodiversity',
    'Forests protect soil, regulate water, and play a vital role in regulating the global climate',
    'Deforestation from logging and land clearing threatens PNG\'s forests — sustainable management is essential'
  ],
  quiz: [
    {q:'What percentage of Papua New Guinea\'s land area is covered by forest?', opts:['Approximately 30%','Approximately 50%','Approximately 70%','Approximately 90%'], ans:2},
    {q:'What type of forest grows in coastal areas where saltwater and land meet?', opts:['Montane forest','Swamp forest','Mangrove forest','Lowland rainforest'], ans:2},
    {q:'Which of the following is a Non-Timber Forest Product (NTFP)?', opts:['Kwila timber','Sawn logs','Rattan and honey','Converted land for farming'], ans:2},
    {q:'What is the main threat to Papua New Guinea\'s forests?', opts:['Too much rainfall','Deforestation from logging and land clearing','Invasive fish species in rivers','Forest fires only'], ans:1},
    {q:'Why are forests important for water?', opts:['They create rainfall by themselves','They act as natural sponges that absorb rain and slowly release it into rivers','They block rivers from flowing','They are important for marine fisheries only'], ans:1},
  ]
},

/* ─── GRADE 9 STRAND 5: AGRIBUSINESS ──────────────────────── */

'g9-agribusiness-economics': {
  title: 'Economic Principles in Agribusiness',
  strand: 'Strand 5: Agribusiness · Unit 1', grade: 9, icon: '💰',
  lessons: ['What is Agribusiness?','Micro and Macro Economics','Supply, Demand & Agricultural Markets'],
  currentLesson: 0,
  objectives: [
    'Define agribusiness and explain its scope',
    'Describe how micro and macroeconomic principles apply to agricultural businesses',
    'Explain the concepts of supply, demand, and pricing in agricultural markets'
  ],
  content: `
  <div class="lesson-section">
    <h2>What is Agribusiness?</h2>
    <figure class="lesson-figure">
      <img src="Image/AgriBusiness.webp" alt="Agribusiness activities from farm to market in Papua New Guinea" loading="lazy"/>
      <figcaption>Agribusiness covers the full chain from farm production to processing, distribution, and sale of agricultural products.</figcaption>
    </figure>
    <p><strong>Agribusiness</strong> refers to all the economic activities related to agriculture — from producing food to processing it, packaging it, transporting it, and selling it to consumers. It covers the entire chain from "farm to fork."</p>
    <p>Agribusiness is not just farming. It includes:</p>
    <ul>
      <li><strong>Input supply</strong> — selling seeds, fertilisers, pesticides, and farm equipment to farmers</li>
      <li><strong>Production</strong> — actual farming of crops, livestock, and fish</li>
      <li><strong>Processing</strong> — turning raw agricultural products into processed goods (e.g. cocoa beans into chocolate, coffee cherries into roasted coffee)</li>
      <li><strong>Distribution and logistics</strong> — transporting and storing products from farm to market</li>
      <li><strong>Retail and marketing</strong> — selling final products to consumers</li>
    </ul>
    <div class="info-box"><strong>🇵🇬 PNG Context:</strong> Agriculture contributes significantly to Papua New Guinea\'s economy. Key agribusinesses include coffee, cocoa, oil palm, copra (coconut), and rubber — all major export earners.</div>
  </div>
  <div class="lesson-section">
    <h2>Microeconomics in Agribusiness</h2>
    <p><strong>Microeconomics</strong> studies the behaviour of individual businesses, farmers, and consumers in making economic decisions. Key concepts:</p>
    <ul>
      <li><strong>Cost of production</strong> — the total money spent to produce a crop or raise animals (seeds, fertiliser, labour, equipment)</li>
      <li><strong>Revenue</strong> — the money earned from selling products</li>
      <li><strong>Profit</strong> — revenue minus total costs. A farm must be profitable to be sustainable</li>
      <li><strong>Break-even point</strong> — the minimum production or selling price needed to cover all costs</li>
      <li><strong>Opportunity cost</strong> — the benefit lost when choosing one option over another. For example, if a farmer chooses to grow sweet potato instead of cabbage, the forgone profit from cabbage is the opportunity cost</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Macroeconomics and Agriculture</h2>
    <p><strong>Macroeconomics</strong> looks at the economy as a whole — including the agricultural sector's contribution to the national economy. Key concepts:</p>
    <ul>
      <li><strong>Gross Domestic Product (GDP)</strong> — the total value of goods and services produced in a country. Agriculture contributes significantly to PNG\'s GDP</li>
      <li><strong>Exports and imports</strong> — countries export products they produce efficiently and import what they cannot produce well. PNG exports coffee, cocoa, and palm oil and imports many manufactured goods</li>
      <li><strong>Government policy</strong> — subsidies, tariffs, and regulations affect what farmers produce and at what price</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Supply, Demand, and Agricultural Prices</h2>
    <p>Agricultural markets are governed by supply and demand:</p>
    <ul>
      <li><strong>Supply</strong> — how much of a product farmers are willing and able to sell at a given price. When prices are high, farmers are encouraged to produce more</li>
      <li><strong>Demand</strong> — how much of a product consumers are willing and able to buy at a given price. When prices fall, people buy more</li>
      <li><strong>Market price</strong> — the price at which supply and demand balance (equilibrium)</li>
    </ul>
    <p>Agricultural prices are particularly unstable because:</p>
    <ul>
      <li>Weather affects supply — a drought or flood can dramatically reduce output</li>
      <li>Demand for food is relatively fixed — people need to eat regardless of price</li>
      <li>Global commodity prices fluctuate — coffee and cocoa prices are set on international markets</li>
    </ul>
  </div>`,
  keyTerms: [
    {word:'Agribusiness', def:'All economic activities related to agriculture — from input supply and production through to processing, distribution, and retail'},
    {word:'Microeconomics', def:'The study of individual economic decision-making by farms, businesses, and consumers'},
    {word:'Macroeconomics', def:'The study of the economy as a whole — including GDP, national exports, and government policy'},
    {word:'Profit', def:'The money remaining after all costs of production are subtracted from total revenue'},
    {word:'Supply', def:'The quantity of a product that producers are willing and able to sell at a given price'},
    {word:'Demand', def:'The quantity of a product that consumers are willing and able to buy at a given price'},
  ],
  summary: [
    'Agribusiness covers the entire chain from producing agricultural goods to selling them to consumers',
    'Microeconomics focuses on individual farm decisions — costs, revenue, profit, and opportunity cost',
    'Macroeconomics looks at agriculture\'s role in the national economy — GDP, exports, and government policy',
    'Agricultural prices are determined by supply and demand, but are unstable due to weather and global markets',
    'Papua New Guinea\'s key agribusiness export sectors include coffee, cocoa, oil palm, and rubber'
  ],
  quiz: [
    {q:'What does agribusiness include?', opts:['Only the farming of crops and animals','Only food processing and packaging','All economic activities from input supply through to selling food to consumers','Only the export of agricultural products'], ans:2},
    {q:'What is the break-even point?', opts:['The point of maximum profit','The minimum production or price needed to cover all costs','When supply equals demand exactly','The point where a business stops operating'], ans:1},
    {q:'Which of the following describes an opportunity cost?', opts:['The cost of purchasing farming equipment','The profit lost by choosing one option over another alternative','The cost of transporting goods to market','The difference between wholesale and retail price'], ans:1},
    {q:'Why are agricultural prices particularly unstable?', opts:['Farmers always set prices too high','Weather can dramatically affect supply, and global commodity prices fluctuate','Consumers do not want to buy agricultural products','Agribusiness is not regulated by the government'], ans:1},
    {q:'Which are Papua New Guinea\'s key agribusiness export crops?', opts:['Rice, wheat, maize, and barley','Coffee, cocoa, oil palm, and rubber','Sweet potato, taro, yam, and cassava','Tomatoes, cabbage, cucumber, and beans'], ans:1},
  ]
},

/* ─── GRADE 10 STRAND 1: CROPS ────────────────────────────── */

'g10-soil-improvement': {
  title: 'Soil Improvement Practices',
  strand: 'Strand 1: Crops · Unit 1', grade: 10, icon: '🌱',
  lessons: ['Natural Soil Improvement','Artificial Soil Improvement','Sustaining Soil Fertility'],
  currentLesson: 0,
  objectives: [
    'Describe natural and artificial techniques used to improve soil quality',
    'Explain strategies and processes for sustaining soil fertility over time',
    'Evaluate the advantages and disadvantages of different soil improvement methods'
  ],
  content: `
  <div class="lesson-section">
    <h2>Why Soil Improvement Matters</h2>
    <p>In Grade 9, we learned how soil forms and what it contains. In Grade 10, we focus on how to <em>improve</em> soil that has become degraded, compacted, or depleted of nutrients — and how to sustain its fertility over time.</p>
    <p>Soils become depleted when: crops remove nutrients faster than they are replaced; erosion removes topsoil; overuse of chemicals destroys micro-organisms; or deforestation exposes soil to sun and rain.</p>
  </div>
  <div class="lesson-section">
    <h2>Natural Soil Improvement Techniques</h2>
    <p>Natural methods improve soil without chemical inputs. They work with ecological processes:</p>
    <ul>
      <li><strong>Adding organic matter (compost)</strong> — decomposed plant and animal material improves soil structure, water retention, and nutrient content. Compost is made from kitchen scraps, crop residues, and animal manure</li>
      <li><strong>Green manure / cover crops</strong> — growing legumes (beans, peanuts, mucuna) and then ploughing them back into the soil before flowering. Legumes fix nitrogen from the air into the soil</li>
      <li><strong>Mulching</strong> — covering the soil surface with organic material (straw, leaves, grass) to reduce moisture loss, control weeds, and gradually add organic matter as it decomposes</li>
      <li><strong>Crop rotation</strong> — alternating crops each season to prevent depletion of specific nutrients and break pest cycles</li>
      <li><strong>Agroforestry</strong> — planting trees alongside crops to add organic matter through leaf litter, fix nitrogen, and prevent erosion</li>
      <li><strong>Intercropping</strong> — growing two or more crops together. A nitrogen-fixing legume grown with a cereal crop benefits both</li>
      <li><strong>Worm farming (vermicomposting)</strong> — using earthworms to break down organic waste into rich compost</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Artificial Soil Improvement Techniques</h2>
    <p>Artificial methods use manufactured inputs to quickly improve specific soil properties:</p>
    <ul>
      <li><strong>Synthetic fertilisers (NPK)</strong> — manufactured chemicals that supply nitrogen (N), phosphorus (P), and potassium (K) directly to plants. Fast-acting but can damage soil biology if overused</li>
      <li><strong>Liming</strong> — adding agricultural lime (calcium carbonate) to raise the pH of acidic soils, making nutrients more available to plants</li>
      <li><strong>Gypsum</strong> — adding calcium sulfate to improve clay soil structure and reduce sodicity (excess sodium)</li>
      <li><strong>Irrigation</strong> — supplying water artificially to prevent moisture stress that limits nutrient uptake</li>
      <li><strong>Soil conditioners</strong> — manufactured products (e.g. zeolite, biochar) that improve soil water retention and nutrient holding capacity</li>
    </ul>
    <div class="info-box"><strong>⚖️ Balance:</strong> The best soil management combines natural and artificial techniques. Synthetic fertilisers can boost yields quickly, but relying on them alone degrades soil health over time. Natural methods build long-term fertility.</div>
  </div>
  <div class="lesson-section">
    <h2>Strategies for Sustaining Soil Fertility</h2>
    <p>Sustaining soil fertility means maintaining its ability to support crop production indefinitely. Key strategies:</p>
    <ul>
      <li>Return crop residues and organic waste to the soil rather than burning them</li>
      <li>Avoid leaving soil bare — always maintain ground cover to prevent erosion</li>
      <li>Test soil regularly to know exactly what nutrients are needed</li>
      <li>Apply fertiliser at the right time, in the right amount, and in the right place</li>
      <li>Reduce tillage (ploughing) to protect soil structure and micro-organism communities</li>
      <li>Maintain windbreaks and vegetation on slopes to prevent erosion</li>
    </ul>
  </div>`,
  keyTerms: [
    {word:'Compost', def:'Decomposed organic matter (plant and animal waste) used to improve soil fertility and structure'},
    {word:'Green manure', def:'Crops (often legumes) grown specifically to be ploughed into the soil to add organic matter and nutrients'},
    {word:'Mulching', def:'Covering soil with organic or inorganic material to reduce moisture loss, control weeds, and protect the surface'},
    {word:'Liming', def:'Adding agricultural lime to acidic soil to raise its pH and make nutrients more available to plants'},
    {word:'Nitrogen fixation', def:'The process by which legumes and their associated bacteria convert atmospheric nitrogen gas into soil nitrogen that plants can use'},
    {word:'Biochar', def:'Charcoal produced from organic material that is added to soil to improve its water retention and nutrient holding capacity'},
  ],
  summary: [
    'Soils become depleted through crop removal of nutrients, erosion, chemical overuse, and deforestation',
    'Natural improvement methods include composting, green manures, mulching, crop rotation, and agroforestry',
    'Artificial methods include synthetic fertilisers (NPK), liming, gypsum, and soil conditioners',
    'Legumes fix nitrogen from the air into soil — making them valuable in crop rotation and intercropping',
    'Sustainable soil management combines natural and artificial methods and avoids leaving soil bare'
  ],
  quiz: [
    {q:'What is the purpose of liming a soil?', opts:['To make the soil more acidic','To raise the pH of acidic soil so nutrients become more available','To add nitrogen quickly','To reduce soil moisture'], ans:1},
    {q:'Which natural technique involves growing legumes and ploughing them back into soil?', opts:['Mulching','Composting','Green manure','Vermicomposting'], ans:2},
    {q:'Why should crop residues be returned to soil rather than burned?', opts:['Burning is more practical for large farms','Returning residues adds organic matter and nutrients back to the soil','Burned residues add more nutrients than organic matter','Returning residues is only useful in highland areas'], ans:1},
    {q:'What does NPK stand for in the context of synthetic fertilisers?', opts:['Nitrogen, Phosphorus, Potassium','Nitrogen, Protein, Kallium','Natural, Processed, Known','Nitrate, Pellet, Kelp'], ans:0},
    {q:'Which approach best sustains long-term soil fertility?', opts:['Using only synthetic fertilisers every season','Leaving soil bare between crops','Combining natural and artificial techniques and maintaining organic matter','Ploughing deeply every year'], ans:2},
  ]
},

'g10-crop-classification': {
  title: 'Crop Classification',
  strand: 'Strand 1: Crops · Unit 2', grade: 10, icon: '🌾',
  lessons: ['Classification by Growing Cycle & Species','Classification by Season & Land Type','Classification by Product & Processing'],
  currentLesson: 0,
  objectives: [
    'Classify crops by growing cycle, species, and varieties',
    'Classify crops by season, land type, and crop use',
    'Classify crops by cultivation method, type of product, and processing methods'
  ],
  content: `
  <div class="lesson-section">
    <h2>Why Classify Crops?</h2>
    <p>Classifying crops helps farmers, scientists, and agronomists understand which crops suit which conditions, how to manage them, and how to process and market them. In Grade 10, we go deeper into the multiple classification systems used in agriculture.</p>
  </div>
  <div class="lesson-section">
    <h2>Classification by Growing Cycle</h2>
    <ul>
      <li><strong>Annual crops</strong> — complete their life cycle in one season. Must be re-planted each year. Examples: maize, rice, beans, tomatoes, groundnuts</li>
      <li><strong>Biennial crops</strong> — complete their life cycle in two seasons. Examples: carrot, onion, sugar beet</li>
      <li><strong>Perennial crops</strong> — live for many years, producing continuously. Examples: coffee, cocoa, oil palm, coconut, banana, cassava</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Classification by Species and Varieties</h2>
    <p>Within each crop there are often many different <strong>varieties</strong> (also called cultivars) — each with different characteristics suited to specific environments or uses:</p>
    <ul>
      <li>Rice varieties: lowland rice vs highland rice; long-grain vs short-grain</li>
      <li>Sweet potato varieties: white-fleshed vs orange-fleshed (orange is richer in vitamin A)</li>
      <li>Coffee varieties: Arabica (Highland grown, premium quality) vs Robusta (lowland, stronger flavour)</li>
    </ul>
    <p>Selecting the right variety for local conditions is one of the most important decisions a farmer can make.</p>
  </div>
  <div class="lesson-section">
    <h2>Classification by Season</h2>
    <ul>
      <li><strong>Wet season crops</strong> — planted when rainfall begins, rely on natural moisture. Example: upland rice, taro</li>
      <li><strong>Dry season crops</strong> — planted in the dry season using irrigation. Example: vegetables, groundnuts</li>
      <li><strong>Year-round crops</strong> — perennial crops that produce continuously. Example: banana, coconut, cassava</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Classification by Land Type</h2>
    <ul>
      <li><strong>Upland crops</strong> — grown on well-drained, non-flooded land. Most food crops fall in this category</li>
      <li><strong>Lowland/wetland crops</strong> — grown in low-lying areas that can be flooded. Example: lowland rice, sago palm</li>
      <li><strong>Highland crops</strong> — grown at altitude where temperatures are cooler. Example: pyrethrum, tea, temperate vegetables (potatoes, cabbage)</li>
      <li><strong>Coastal crops</strong> — grown in tropical coastal lowlands. Example: coconut, sago, mangrove products</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Classification by Type of Product</h2>
    <ul>
      <li><strong>Grain crops</strong> — grown for their seeds. Examples: rice, maize, wheat, sorghum</li>
      <li><strong>Root and tuber crops</strong> — grown for their underground storage organs. Examples: sweet potato, cassava, taro, yam</li>
      <li><strong>Leaf and stem vegetables</strong> — grown for leaves or stems. Examples: cabbage, spinach, kaukau greens, sugarcane</li>
      <li><strong>Fruit vegetables</strong> — grown for their fruit. Examples: tomato, pumpkin, cucumber, pawpaw</li>
      <li><strong>Legumes</strong> — grown for protein-rich seeds or pods. Examples: beans, peas, peanuts</li>
      <li><strong>Industrial/cash crops</strong> — grown for processing and export. Examples: coffee, cocoa, oil palm, rubber</li>
    </ul>
  </div>`,
  keyTerms: [
    {word:'Cultivar / Variety', def:'A plant variety that has been selected and maintained for specific desirable characteristics'},
    {word:'Upland crop', def:'A crop grown on well-drained, non-flooded land'},
    {word:'Lowland/wetland crop', def:'A crop grown in low-lying areas that can be flooded, such as rice'},
    {word:'Legume', def:'A crop that produces seeds in pods and has bacteria on its roots that fix nitrogen from the air into the soil'},
    {word:'Cash crop', def:'A crop grown specifically for sale or export, not just for family consumption'},
  ],
  summary: [
    'Crops can be classified by growing cycle: annual (one season), biennial (two seasons), or perennial (many years)',
    'Within each crop, varieties differ in characteristics suited to specific environments or uses',
    'Classification by season distinguishes wet season, dry season, and year-round crops',
    'Classification by land type includes upland, lowland, highland, and coastal crops',
    'Classification by product type covers grains, root crops, vegetables, fruits, legumes, and cash crops'
  ],
  quiz: [
    {q:'Coffee in Papua New Guinea is an example of which type of crop by growing cycle?', opts:['Annual','Biennial','Perennial','Seasonal'], ans:2},
    {q:'Sweet potato is classified as which type of crop by product type?', opts:['Grain crop','Leaf vegetable','Root and tuber crop','Legume'], ans:2},
    {q:'Which type of crop is grown in low-lying flooded areas?', opts:['Upland crop','Lowland/wetland crop','Highland crop','Cash crop'], ans:1},
    {q:'What is a cultivar?', opts:['A large commercial farm','A plant variety selected for specific desirable characteristics','A type of soil testing','A method of irrigation'], ans:1},
    {q:'Arabica and Robusta are varieties of which crop?', opts:['Cocoa','Oil palm','Coffee','Coconut'], ans:2},
  ]
},

/* ─── GRADE 10 STRAND 5: AGRIBUSINESS ─────────────────────── */

'g10-agribusiness-risk': {
  title: 'Managing Risk in Agribusiness',
  strand: 'Strand 5: Agribusiness · Unit 1', grade: 10, icon: '⚠️',
  lessons: ['Sources of Risk','Importance of Risk Management','Risk Management Strategies'],
  currentLesson: 0,
  objectives: [
    'Identify the sources of risk and uncertainty in farming businesses',
    'Explain why risk management is important in agribusiness',
    'Describe strategies used to manage and reduce agricultural risk'
  ],
  content: `
  <div class="lesson-section">
    <h2>What is Risk in Agribusiness?</h2>
    <p>In any business, <strong>risk</strong> is the possibility that things will not go as planned and that money will be lost. Agribusiness faces particularly high levels of risk because farmers depend on weather, living organisms, and unpredictable market prices — all of which are largely outside their control.</p>
  </div>
  <div class="lesson-section">
    <h2>Sources of Risk in Agribusiness</h2>
    <ul>
      <li><strong>Production risk</strong> — the risk that crops or animals will fail to produce expected yields due to weather (drought, flood, frost), pests, disease, or poor management. This is the most common risk in PNG agriculture.</li>
      <li><strong>Price/market risk</strong> — the risk that prices will fall after the farmer has already planted and invested in a crop. Global commodity prices for coffee and cocoa can drop significantly.</li>
      <li><strong>Financial risk</strong> — the risk of not being able to repay loans or cover operating costs if income falls short. Many smallholder farmers in PNG have limited access to credit.</li>
      <li><strong>Human risk</strong> — illness, death, or departure of key people in the business can disrupt production and management</li>
      <li><strong>Institutional risk</strong> — changes in government policy, land tenure disputes, or unreliable infrastructure (roads, electricity) that affect the business</li>
      <li><strong>Environmental/climate risk</strong> — increasingly severe weather events, sea level rise, and changing rainfall patterns due to climate change</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Why Risk Management is Important</h2>
    <p>Without managing risk, agribusinesses can:</p>
    <ul>
      <li>Lose their entire investment in a single bad season</li>
      <li>Fail to repay loans and become indebted</li>
      <li>Be forced to abandon farming permanently</li>
      <li>Leave families without food or income</li>
    </ul>
    <p>Effective risk management does not eliminate risk — it reduces the impact of bad outcomes so the business can survive and recover.</p>
  </div>
  <div class="lesson-section">
    <h2>Risk Management Strategies</h2>
    <ul>
      <li><strong>Diversification</strong> — growing multiple crops or combining crops with livestock so that if one enterprise fails, others can compensate. "Don't put all your eggs in one basket."</li>
      <li><strong>Savings</strong> — maintaining financial reserves to cover costs during bad seasons</li>
      <li><strong>Crop insurance</strong> — paying a premium in good years so that losses are partially covered in bad years (limited availability in PNG)</li>
      <li><strong>Improved crop varieties</strong> — using drought-tolerant, disease-resistant varieties that reduce production risk</li>
      <li><strong>Irrigation</strong> — reducing dependence on unreliable rainfall</li>
      <li><strong>Contract farming</strong> — agreeing in advance on a buyer and price for a crop, reducing market risk</li>
      <li><strong>Market information</strong> — monitoring market prices and selling when prices are favourable rather than immediately after harvest (when many farmers sell and prices are lowest)</li>
      <li><strong>Cooperatives</strong> — joining a farmer group or cooperative gives individual farmers more bargaining power with buyers and access to shared resources</li>
    </ul>
    <div class="info-box"><strong>🇵🇬 PNG Example:</strong> Coffee farmers in the Highlands face significant price risk because global coffee prices are set in New York and London. Joining a cooperative and obtaining Fair Trade or organic certification are strategies that can secure better, more stable prices.</div>
  </div>`,
  keyTerms: [
    {word:'Risk', def:'The possibility that actual outcomes will differ from planned outcomes, potentially resulting in financial loss'},
    {word:'Diversification', def:'Spreading production across multiple crops or enterprises so that failure of one does not destroy the whole business'},
    {word:'Contract farming', def:'An arrangement where a buyer agrees in advance to purchase a farmer\'s crop at a set price, reducing market risk'},
    {word:'Cooperative', def:'An organisation owned and operated by a group of farmers who work together to buy inputs, process products, or access markets'},
    {word:'Production risk', def:'The risk that crops or animals will fail to produce expected yields due to weather, pests, disease, or poor management'},
  ],
  summary: [
    'Risk in agribusiness includes production, price, financial, human, institutional, and environmental risk',
    'Production risk (crop failure from weather or pests) is the most common risk in Papua New Guinea',
    'Risk management does not eliminate risk — it reduces the impact so the business can survive',
    'Key strategies include diversification, savings, improved varieties, irrigation, contract farming, and cooperatives',
    'Joining a cooperative can help individual smallholder farmers access better prices and shared resources'
  ],
  quiz: [
    {q:'What is production risk in agribusiness?', opts:['The risk of buying too many inputs','The risk that crops or animals fail to produce expected yields due to weather, pests, or disease','The risk of market prices rising too high','The risk of a business partner leaving the farm'], ans:1},
    {q:'What does diversification mean in risk management?', opts:['Investing all resources in one high-value crop','Spreading production across multiple crops or enterprises','Selling products in multiple markets only','Hiring more workers for peak seasons'], ans:1},
    {q:'What is a cooperative?', opts:['A government agricultural agency','An organisation owned and run by a group of farmers working together','A type of crop insurance scheme','A contract between a farmer and a supermarket'], ans:1},
    {q:'Why do coffee farmers in PNG face significant price risk?', opts:['Coffee is only grown in one area','Global coffee prices are set on international markets far outside farmers\' control','PNG coffee has poor quality','Coffee is always in low demand locally'], ans:1},
    {q:'Which risk management strategy involves agreeing on a buyer and price BEFORE planting?', opts:['Crop insurance','Savings','Contract farming','Diversification'], ans:2},
  ]
},

'g10-agribusiness-marketing': {
  title: 'Agribusiness Communication & Marketing',
  strand: 'Strand 5: Agribusiness · Unit 2', grade: 10, icon: '📣',
  lessons: ['Agricultural Markets','Marketing Principles','Sales Strategies & the Sales Process'],
  currentLesson: 0,
  objectives: [
    'Describe the types of markets related to agribusiness',
    'Explain key marketing principles for agricultural products',
    'Describe the components of the sales process in agribusiness'
  ],
  content: `
  <div class="lesson-section">
    <h2>Types of Agricultural Markets</h2>
    <p>A <strong>market</strong> is any place or mechanism where buyers and sellers meet to exchange goods and services. Agricultural markets can be:</p>
    <ul>
      <li><strong>Local markets</strong> — village markets, town markets, roadside stalls. Most smallholder farmers in PNG sell here. Prices are local and vary daily.</li>
      <li><strong>Wholesale markets</strong> — where traders buy large quantities from farmers to sell on to retailers or processors. Examples: the Lae and Port Moresby produce markets.</li>
      <li><strong>Supermarkets / retail</strong> — formal retail where products must meet quality and packaging standards</li>
      <li><strong>Export markets</strong> — selling agricultural products to buyers in other countries. Requires quality certification, correct packaging, and compliance with import regulations</li>
      <li><strong>Online markets</strong> — selling via social media, websites, or digital platforms. Growing in PNG particularly for handicrafts and specialty food products</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>The 4 Ps of Marketing</h2>
    <p>Marketing is about getting the right product to the right customer at the right price through the right channels. The classic framework is the <strong>4 Ps</strong>:</p>
    <ul>
      <li><strong>Product</strong> — what are you selling? What makes it valuable? Quality, size, freshness, variety all matter.</li>
      <li><strong>Price</strong> — how much will you charge? Price must cover costs, be competitive, and reflect value</li>
      <li><strong>Place</strong> — where and how will you sell? Local market, cooperative, wholesale buyer, or export?</li>
      <li><strong>Promotion</strong> — how will people know about your product? Word of mouth, signs, social media, or radio advertising?</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Sales Strategies for Agribusiness</h2>
    <ul>
      <li><strong>Timing of sales</strong> — avoid selling immediately after harvest when all farmers are selling and prices are lowest. Store where possible and sell when prices recover</li>
      <li><strong>Value-adding</strong> — processing raw products before selling increases their value. Turning fresh cocoa into fermented, dried beans increases the price; packaging fresh vegetables attractively increases perceived value</li>
      <li><strong>Building relationships with buyers</strong> — reliable, consistent supply builds trust with buyers and can secure better ongoing prices</li>
      <li><strong>Collective selling</strong> — selling as a group through a cooperative gives farmers more bargaining power</li>
      <li><strong>Quality standards</strong> — maintaining quality (grading, proper handling, clean presentation) commands better prices</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>The Sales Process</h2>
    <p>The sales process describes the steps from identifying a potential customer to completing a sale:</p>
    <ol>
      <li><strong>Prospecting</strong> — identifying potential buyers (market traders, processors, export buyers)</li>
      <li><strong>Preparation</strong> — preparing the product (grading, packaging, calculating minimum acceptable price)</li>
      <li><strong>Approach</strong> — making initial contact with potential buyers and building rapport</li>
      <li><strong>Presentation</strong> — showing and describing the product, emphasising its quality and value</li>
      <li><strong>Handling objections</strong> — responding to concerns about price, quality, or quantity</li>
      <li><strong>Closing the sale</strong> — agreeing on a price and quantity and completing the transaction</li>
      <li><strong>Follow-up</strong> — checking that the buyer is satisfied and maintaining the relationship for future sales</li>
    </ol>
  </div>`,
  keyTerms: [
    {word:'Marketing', def:'The activities involved in promoting and selling a product — from identifying customers to completing the sale'},
    {word:'Value-adding', def:'Processing or improving a raw agricultural product to increase its market value before selling'},
    {word:'The 4 Ps', def:'A marketing framework: Product, Price, Place, and Promotion'},
    {word:'Wholesale market', def:'A market where large quantities are bought and sold between traders rather than directly to consumers'},
    {word:'Prospecting', def:'The first step of the sales process — identifying and approaching potential buyers'},
  ],
  summary: [
    'Agricultural markets range from local village markets to export markets — each has different requirements',
    'The 4 Ps of marketing are Product, Price, Place, and Promotion',
    'Timing sales, value-adding, building buyer relationships, and maintaining quality all improve sales outcomes',
    'Collective selling through cooperatives gives individual farmers more market power',
    'The sales process: prospecting → preparation → approach → presentation → handling objections → closing → follow-up'
  ],
  quiz: [
    {q:'What are the 4 Ps of marketing?', opts:['Produce, Price, Profit, Promotion','Product, Price, Place, Promotion','Product, Process, Price, People','Profit, Place, Price, Production'], ans:1},
    {q:'What is value-adding in agribusiness?', opts:['Planting more crops to increase total yield','Processing or improving a raw product to increase its market value before selling','Recruiting more workers for the farm','Applying more fertiliser to improve quality'], ans:1},
    {q:'Why should farmers avoid selling immediately after harvest?', opts:['Their products are not fully mature at harvest','All farmers sell at the same time, pushing prices down','Export markets are not open immediately after harvest','Buyers only operate outside of harvest season'], ans:1},
    {q:'What is the first step in the sales process?', opts:['Closing the sale','Handling objections','Prospecting — identifying potential buyers','Product presentation'], ans:2},
    {q:'Which market requires quality certification and compliance with import regulations?', opts:['Local village market','Online social media market','Export market','Wholesale market'], ans:2},
  ]
},

'g9-animal-anatomy': {
  title: 'Anatomy of Farm Animals',
  strand: 'Strand 2: Animals · Unit 2', grade: 9, icon: '🐄',
  lessons: ['Monogastric vs Polygastric Digestive Systems','Anatomy & Body Systems','Skeletal & Muscular Systems','Reproductive Systems Overview'],
  currentLesson: 0,
  objectives: [
    'Identify the body systems of farm animals and explain their functions',
    'Compare monogastric and polygastric digestive systems',
    'Describe how skeletal, muscular, and reproductive systems differ between animal types'
  ],
  content: `
  <div class="lesson-section">
    <h2>Monogastric vs Polygastric (Ruminant) Digestive Systems</h2>
    <h3>Monogastric Animals (Simple Stomach)</h3>
    <p><strong>Monogastric</strong> animals have a single-chambered stomach. Digestion occurs mainly through chemical processes. Examples: pigs, chickens, rabbits.</p>
    <p><strong>Digestive pathway:</strong> Mouth → Oesophagus → Stomach → Small intestine → Large intestine → Rectum</p>
    <ul>
      <li>Quick passage through digestive tract (12-24 hours)</li>
      <li>Can digest grains, vegetables, and meat</li>
      <li>Less efficient at extracting nutrients from fibrous plants</li>
      <li>Require more concentrated feed</li>
    </ul>
    <h3>Polygastric Animals (Ruminants)</h3>
    <p><strong>Polygastric</strong> or <strong>ruminant</strong> animals have a four-chambered stomach: rumen, reticulum, omasum, and abomasum. Examples: cattle, sheep, goats.</p>
    <p><strong>Process: </strong> Food enters the rumen where it\'s broken down by microorganisms, then returns to mouth for further chewing (chewing cud), then progresses through remaining chambers.</p>
    <ul>
      <li>Slow digestion (48-72 hours) allows maximum nutrient extraction</li>
      <li>Excellent at digesting fibrous plant material (grass, hay)</li>
      <li>Microorganisms synthesize vitamins and amino acids</li>
      <li>More efficient at converting pasture to meat/milk</li>
    </ul>
    <div class="info-box"><strong>💡 Key Difference:</strong> Monogastrics need grain supplements; ruminants thrive on grass and hay. This affects feed costs and farm management.</div>
  </div>
  <div class="lesson-section">
    <h2>Skeletal System</h2>
    <p>The skeleton provides structure, protects organs, and works with muscles for movement.</p>
    <ul>
      <li><strong>Skull</strong> — protects the brain</li>
      <li><strong>Spine (vertebral column)</strong> — supports the body and protects the spinal cord</li>
      <li><strong>Ribs</strong> — protect the heart and lungs</li>
      <li><strong>Limb bones</strong> — support body weight and enable movement</li>
      <li><strong>Pelvis</strong> — protects organs and provides attachment for back legs</li>
    </ul>
    <p>In ruminants, the skeleton is generally lighter and more adapted for running. In pigs, the skeleton is heavier and more compact.</p>
  </div>
  <div class="lesson-section">
    <h2>Muscular System</h2>
    <p>Muscles enable movement and heat production. There are three types:</p>
    <ul>
      <li><strong>Skeletal muscle</strong> — voluntary muscles attached to bones; responsible for movement</li>
      <li><strong>Smooth muscle</strong> — involuntary muscles in digestive and reproductive organs</li>
      <li><strong>Cardiac muscle</strong> — heart muscle; pumps blood</li>
    </ul>
    <p>Muscle quality and development depend on genetics, nutrition, and exercise. Proper feeding and management improve meat quality.</p>
  </div>
  <div class="lesson-section">
    <h2>Reproductive System Basics</h2>
    <h3>Female Reproductive System</h3>
    <ul>
      <li><strong>Ovaries</strong> — produce eggs (ova) and hormones</li>
      <li><strong>Oviducts</strong> — transport eggs from ovaries</li>
      <li><strong>Uterus</strong> — where embryo develops</li>
      <li><strong>Vagina</strong> — reproductive opening</li>
    </ul>
    <h3>Male Reproductive System</h3>
    <ul>
      <li><strong>Testicles</strong> — produce sperm and hormones</li>
      <li><strong>Epididymis</strong> — stores sperm</li>
      <li><strong>Vas deferens</strong> — transports sperm</li>
      <li><strong>Penis</strong> — delivers sperm during mating</li>
    </ul>
    <p>Understanding reproductive anatomy helps farmers manage breeding, recognize health issues, and optimize production.</p>
  </div>`,
  keyTerms: [
    {word:'Monogastric', def:'An animal with a single-chambered stomach — pig, chicken, or rabbit'},
    {word:'Polygastric (Ruminant)', def:'An animal with a multi-chambered stomach designed to digest fibrous plant material — cattle, sheep, goat'},
    {word:'Rumen', def:'The first chamber of a ruminant stomach where microbial fermentation occurs'},
    {word:'Chewing cud', def:'The process where ruminants regurgitate and re-chew food for more complete digestion'},
    {word:'Anatomy', def:'The structure of a body or body part'},
  ],
  summary: [
    'Monogastric animals have one stomach chamber; ruminants have four chambers',
    'Monogastrics need concentrated feed; ruminants efficiently digest grass and hay',
    'The skeletal system provides structure and protection; muscles enable movement',
    'Reproductive systems differ between males and females in structure and function',
    'Understanding animal anatomy helps farmers manage nutrition and health'
  ],
  quiz: [
    {q:'Which animals are monogastric?', opts:['Cattle and sheep','Pigs and chickens','Goats and buffaloes','Horses and llamas'], ans:1},
    {q:'How many chambers does a ruminant stomach have?', opts:['One','Two','Four','Six'], ans:2},
    {q:'What is chewing cud?', opts:['The first chewing of food in the mouth','Regurgitation and re-chewing of food from the rumen','Swallowing food without chewing','Chewing inedible material'], ans:1},
    {q:'Why are ruminants efficient at digesting grass?', opts:['They have larger mouths','Microorganisms in the rumen break down fibrous material','Grass is easier to digest than grain','They have longer intestines'], ans:1},
    {q:'Which body system provides structure and protects organs?', opts:['Muscular system','Respiratory system','Skeletal system','Nervous system'], ans:2},
  ]
},

'g9-animal-farming': {
  title: 'Animal Farming Practices & Management',
  strand: 'Strand 2: Animals · Unit 3', grade: 9, icon: '🏠',
  lessons: ['Housing Systems','Feeding & Nutrition','Health Management','Breeding & Reproduction'],
  currentLesson: 0,
  objectives: [
    'Explain different animal farming systems and their characteristics',
    'Describe proper housing, feeding, and health management for farm animals',
    'Analyse the role of breeding and reproduction in animal production'
  ],
  content: `
  <div class="lesson-section">
    <h2>Animal Production Systems</h2>
    <p>Farm animals can be managed using different systems, each with distinct characteristics:</p>
    <h3>Extensive Systems</h3>
    <ul>
      <li>Animals graze freely on large pastures with minimal human input</li>
      <li>Low input costs but low productivity</li>
      <li>Animals roam and find their own forage</li>
      <li>Suitable for cattle and sheep in areas with abundant land</li>
      <li>Common in pastoral communities and rangeland areas</li>
    </ul>
    <h3>Semi-Intensive Systems</h3>
    <ul>
      <li>Animals kept in enclosures but also allowed to graze</li>
      <li>Supplementary feeding with grains and concentrates</li>
      <li>Moderate capital investment required</li>
      <li>Better control over animal health and nutrition</li>
      <li>Higher productivity than extensive but lower than intensive</li>
    </ul>
    <h3>Intensive Systems</h3>
    <ul>
      <li>Animals confined in close housing (pens, cages, sheds)</li>
      <li>Complete diet provided (no grazing)</li>
      <li>High input costs (feed, labour, facilities)</li>
      <li>High productivity and meat/egg/milk output</li>
      <li>Requires careful management of waste and disease</li>
      <li>Common for poultry and pig farming</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Housing Requirements</h2>
    <p>Proper housing protects animals from weather, predators, and disease:</p>
    <ul>
      <li><strong>Adequate space</strong> — prevents stress and disease spread</li>
      <li><strong>Good ventilation</strong> — removes ammonia and moisture</li>
      <li><strong>Clean bedding</strong> — improves hygiene and animal comfort</li>
      <li><strong>Feeding and drinking areas</strong> — placed separate from toilets</li>
      <li><strong>Temperature control</strong> — shelter from extreme heat and cold</li>
      <li><strong>Easy to clean</strong> — reduces disease and parasites</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Feeding & Nutrition</h2>
    <p>Animals require balanced diets with proper nutrients:</p>
    <ul>
      <li><strong>Protein</strong> — for growth and muscle development</li>
      <li><strong>Energy</strong> — from carbohydrates and fats</li>
      <li><strong>Minerals</strong> — calcium, phosphorus for bones and milk production</li>
      <li><strong>Vitamins</strong> — for immunity and health</li>
      <li><strong>Water</strong> — essential for all bodily functions</li>
    </ul>
    <p>Feed types vary by animal: ruminants eat hay and grass; monogastrics need grains and protein sources.</p>
  </div>
  <div class="lesson-section">
    <h2>Health Management</h2>
    <p>Preventive care reduces disease and improves productivity:</p>
    <ul>
      <li><strong>Vaccination</strong> — prevents infectious diseases</li>
      <li><strong>Parasite control</strong> — regular worming and pest management</li>
      <li><strong>Hygiene</strong> — clean housing and feeding equipment reduce disease transmission</li>
      <li><strong>Veterinary care</strong> — prompt treatment of illness</li>
      <li><strong>Record keeping</strong> — tracks health problems and treatments</li>
      <li><strong>Isolation of sick animals</strong> — prevents disease spread</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Breeding & Reproduction</h2>
    <p>Selective breeding improves animal productivity:</p>
    <ul>
      <li><strong>Select superior animals</strong> — those with desirable traits (growth, milk production, disease resistance)</li>
      <li><strong>Understand reproductive cycles</strong> — time breeding during fertile periods (oestrus)</li>
      <li><strong>Avoid inbreeding</strong> — which reduces genetic diversity and health</li>
      <li><strong>Record genetics</strong> — keep track of parentage and traits</li>
      <li><strong>Improve herd quality</strong> — over generations through selective mating</li>
    </ul>
  </div>`,
  keyTerms: [
    {word:'Extensive system', def:'A farming system where animals graze freely with minimal human input'},
    {word:'Intensive system', def:'A farming system where animals are confined and given complete diets — high input and output'},
    {word:'Oestrus', def:'The fertile period in female animals when they are ready to breed'},
    {word:'Inbreeding', def:'Breeding related animals — can reduce genetic diversity and health'},
    {word:'Selective breeding', def:'Choosing animals with desirable traits to produce offspring with improved characteristics'},
  ],
  summary: [
    'Three main farming systems exist: extensive (free grazing), semi-intensive (mixed), and intensive (confined)',
    'Proper housing provides shelter, ventilation, space, and clean conditions',
    'Animals need balanced nutrition with protein, energy, minerals, and vitamins',
    'Preventive health care reduces disease through vaccination, hygiene, and parasite control',
    'Selective breeding improves productivity over generations by choosing superior animals'
  ],
  quiz: [
    {q:'Which system has the lowest input costs?', opts:['Intensive','Semi-intensive','Extensive','Commercial'], ans:2},
    {q:'What is oestrus?', opts:['A type of animal feed','The fertile breeding period in females','A disease in cattle','A housing structure'], ans:1},
    {q:'Which nutrient is needed for muscle development?', opts:['Carbohydrates','Protein','Vitamins','Water'], ans:1},
    {q:'What is inbreeding?', opts:['Feeding breeding animals special diets','Breeding related animals together','Separating males and females','Record-keeping for genetics'], ans:1},
    {q:'Why is vaccination important?', opts:['It improves feed efficiency','It prevents infectious diseases','It increases growth rate','It improves meat quality'], ans:1},
  ]
},

'g9-poultry-types': {
  title: 'Types of Poultry & Their Behaviour',
  strand: 'Strand 2: Animals · Unit 4', grade: 9, icon: '🐔',
  lessons: ['Domesticated Poultry Species','Poultry Breeds & Characteristics','Poultry Behaviour','Purpose & Selection'],
  currentLesson: 0,
  objectives: [
    'Identify different types of domesticated poultry and their characteristics',
    'Describe poultry behaviour and welfare requirements',
    'Analyse how to select poultry breeds for specific purposes'
  ],
  content: `
  <div class="lesson-section">
    <h2>Types of Domesticated Poultry</h2>
    <p><strong>Poultry</strong> refers to domesticated birds raised for meat, eggs, or feathers. Main types include:</p>
    <h3>Chickens (Fowl)</h3>
    <ul>
      <li>Most commonly raised poultry worldwide</li>
      <li>Males are roosters; females are hens</li>
      <li>Can be raised for eggs, meat, or both</li>
      <li>Relatively easy to manage and fast to mature (6-8 weeks for meat)</li>
      <li>Excellent feed conversion (1-2 kg feed per 1 kg meat)</li>
    </ul>
    <h3>Ducks</h3>
    <ul>
      <li>Water birds requiring access to water for health and wellbeing</li>
      <li>Lay blue or brown eggs</li>
      <li>Meat is fattier and richer in flavour than chicken</li>
      <li>Hardier than chickens; can convert poor quality feeds</li>
      <li>Excellent for small-scale farming and marshy areas</li>
    </ul>
    <h3>Geese</h3>
    <ul>
      <li>Larger than ducks; require more space</li>
      <li>Excellent at converting grass to meat</li>
      <li>Good mothers; broody and protective</li>
      <li>Long lifespan (15-20 years); reproductive peak at 2-3 years</li>
      <li>Produce high-quality meat and down feathers</li>
    </ul>
    <h3>Turkeys</h3>
    <ul>
      <li>Large, meat-type birds</li>
      <li>Longer growing period (16-20 weeks) than chickens</li>
      <li>Popular in Western countries for special occasions</li>
      <li>Less common in Papua New Guinea due to management demands</li>
    </ul>
    <h3>Guinea fowls</h3>
    <ul>
      <li>Small birds raised for meat</li>
      <li>Better disease resistance than chickens</li>
      <li>Hardy and good foragers</li>
      <li>Meat is considered a delicacy in some cultures</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Poultry Breeds & Characteristics</h2>
    <h3>Meat Breeds (Broilers)</h3>
    <ul>
      <li>Fast-growing and heavy (2-2.5 kg at 6-8 weeks)</li>
      <li>Examples: Cornish Cross, Cobb, Ross strains</li>
      <li>Fed specialized commercial diets</li>
      <li>Large breasts and meat yields</li>
    </ul>
    <h3>Egg Breeds (Layers)</h3>
    <ul>
      <li>Light body weight but high egg production (300+ eggs/year)</li>
      <li>Examples: Leghorn, Rhode Island Red, Sussex</li>
      <li>Lower feed intake than broilers</li>
      <li>Productive for 2-3 years before declining</li>
    </ul>
    <h3>Dual-Purpose Breeds</h3>
    <ul>
      <li>Good for both meat and eggs</li>
      <li>Examples: Australorp, Brahma, Wyandotte</li>
      <li>Suited to smallholder farmers with mixed production goals</li>
    </ul>
    <h3>Indigenous/Local Breeds</h3>
    <ul>
      <li>Adapted to local environments</li>
      <li>More disease-resistant and hardy</li>
      <li>Slower growth but tasty meat</li>
      <li>Good foragers; thrive with minimal external inputs</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Poultry Behaviour & Welfare</h2>
    <h3>Natural Behaviours</h3>
    <ul>
      <li><strong>Scratching</strong> — birds search for food and maintain feather condition</li>
      <li><strong>Dust bathing</strong> — maintains feather health and controls parasites</li>
      <li><strong>Roosting</strong> — perching at height for safety during sleep</li>
      <li><strong>Nesting</strong> — hens need quiet, private spaces to lay eggs</li>
      <li><strong>Social hierarchy</strong> — pecking order determines dominance</li>
    </ul>
    <h3>Welfare Requirements</h3>
    <ul>
      <li><strong>Space</strong> — minimum 0.3 m² per bird in cages; 1-1.5 m² in pens</li>
      <li><strong>Perches and roosting bars</strong> — satisfy perching behaviour</li>
      <li><strong>Nesting boxes</strong> — one per 4 birds for layers</li>
      <li><strong>Litter for scratching</strong> — straw, wood shavings, or sand</li>
      <li><strong>Light</strong> — 14-16 hours daily for optimal egg production</li>
      <li><strong>Ventilation</strong> — removes ammonia and moisture</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Selection Based on Purpose</h2>
    <h3>For Egg Production</h3>
    <ul>
      <li>Choose egg breeds: Leghorns, Rhode Island Reds</li>
      <li>Select females (hens) only</li>
      <li>Expect 250-300 eggs per bird per year</li>
      <li>Productive for 2-3 years</li>
    </ul>
    <h3>For Meat Production</h3>
    <ul>
      <li>Choose meat breeds: Cornish Cross, Cobb, Ross</li>
      <li>Rapid growth to 2-2.5 kg in 6-8 weeks</li>
      <li>High feed conversion efficiency</li>
      <li>Market-ready quickly</li>
    </ul>
    <h3>For Small-scale/Village Farming</h3>
    <ul>
      <li>Dual-purpose breeds: Australorp, Wyandotte</li>
      <li>Or indigenous local breeds</li>
      <li>Lower input requirements</li>
      <li>Good foragers; thrive on kitchen scraps and insects</li>
    </ul>
  </div>`,
  keyTerms: [
    {word:'Poultry', def:'Domesticated birds raised for meat, eggs, or feathers — includes chickens, ducks, geese, turkeys'},
    {word:'Broiler', def:'A chicken breed or strain selected for rapid meat production'},
    {word:'Layer', def:'A poultry bird selected for high egg production'},
    {word:'Dual-purpose', def:'A breed suitable for both meat and egg production'},
    {word:'Pecking order', def:'The social hierarchy among poultry determining dominance and access to resources'},
  ],
  summary: [
    'Main poultry types are chickens, ducks, geese, turkeys, and guinea fowls',
    'Meat breeds (broilers) grow fast; egg breeds (layers) produce many eggs',
    'Poultry have natural behaviours like scratching, roosting, and nesting that require accommodation',
    'Welfare needs include adequate space, perches, nesting boxes, litter, light, and ventilation',
    'Breed selection depends on whether the goal is eggs, meat, or small-scale mixed production'
  ],
  quiz: [
    {q:'Which bird is best adapted to wetland areas?', opts:['Chicken','Duck','Turkey','Guinea fowl'], ans:1},
    {q:'How fast do broiler chickens grow to market weight?', opts:['2-3 weeks','6-8 weeks','12 weeks','16 weeks'], ans:1},
    {q:'What is the pecking order?', opts:['The order birds eat at feeding time','The social hierarchy determining dominance','The noise birds make','A disease in poultry'], ans:1},
    {q:'What space is needed per bird in intensive housing?', opts:['0.1 m²','0.3 m²','1.5 m²','3 m²'], ans:1},
    {q:'Which breed is best for small-scale village farming?', opts:['Leghorn','Cornish Cross','Australorp','Commercial hybrid'], ans:2},
  ]
},

'g9-poultry-farming': {
  title: 'Poultry Farming Principles & Systems',
  strand: 'Strand 2: Animals · Unit 5', grade: 9, icon: '🥚',
  lessons: ['Free-Range Systems','Semi-Intensive Systems','Intensive Systems','Management Practices'],
  currentLesson: 0,
  objectives: [
    'Describe different poultry production systems and their characteristics',
    'Explain management practices for successful poultry farming',
    'Compare advantages and disadvantages of each system'
  ],
  content: `
  <div class="lesson-section">
    <h2>Free-Range (Extensive) Systems</h2>
    <p>Birds have unlimited access to outdoor areas and grazing land.</p>
    <h3>Characteristics</h3>
    <ul>
      <li>Birds roam freely to forage for food</li>
      <li>Minimal enclosed housing needed</li>
      <li>Low capital investment</li>
      <li>Low feed costs (birds find insects, worms, plants)</li>
      <li>Lower productivity and egg/meat output</li>
      <li>Higher risk of predation and disease</li>
    </ul>
    <h3>Best for</h3>
    <ul>
      <li>Small-scale village farming</li>
      <li>Subsistence poultry keeping</li>
      <li>Areas with abundant land and good climate</li>
      <li>Producing premium "free-range" products</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Semi-Intensive Systems</h2>
    <p>Birds have both enclosed houses and outdoor pens or runs.</p>
    <h3>Characteristics</h3>
    <ul>
      <li>Birds housed at night for safety and protection</li>
      <li>Outdoor runs (pens) allow some grazing and foraging</li>
      <li>Supplementary feed provided in addition to foraged food</li>
      <li>Moderate capital investment for simple housing</li>
      <li>Medium productivity and lower disease risk than free-range</li>
      <li>Better control over health and nutrition than free-range</li>
    </ul>
    <h3>Best for</h3>
    <ul>
      <li>Small to medium-scale farming</li>
      <li>Balancing productivity with lower input costs</li>
      <li>Areas with predation risk</li>
      <li>Farmers wanting good balance of profit and sustainability</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Intensive Systems</h2>
    <p>Birds are confined in buildings with full environmental control.</p>
    <h3>Battery Cage System (for eggs)</h3>
    <ul>
      <li>Birds housed in small cages (multiple birds per cage)</li>
      <li>Automated feeding, watering, egg collection</li>
      <li>Very high productivity (300+ eggs per bird per year)</li>
      <li>Concentrated waste management challenges</li>
      <li>Controversial due to animal welfare concerns</li>
    </ul>
    <h3>Deep Litter System (for meat and eggs)</h3>
    <ul>
      <li>Birds on bedding material (wood shavings, straw) on floor</li>
      <li>Easier to manage than cages; better welfare</li>
      <li>Requires larger buildings and more labour</li>
      <li>Bedding accumulates litter — ammonia management important</li>
    </ul>
    <h3>Controlled Environment Features</h3>
    <ul>
      <li><strong>Temperature control</strong> — heating in cold, ventilation in heat</li>
      <li><strong>Lighting control</strong> — 14-16 hours daily for layers</li>
      <li><strong>Automatic feeding and watering</strong> — ensures consistent supply</li>
      <li><strong>Biosecurity</strong> — controlled access prevents disease entry</li>
      <li><strong>Waste management</strong> — manure collected regularly</li>
    </ul>
    <h3>Best for</h3>
    <ul>
      <li>Commercial poultry production</li>
      <li>Areas with high land costs</li>
      <li>Climate extremes (too hot or cold)</li>
      <li>Maximum productivity and profitability</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Management Practices Across Systems</h2>
    <h3>Housing & Environment</h3>
    <ul>
      <li>Adequate space: 1-2 birds per m² for layers; 3-4 birds per m² for broilers</li>
      <li>Proper ventilation to remove ammonia and moisture</li>
      <li>Temperature: 18-24°C optimal; broilers slightly warmer</li>
      <li>Light: 14-16 hours daily for layers; 23-24 hours for broilers</li>
      <li>Roosting bars and nesting boxes for comfort and laying</li>
    </ul>
    <h3>Feeding & Nutrition</h3>
    <ul>
      <li><strong>Starter feed (0-4 weeks)</strong> — high protein (20-24%) for growth</li>
      <li><strong>Grower feed (4-16 weeks)</strong> — medium protein (16-18%) for continued growth</li>
      <li><strong>Layer feed (for hens)</strong> — balanced with calcium for egg shell quality</li>
      <li><strong>Finisher feed (broilers only)</strong> — lower fibre for rapid weight gain</li>
      <li>Fresh water always available</li>
    </ul>
    <h3>Health & Biosecurity</h3>
    <ul>
      <li>Vaccination against common diseases (Newcastle, Gumboro)</li>
      <li>Regular parasite control (worms, mites, lice)</li>
      <li>Quarantine new birds before adding to flock</li>
      <li>Strict hygiene: clean feeders, waterers, and housing</li>
      <li>Isolation of sick or injured birds</li>
      <li>Regular bird counts to detect missing birds or mortality</li>
    </ul>
    <h3>Record Keeping</h3>
    <ul>
      <li>Daily mortality records</li>
      <li>Feed consumption — indicates health problems if drops</li>
      <li>Egg production rates and quality</li>
      <li>Health treatments and vaccinations</li>
      <li>Income and expenses for profitability analysis</li>
    </ul>
  </div>`,
  keyTerms: [
    {word:'Free-range', def:'A system where poultry have unlimited outdoor access to forage for food'},
    {word:'Semi-intensive', def:'A system combining indoor housing with outdoor pens or runs'},
    {word:'Intensive', def:'A confined system with complete environmental control — highest productivity'},
    {word:'Biosecurity', def:'Measures to prevent disease entry and spread through hygiene and controlled access'},
    {word:'Brooding', def:'Providing warmth and care for young birds — using heat lamps or broody hens'},
  ],
  summary: [
    'Free-range systems have low costs but lower productivity; best for subsistence farming',
    'Semi-intensive systems balance productivity with sustainability; suitable for small-scale commercial farming',
    'Intensive systems maximize output but require high investment and careful management',
    'Proper housing provides space, ventilation, temperature control, and lighting for bird welfare',
    'Nutrition, health management, and record-keeping are essential for successful poultry farming'
  ],
  quiz: [
    {q:'Which system has the lowest capital investment?', opts:['Intensive','Semi-intensive','Free-range','Cage system'], ans:2},
    {q:'What is the optimal temperature range for poultry housing?', opts:['10-15°C','18-24°C','25-30°C','32-35°C'], ans:1},
    {q:'How many hours of light daily are needed for optimal layer production?', opts:['8 hours','12 hours','14-16 hours','24 hours'], ans:2},
    {q:'What is biosecurity in poultry farming?', opts:['Selling birds at market','Measures to prevent disease entry and spread','Building strong house structures','Keeping records of production'], ans:1},
    {q:'Which management system allows birds both indoor housing and outdoor grazing?', opts:['Battery cages','Free-range only','Semi-intensive','Deep litter'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/digital-agriculture/en/',label:'FAO Digital Agriculture',desc:'How technology is applied in modern agriculture — tools, mechanisation, and smart farming.'},
  ]
},

'g9-pomology-olericulture': {
  title: 'Plant Farming Practices — Pomology & Olericulture',
  strand: 'Strand 1: Crops · Unit 6', grade: 9, icon: '🌿',
  lessons: ['Types of Horticulture Industry','Pomology — Fruit Crop Management','Olericulture — Vegetable Crop Management','Arboriculture & Landscaping Horticulture'],
  currentLesson: 0,
  objectives: [
    'Identify, describe, and differentiate the major areas of the horticulture industry: Pomology, Olericulture, and Ornamental Horticulture',
    'Analyse how to cultivate, process, preserve, market, and regulate pomology and olericulture plant products',
    'Describe the management systems and practices of arboriculture and landscaping horticulture'
  ],
  content: `
  <div class="lesson-section">
    <h2>The Horticulture Industry</h2>
    <p>A direct relationship exists between horticulture and science. The area of science most closely associated with horticulture is <strong>botany</strong> — the study of plants and plant processes. The field of science that deals with the cultivation of horticultural plants is known as <strong>horticulture science</strong>.</p>
    <p>The horticulture industry is the contribution of scientific, technological and production activities that ensure the satisfaction of the consumer. The horticulture industry can be divided into three areas: <strong>pomology</strong>, <strong>olericulture</strong>, and <strong>ornamental horticulture</strong>. Each area is unique and includes many career opportunities.</p>
  </div>
  <div class="lesson-section">
    <h2>Pomology</h2>
    <p><strong>Pomology</strong> is the planting, harvesting, sorting, processing and marketing of fruit and nut crops. Fruit crops include large and small fruits. Examples of large fruits are peaches, apples and pears. Small fruits include strawberries, raspberries and blueberries. Almonds, pecans and walnuts are popular nut crops.</p>
    <h3>Management Systems and Practices of Pomology</h3>
    <ol>
      <li><strong>Cultivation</strong> — site selection, planting and spacing, pruning. Fruit trees require 6–8 hours of sunlight per day. Avoid sites shaded by large trees. Proper spacing prevents plants from competing for nutrients and water.</li>
      <li><strong>Soil management</strong> — irrigation and fertilization. The soil condition and types of nutrients available must be assessed.</li>
      <li><strong>Crop enhancement</strong> — pollination and thinning. Introduced varieties have higher yields than common varieties.</li>
      <li><strong>Harvesting and packing</strong> — the proper time to remove fruit is governed by whether the product will be sold and consumed within hours, or stored for weeks, months or even a year. Most fruits are harvested as close as possible to the time they are eaten.</li>
    </ol>
    <div class="info-box"><strong>🌳 Nursery:</strong> The type of nursery depends on the type of tree crop. Most fruit trees use poly bag nursery before being planted into the field.</div>
  </div>
  <div class="lesson-section">
    <h2>Olericulture</h2>
    <p><strong>Olericulture</strong> is the area of horticulture that involves the production of vegetable food crops. Olericulture includes the planting, harvesting, storing, processing and marketing of vegetable crops. Sweet corn, tomatoes, snap beans, and lettuce are examples of vegetable crops.</p>
    <h3>Management Systems and Practices of Olericulture</h3>
    <ol>
      <li><strong>Cultivar selection</strong> — choosing the right variety of vegetable for the local environment and intended use</li>
      <li><strong>Seedbed preparation</strong> — the soil must be well-drained loamy soil, ploughed and incorporated with manure or compost. Nursery types include seedbeds, seed trays, and polybags.</li>
      <li><strong>Transplanting</strong> — transferring crops from the nursery to the main food garden at the correct spacing (distance between plants and distance between rows)</li>
      <li><strong>Fertilizer application</strong> — applying appropriate nutrients to support vegetable growth</li>
      <li><strong>Management practices</strong> — watering, weeding, staking, fertilizer application, and disease and pest control</li>
      <li><strong>Pest and disease management</strong> — regular monitoring and treatment to protect crops</li>
      <li><strong>Harvesting</strong> — depends on the maturity of the crop</li>
    </ol>
    <h3>Processing Vegetables</h3>
    <p>Processed vegetables include canned, frozen, dehydrated, and pickled products. Vegetables for canning and freezing usually include small size, high quality and uniformity. Most vegetables have different maturity dates which are required for a constant supply of raw material. The processed vegetable should have a taste, odour and appearance comparable to the fresh product and retain its nutritive value.</p>
  </div>
  <div class="lesson-section">
    <h2>Ornamental Horticulture</h2>
    <p>The growth and use of plants for their beauty is the area of horticulture known as <strong>Ornamental Horticulture</strong>. It is divided into two categories:</p>
    <ul>
      <li><strong>Floriculture</strong> — the area of ornamental horticulture associated with the production and use of flowers, potted plants and annual bedding plants. It includes the use of floral products in the florist's trade.</li>
      <li><strong>Landscape horticulture</strong> — the production and use of plants to beautify the outdoor environment. Includes designing plans for landscapes, installing landscapes, and maintaining them.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Arboriculture</h2>
    <p><strong>Arboriculture</strong> is the cultivation, management and study of individual trees, shrubs, vines and other perennial woody plants. The science of arboriculture studies how these plants grow and respond to cultural practices and to their environment.</p>
    <h3>Management Practices of Arboriculture</h3>
    <ul>
      <li>Tree pruning — removing dead, diseased, or excess branches to improve tree health and structure</li>
      <li>Management of young trees — correct staking, watering, and shaping from early growth</li>
      <li>Management of mature trees — maintaining structure, removing hazards, monitoring for disease</li>
    </ul>
    <h3>Management of Landscaping Horticulture</h3>
    <ul>
      <li>Maintain healthy plants by meeting their cultural requirements with the goal of using fewer pesticides</li>
      <li>Avoid planting invasive species — instead choose plants that minimise maintenance and increase habitat</li>
      <li>Select plants whose mature size will fit the scale and size of the landscape</li>
      <li>Apply fertilizer and pest and disease control as needed</li>
    </ul>
  </div>`,
  keyTerms: [
    {word:'Pomology', def:'The area of horticulture that involves the planting, harvesting, sorting, processing and marketing of fruit and nut crops'},
    {word:'Olericulture', def:'The area of horticulture that involves the production, planting, harvesting, storing, processing and marketing of vegetable food crops'},
    {word:'Ornamental horticulture', def:'The area of horticulture focused on the growth and use of plants for their beauty — includes floriculture and landscape horticulture'},
    {word:'Floriculture', def:'The area of ornamental horticulture associated with producing and using flowers, potted plants, and bedding plants'},
    {word:'Arboriculture', def:'The cultivation, management, and study of individual trees, shrubs, vines and other perennial woody plants'},
    {word:'Landscaping horticulture', def:'The production and use of plants to beautify the outdoor environment through design, installation, and maintenance'},
  ],
  summary: [
    'The horticulture industry has three main divisions: pomology (fruits/nuts), olericulture (vegetables), and ornamental horticulture',
    'Pomology involves the planting, harvesting, sorting, processing and marketing of fruit and nut crops',
    'Olericulture involves the production, processing, and marketing of vegetable food crops',
    'Ornamental horticulture is divided into floriculture (flowers/potted plants) and landscape horticulture',
    'Arboriculture is the cultivation and management of individual trees and woody plants'
  ],
  quiz: [
    {q:'What is pomology?', opts:['The study of soil and how crops grow','The planting, harvesting, sorting, processing and marketing of fruit and nut crops','The production of vegetable food crops','The study of ornamental plant design'], ans:1},
    {q:'Which area of horticulture is olericulture?', opts:['Fruit and nut crop production','The study of trees and shrubs','The production and marketing of vegetable food crops','Flower growing for the florist trade'], ans:2},
    {q:'Floriculture is associated with:', opts:['Growing vegetables for processing','The production and use of flowers, potted plants and bedding plants','Designing gardens and parks','Managing large fruit orchards'], ans:1},
    {q:'What is arboriculture?', opts:['The study of vegetable varieties','The cultivation, management and study of individual trees, shrubs, vines and perennial woody plants','A method of composting garden waste','The processing and packaging of fresh produce'], ans:1},
    {q:'What type of nursery do most fruit trees use before planting in the field?', opts:['Seedbed nursery','Seed tray nursery','Poly bag nursery','Open-ground nursery'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/horticulture/en/',label:'FAO Horticulture',desc:'Pomology and olericulture resources including cultivation guides for fruit and vegetable crops.'},
  ]
},

'g9-horticulture-technology': {
  title: 'Technology in Horticulture Production',
  strand: 'Strand 1: Crops · Unit 7', grade: 9, icon: '💡',
  lessons: ['Technology in Cultivation','Processing & Preservation Technology','Marketing Technology & Regulation'],
  currentLesson: 0,
  objectives: [
    'Identify and examine the advantages and disadvantages of technology used in horticulture cultivation',
    'Describe how technology is used in the processing, preservation, and marketing of horticulture products',
    'Explain how technology improves management decisions in horticulture production'
  ],
  content: `
  <div class="lesson-section">
    <h2>Technology in Horticulture Cultivation</h2>
    <p>Technology has transformed how horticulture plants are grown, managed, and sold. Throughout all segments of agriculture, farmers are finding that the key to management today and preparing for tomorrow involves the use of technology. Farmers and plantation managers increasingly use information technology to help them improve their decision-making capabilities, particularly when trying to manage the inherent variability found within the crop environment.</p>
    <h3>Advantages of Technology in Horticulture Cultivation</h3>
    <ul>
      <li>Modern machines reduce the physical effort required by farmers and save time</li>
      <li>Irrigation technology supplies water to horticultural crops efficiently — crops cannot be successfully produced where there is insufficient water</li>
      <li>Machines help with sowing seeds accurately, at the correct spacing and depth</li>
      <li>Technology is used in the transportation of produce to markets</li>
      <li>Application of synthetic fertilisers can boost soil nutrients quickly to improve plant growth</li>
      <li>Chemical pest control prevents large crop losses from insects and diseases</li>
      <li>Technology increases the price and demand of products through better marketing and exposure</li>
      <li>Online trading and E-Commerce facilitate direct sales to buyers</li>
      <li>Precision farming decreases the use of water and fertilisers, keeping prices down</li>
      <li>Technology reduces the run-off of chemicals into seas and water sources</li>
      <li>It can reduce the impact on the ecosystem when used correctly</li>
    </ul>
    <h3>Disadvantages of Technology in Horticulture Cultivation</h3>
    <ul>
      <li>Excessive use of chemicals by machines reduces the long-term fertility of the land</li>
      <li>Lack of practical knowledge means farmers cannot handle machines properly</li>
      <li>The cost of maintenance is very high</li>
      <li>Overuse of machines may lead to environmental damage</li>
      <li>Technology has many side effects if not used correctly</li>
      <li>Most farmers in developing countries may lack literacy to use modern machines</li>
    </ul>
    <div class="info-box"><strong>💡 Precision Farming:</strong> Precision farming is a systems approach to managing crops and land selectively, according to their needs. It utilises expertise from many disciplines and integrates the latest information technology tools and techniques to enable farm managers to get a better understanding and control of their fields.</div>
  </div>
  <div class="lesson-section">
    <h2>Processing and Preservation Technology</h2>
    <p>To process and preserve fresh produce successfully, the spoilage agents must be destroyed without ruining the nutritional value or palatability of the produce itself. Fruits, vegetables, and root crops are important natural sources of essential vitamin C — this vitamin is easily destroyed where processing makes use of heat.</p>
    <p>To retain the maximum amount of vitamin C in processed food:</p>
    <ul>
      <li>Produce should be used when freshly harvested</li>
      <li>Must not be subjected to long soaking or washing</li>
      <li>Must be processed immediately after preparation</li>
      <li>Should not be treated in copper, iron or chipped pans</li>
    </ul>
    <h3>Best Methods for Small-Scale Processing</h3>
    <ul>
      <li><strong>Drying</strong> — the aim is to reduce the water content of the produce to a level insufficient for enzyme activity. Produce can be dried using solar or artificial heat</li>
      <li><strong>Processing using chemicals</strong> — chemicals used include preserving with sugar, pickling vegetables, preservation with salt, and fermented products</li>
      <li><strong>Heat treatments</strong> — for many years fruit and vegetables have been preserved by heat, using canning or bottling methods</li>
    </ul>
    <p>Processing techniques for spices include: drying, grading, and grinding.</p>
  </div>
  <div class="lesson-section">
    <h2>Marketing Technology in Horticulture</h2>
    <p>Technology has improved how horticulture products are marketed and sold. There can be many participants in any given marketing system:</p>
    <ul>
      <li><strong>Farmers</strong> — are mainly concerned with growing crops. In developing countries, very few growers have sufficient production or sufficient knowledge to take advantage of the marketing choices available. Technology can help farmers access market information and new buyers</li>
      <li><strong>Traders</strong> — the role of traders is to act as the link between producer and distributor</li>
      <li><strong>Commission Agents</strong> — specialised agents take produce owned by a farmer or trader and sell it for the best price possible</li>
      <li><strong>Retailers</strong> — what the retailer buys reflects the quality and quantity of what their customers will buy</li>
    </ul>
    <p>Digital technology — including mobile phones, internet platforms, and social media — is increasingly used in Papua New Guinea to connect farmers to buyers and access current market prices before selling.</p>
  </div>`,
  keyTerms: [
    {word:'Precision farming', def:'A systems approach to managing crops and land selectively according to their specific needs, using information technology and data'},
    {word:'Preservation', def:'Extending the shelf life of a harvested product by destroying spoilage agents without ruining its nutritional value or taste'},
    {word:'Drying', def:'A processing method that reduces the water content of produce to a level too low for spoilage organisms to grow'},
    {word:'Heat treatment', def:'Preserving fruits and vegetables by applying heat — through canning or bottling — to destroy spoilage agents'},
    {word:'Commission agent', def:'A specialist who sells produce on behalf of farmers or traders, aiming to achieve the best possible price'},
  ],
  summary: [
    'Technology in horticulture helps with cultivation, irrigation, pest control, transportation, and marketing',
    'Advantages include labour savings, higher yields, better marketing, and reduced input waste',
    'Disadvantages include high cost, risk of environmental damage, and the need for technical literacy',
    'Preservation methods include drying, chemical preservation (pickling/salt/sugar), and heat treatment (canning)',
    'Vitamin C in produce is easily destroyed by heat — fresh, quick processing preserves nutritional value',
    'Marketing technology — including mobile phones and E-Commerce — helps connect PNG farmers to buyers'
  ],
  quiz: [
    {q:'What is the aim of drying as a preservation method?', opts:['To add nutrients back to the produce','To reduce water content to a level too low for spoilage','To increase the sugar content','To make produce more colourful'], ans:1},
    {q:'Which vitamin is easily destroyed when processing uses heat?', opts:['Vitamin A','Vitamin B','Vitamin C','Vitamin D'], ans:2},
    {q:'What is precision farming?', opts:['Growing crops in precise rows with spacing guides','A systems approach using information technology to manage crops and land selectively','Farming only during precise seasons','Using only exact amounts of chemical fertiliser'], ans:1},
    {q:'Which is a disadvantage of technology in horticulture?', opts:['It reduces labour requirements','Excessive chemical use can reduce long-term soil fertility','It increases crop yields','It improves marketing access'], ans:1},
    {q:'What role do commission agents play in the marketing system?', opts:['They grow and harvest the produce','They transport produce to ports for export','They sell produce on behalf of farmers or traders for the best price','They inspect produce for quality certification'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/digital-agriculture/en/',label:'FAO Digital Agriculture',desc:'Technology in agriculture — precision farming, E-Commerce, and post-harvest processing tools.'},
  ]
},


'g9-aqua-farming-systems': {
  title: 'Aqua Farming Systems & Practices',
  strand: 'Strand 3: Aquaculture · Unit 2', grade: 9, icon: '🦐',
  lessons: ['Principles of Aqua Farming','Types of Aqua Farming Systems','Monoculture & Polyculture'],
  currentLesson: 0,
  objectives: [
    'Explain the management principles of different types of aqua farming',
    'Identify and describe different aqua farming systems and practices used in different environments',
    'Distinguish between monoculture and polyculture fish production systems'
  ],
  keyTerms: [
    {word:'Aquaculture',def:'The farming of aquatic organisms such as fish, crustaceans, molluscs, and aquatic plants under controlled conditions.'},
    {word:'Extensive system',def:'A low-input aquaculture system with large ponds and low stocking density, relying mainly on natural food production.'},
    {word:'Intensive system',def:'A high-input aquaculture system with small ponds, high stocking density, and formulated feed to achieve maximum production.'},
    {word:'Semi-intensive system',def:'An intermediate system combining natural food production with supplemental feeding to achieve moderate yields.'},
    {word:'Monoculture',def:'A fish production system in which only one fish species is reared in the culture system.'},
    {word:'Polyculture',def:'A fish production system in which two or more different species are farmed together, using different food sources to reduce competition.'},
    {word:'Cage culture',def:'Rearing fish in a volume of water enclosed on all sides including bottom, allowing free circulation of water.'},
    {word:'Pond culture',def:'The most common method of fish culture, where water is maintained in an enclosed area by artificial construction of dikes or bunds.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Principles of Aqua Farming</h2>
    <p>Aquaculture is the farming of aquatic organisms such as fish, crustaceans, molluscs, and aquatic plants. Successful aquaculture takes into consideration the biology of the aquatic species — including feeding habits, water flow and temperature needs, and disease prevention — as well as the engineering design of the farming system, including water source, pond design, filtration, and aeration.</p>
    <p>The key principles of freshwater aquaculture include:</p>
    <ul>
      <li>Principles of organic aquaculture</li>
      <li>Pre-stocking and post-stocking pond management</li>
      <li>Criteria for selection of candidate species for culture</li>
      <li>Water and soil quality management in relation to fish production</li>
      <li>Estimation of pond productivity and factors affecting it</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Classification of Aquaculture Systems</h2>
    <p>Aquaculture practices are classified in several ways based on water type, intensity of management, and enclosure type.</p>
    <h3>By Water Type</h3>
    <ul>
      <li><strong>Freshwater farming</strong> — farming in zero-salinity water, mostly inland. Common species: catla, rohu, tilapia, freshwater prawn.</li>
      <li><strong>Brackish water farming</strong> — farming in water with partial salinity, found near estuaries and river mouths.</li>
      <li><strong>Marine water farming (Mariculture)</strong> — farming in seawater. Includes molluscs, prawns, shellfish, seaweed, and fish in open sea cages.</li>
    </ul>
    <h3>By Intensity of Management</h3>
    <ul>
      <li><strong>Extensive system</strong> — large ponds (1–5 ha), low stocking density (under 5,000 fish/ha), no supplemental feeding. Fish depend on natural food. Low yield (500 kg to 2 tonnes/ha) but low cost.</li>
      <li><strong>Semi-intensive system</strong> — smaller ponds (0.5–1 ha), stocking density of 10,000–15,000 fish/ha. Natural food supplemented with fertilisation and feeding. Moderate yield (3–10 tonnes/ha).</li>
      <li><strong>Intensive system</strong> — small ponds or tanks, very high stocking density (10–50 fish/m³). Fish fed completely on formulated feed. Water quality actively managed using aerators. Highest yields (15–100+ tonnes/ha) but high capital cost.</li>
    </ul>
    <h3>By Enclosure Type</h3>
    <ul>
      <li><strong>Pond culture</strong> — the most common method. Water held in an enclosed area by artificial bunds. Ponds filled by rain, canals, or bores.</li>
      <li><strong>Cage culture</strong> — fish raised in cages enclosed on all sides, allowing free water circulation. Suited to lakes, reservoirs, and rivers. Fish species include carps, tilapia, trout, and catfish.</li>
      <li><strong>Pen culture</strong> — fish raised in an enclosure open at the bottom, with the lake floor forming the base. Fish can feed on natural benthic fauna.</li>
      <li><strong>Raceway culture</strong> — fish raised in running water at high stocking density. Two types: linear (ponds in sequence) and lateral (ponds in parallel). Lateral type reduces disease spread between ponds.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Monoculture and Polyculture</h2>
    <p><strong>Monoculture</strong> is a production system in which only one fish species is reared. Common monoculture species include trout, tilapia, catfish, carps, and shrimp. It is widely practised in intensive systems where supplemental feeding is essential.</p>
    <p><strong>Polyculture</strong> is a system in which two or more different species are farmed together. Species are chosen so that they occupy different water depths and have different food preferences, avoiding competition. Polyculture generally produces higher yields than monoculture under the same conditions.</p>
    <p>The principal requirements for a successful polyculture system are:</p>
    <ul>
      <li>Species must have different feeding habits</li>
      <li>Species should occupy different columns (levels) within the pond</li>
      <li>All species should reach marketable size at the same time</li>
      <li>Species should be non-predatory toward each other</li>
    </ul>
  </div>`,
  summary: [
    'Aquaculture is the controlled farming of fish, crustaceans, molluscs, and aquatic plants',
    'Systems are classified by water type: freshwater, brackish water, and marine (mariculture)',
    'By intensity: extensive (low input/yield), semi-intensive (moderate), and intensive (high input/yield)',
    'By enclosure type: pond culture, cage culture, pen culture, and raceway culture',
    'Monoculture farms one species; polyculture farms two or more species with different food habits',
    'Intensive systems use aerators, formulated feed, and small tanks to achieve the highest yields',
  ],
  quiz: [
    {q:'Which aquaculture system requires the highest capital investment but produces the greatest yield?', opts:['Extensive','Semi-intensive','Intensive','Pond culture'], ans:2},
    {q:'What is the main advantage of polyculture over monoculture?', opts:['It requires less water','Different species use different food sources, reducing competition and increasing yield','It only requires one type of feed','It is cheaper to set up'], ans:1},
    {q:'In cage culture, what happens to water?', opts:['It is pumped in and out manually','It circulates freely through the cage','It is treated with chemicals daily','It remains still around the cage'], ans:1},
    {q:'What type of aquaculture involves farming in seawater?', opts:['Freshwater farming','Brackish water farming','Mariculture','Raceway culture'], ans:2},
    {q:'In an extensive aquaculture system, what do fish primarily rely on for food?', opts:['Formulated pellet feed','Organic manure only','Natural food produced in the pond','Feed from automatic feeders'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/fishery/en/aquaculture',label:'FAO Aquaculture',desc:'Aquaculture systems, fish farming practices, and Pacific fisheries information from the FAO.'},
  ]
},

'g9-aqua-technology': {
  title: 'Gears & Technology in Aqua Farming',
  strand: 'Strand 3: Aquaculture · Unit 3', grade: 9, icon: '🎣',
  lessons: ['Fishing Gears & Devices','Aqua Farming Technology','Challenges & Solutions'],
  currentLesson: 0,
  objectives: [
    'Identify different types of gears and devices used in aqua farming',
    'Analyse technologies used in aqua farming and identify their problems',
    'Develop appropriate solutions to aqua farming technology challenges'
  ],
  keyTerms: [
    {word:'Gillnet',def:'A fishing net hung vertically so that fish become trapped by their gills. Has floats on the upper line and weights on the lower line.'},
    {word:'Handline',def:'A simple, low-cost fishing method using a line, hook, sinker, and bait. Widely used in PNG and the Pacific.'},
    {word:'Fish trap',def:'A passive fishing device that allows fish to enter easily but makes it difficult for them to escape.'},
    {word:'Active gear',def:'Fishing gear designed to chase and capture target species.'},
    {word:'Passive gear',def:'Fishing gear that remains in one place allowing target species to approach the capture device.'},
    {word:'RAS',def:'Recirculating Aquaculture System — treats and reuses water continuously, replacing less than 10% of total water volume per day.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Fishing Gears and Devices in Aqua Farming</h2>
    <p>Fishing gear refers to the tools used to capture aquatic resources. All fishing gears fall under two general categories: <strong>active gear</strong> (designed to chase and capture target species) and <strong>passive gear</strong> (which sits in one place, allowing target species to approach the device).</p>
    <h3>Gillnets</h3>
    <p>A gillnet is a fishing net hung vertically so that fish get trapped in it by their gills. Gillnets have floats on the upper line (headrope) and weights on the lower line (footrope) to keep them upright in the water. They can be set near the surface, at mid-water depth, or on the bottom depending on the target species.</p>
    <h3>Handlines</h3>
    <p>A handline is a simple and affordable fishing method using a line, hook, sinker, and bait. In Papua New Guinea, handline fishing from a canoe remains a widely used and economically accessible method. It is fuel efficient and effective for catching fish like snapper, bonefish, tilapia, and catfish.</p>
    <h3>Fish Traps</h3>
    <p>Fish traps are passive fishing devices that allow fish to enter but make it difficult for them to escape, through internal chambers or funnels. Traps come in many forms: barrier traps, habitat traps (like brush traps and octopus pots), basket traps made of wood or wire, and large corrals or open traps anchored in place.</p>
    <h3>Fish Farming Equipment</h3>
    <p>Aquaculture farms require specific equipment including: ponds or tanks, handling and grading equipment, water quality testers, fish transporters, dip nets, seine reels, water pumps, and automatic feeders.</p>
  </div>
  <div class="lesson-section">
    <h2>Technology in Aqua Farming</h2>
    <p>Key developments in aquaculture technology include:</p>
    <ul>
      <li><strong>Recirculating Aquaculture Systems (RAS)</strong> — systems that treat and reuse water continuously, replacing less than 10% of total water volume per day. They use mechanical and biological filtration, pumps, and holding tanks to maintain water quality at high stocking densities.</li>
      <li><strong>Offshore cage systems</strong> — engineering advances allow aquaculture cages to be used further out at sea, with greater production potential.</li>
      <li><strong>Aquafeeds technology</strong> — combining a large number of nutritional ingredients into highly efficient small pellets to maximise fish growth.</li>
      <li><strong>Integrated agriculture-aquaculture systems</strong> — combining fish culture with agricultural crops such as rice, banana, or coconut on the same farm.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Challenges and Solutions in Aqua Farming Technology</h2>
    <p>Key challenges include environmental impacts from intensive systems, dependency on wild fish for fishmeal, rapid disease spread at high stocking densities, high capital costs for advanced systems, and the technical demands of water quality management.</p>
    <p>Solutions include adopting integrated multitrophic aquaculture (IMTA), using biological filtration in RAS, applying technology appropriate to the farm scale, and selecting species naturally suited to local environmental conditions.</p>
  </div>`,
  summary: [
    'Fishing gears are classified as active (chase target species) or passive (target species approach the device)',
    'Gillnets trap fish by their gills using floats on the top line and weights on the bottom',
    'Handlines are low-cost, fuel-efficient, and widely used in Papua New Guinea and the Pacific',
    'Fish traps are passive devices that allow fish to enter but make escape difficult',
    'RAS systems treat and reuse water continuously, allowing high stocking densities with minimal water waste',
    'Key challenges include disease risk, environmental impacts, high cost, and water quality management',
  ],
  quiz: [
    {q:'How does a gillnet catch fish?', opts:['Fish are attracted by bait into a funnel','Fish become trapped by their gills in the vertical net','Fish are chased into the net by boats','Fish swim over the net and are trapped below'], ans:1},
    {q:'What distinguishes passive fishing gear from active fishing gear?', opts:['Passive gear is more expensive','Passive gear sits in one place and lets fish approach it','Passive gear is only used in freshwater','Passive gear requires more labour'], ans:1},
    {q:'What does RAS stand for in aquaculture?', opts:['Reef Aquaculture System','River Aeration Solution','Recirculating Aquaculture System','Regulated Aquatic Seeding'], ans:2},
    {q:'Which of the following is a challenge of intensive aquaculture technology?', opts:['Too many fish species available','High capital cost and risk of rapid disease spread','Nets are too expensive to make','Fish grow too slowly in intensive systems'], ans:1},
    {q:'In PNG, which fishing method remains widely used due to its low cost and fuel efficiency?', opts:['Trawl net fishing','Cage fishing','Handline fishing from a canoe','Offshore mariculture'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/fishery/en/aquaculture',label:'FAO Aquaculture Technology',desc:'Aquaculture systems, technology, and sustainable fish farming resources from the FAO.'},
  ]
},

'g9-forest-harvesting': {
  title: 'Forest Harvesting Practices',
  strand: 'Strand 4: Natural Resources · Unit 5', grade: 9, icon: '🪓',
  lessons: ['Principles of Forest Management','Forest Harvesting Practices','Impact of Harvesting'],
  currentLesson: 0,
  objectives: [
    'Explain the principles of forests and their importance in sustainable management',
    'Identify and describe forest harvesting practices used in different places and environments',
    'Evaluate the impact of different harvesting methods on forest regeneration'
  ],
  keyTerms: [
    {word:'Selective cutting',def:'A harvesting practice where only trees meeting certain criteria (maturity, height, age, disease) are cut, leaving the rest of the forest intact.'},
    {word:'Clear cutting',def:'A harvesting method where every tree in a selected area is cut down at once. Highly efficient but causes significant landscape damage and soil erosion.'},
    {word:'Strip cutting',def:'Harvesting trees in narrow strips to minimise damage and allow for natural forest regeneration in the uncut sections between strips.'},
    {word:'Sustainable harvesting',def:'Harvesting forests at a rate at which they can naturally regenerate, ensuring forests remain available for future generations.'},
    {word:'Deforestation',def:'The decrease in forest areas caused by clearing land for agriculture, urbanisation, or mining. The greatest impact of forest harvesting.'},
    {word:'Forest regeneration',def:'The process of forests growing back after harvesting or disturbance, through natural seeding or replanting.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Principles of Forest Management</h2>
    <p>One of the key agreements from the 1992 Rio Earth Summit was the <strong>Principles of Forest Management</strong>, which stated that forests are essential to sustainable development and the maintenance of all forms of life. Forests provide wood, food, and medicine; contain immense biodiversity; and act as carbon sinks for carbon dioxide, helping reduce global warming.</p>
    <p>The Principles of Forest Management state that:</p>
    <ul>
      <li>All nations should participate in "the greening of the world" through planting and conserving forests.</li>
      <li>Forests should be managed to meet the social, economic, ecological, cultural, and spiritual needs of present and future generations.</li>
      <li>Unique examples of forest — including ancient forests and forests with cultural or religious importance — should be protected.</li>
      <li>Pollutants that harm forests should be controlled and forest degradation should be avoided.</li>
    </ul>
    <p>Forestry contributes on average 5.1% of Papua New Guinea\'s GDP and serves as the third largest source of foreign exchange. Benefits to PNG society include government revenue, rural jobs and payments, and infrastructure provision.</p>
  </div>
  <div class="lesson-section">
    <h2>Types of Forest Harvesting Practices</h2>
    <p>There are three major harvesting practices used in forestry:</p>
    <h3>1. Selective Cutting</h3>
    <p>Selective cutting harvests only trees that meet certain criteria — such as maturity, height, age, or disease. Operators use chainsaws to cut selected trees, reducing scarring of the land. This is the most environmentally friendly method as it allows the forest to continue growing and regenerating naturally.</p>
    <h3>2. Clear Cutting</h3>
    <p>Clear cutting means cutting down every tree in a selected area. Large machines cut, debranch, and load logs onto trucks. While economically efficient, clear cutting causes considerable damage: destruction of entire habitats, loss of biodiversity, and significant soil erosion. Replanting is necessary after clear cutting.</p>
    <h3>3. Strip Cutting</h3>
    <p>Strip cutting harvests trees in narrow strips, leaving sections between strips uncut — especially near lakes and rivers — to reduce soil and wind erosion and allow natural forest regeneration. It is a compromise between efficiency and environmental protection.</p>
  </div>
  <div class="lesson-section">
    <h2>Impact of Harvesting Forests</h2>
    <p>The greatest impact of harvesting forests is <strong>deforestation</strong> — the permanent removal of forest cover. Deforestation threatens biodiversity (80% of Earth\'s land animals and plants live in forests), destroys habitats, disrupts water cycles, and contributes to climate change by releasing stored carbon.</p>
    <p>According to the FAO, 6 million hectares of land were lost from forest to agriculture since 1990 in the tropical domain. Sustainable use of the forest means harvesting at the rate at which forests can regenerate — so there will always be forest available for future generations.</p>
  </div>`,
  summary: [
    'The 1992 Rio Earth Summit Principles require forests to be managed for present and future generations',
    'Forestry contributes about 5.1% of PNG GDP and is the third largest source of foreign exchange',
    'Selective cutting removes only trees meeting set criteria — the most environmentally responsible method',
    'Clear cutting removes all trees in an area — efficient but causes severe habitat destruction and soil erosion',
    'Strip cutting harvests in narrow strips, leaving uncut sections to allow natural regeneration',
    'Deforestation threatens biodiversity and contributes to climate change by releasing stored carbon',
  ],
  quiz: [
    {q:'Which forest harvesting method removes only trees that meet specific criteria such as maturity or disease?', opts:['Clear cutting','Strip cutting','Selective cutting','Raceway cutting'], ans:2},
    {q:'What is the main disadvantage of clear cutting?', opts:['It is too slow and expensive','It destroys entire habitats and causes significant soil erosion','It produces too much timber','It can only be done in dry weather'], ans:1},
    {q:'Strip cutting leaves sections between strips uncut mainly to:', opts:['Make logging easier','Reduce soil erosion and allow natural regeneration','Save on equipment costs','Protect private land boundaries'], ans:1},
    {q:'Approximately what percentage of Earth\'s land animals and plants live in forests?', opts:['20%','50%','80%','95%'], ans:2},
    {q:'Forestry contributes approximately what percentage of Papua New Guinea\'s GDP?', opts:['1%','5.1%','12%','20%'], ans:1},
  ],
  furtherReading: [
    {url:'https://www.fao.org/forestry/en/',label:'FAO Forestry',desc:'Sustainable forest management, forest harvesting practices, and global forest resources.'},
  ]
},

'g9-forest-management': {
  title: 'Forest Management & Conservation',
  strand: 'Strand 4: Natural Resources · Unit 4', grade: 9, icon: '🌲',
  lessons: ['Types of Forests','Forest Attributes & Classification','Forests & the Global Ecosystem'],
  currentLesson: 0,
  objectives: [
    'Explain what forestry is and identify the different types of forests',
    'Describe and distinguish the attributes of different types of forests and forestry',
    'Explain how forests contribute to the global ecosystem and climate regulation'
  ],
  keyTerms: [
    {word:'Tropical forest',def:'Forests in tropical regions receiving large amounts of annual rainfall. Most nutrients are in the vegetation; soils are typically low in mineral content.'},
    {word:'Temperate forest',def:'Forests in North America, Eurasia, and Japan, primarily deciduous with broad-leafed hardwood trees that shed leaves each autumn.'},
    {word:'Boreal forest',def:'Also called taiga. Located south of the tundra, dominated by coniferous trees, with short growing seasons and minimal precipitation.'},
    {word:'Primary forest',def:'Forest of native species with no clearly visible indications of human activity and no significant disturbance of ecological processes.'},
    {word:'Transpiration',def:'The process of plants releasing excess water into the atmosphere as water vapour, affecting humidity and precipitation.'},
    {word:'Carbon sink',def:'A forest\'s ability to absorb and store carbon dioxide from the atmosphere, helping to reduce global warming.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>What is a Forest?</h2>
    <p>A <strong>forest ecosystem</strong> is a community of organisms that lives within a forest. Forests cover one-third of the Earth\'s surface and contain an estimated 3 trillion trees. Trees absorb carbon dioxide, reduce wind speeds, cool the air, prevent flooding and soil erosion, and filter pollutants from the air. Papua New Guinea\'s forests are predominantly tropical and among the most biodiverse on Earth.</p>
  </div>
  <div class="lesson-section">
    <h2>Types of Forests</h2>
    <p>By latitude, the three main types of forests are tropical, temperate, and boreal.</p>
    <h3>Tropical Forest</h3>
    <p>Tropical forests receive large amounts of rain annually — up to 100 inches — spread fairly evenly throughout the year. Most nutrients are held in the vegetation canopy, so soils are typically low in mineral content. PNG\'s forests are predominantly tropical.</p>
    <h3>Temperate Forest</h3>
    <p>Temperate forests are found in North America, Eurasia, and Japan. They are primarily deciduous — characterised by broad-leafed hardwood trees that shed their leaves each autumn. They experience four seasons, with winters often bringing freezing temperatures. Soils are well-developed and rich in organic matter.</p>
    <h3>Boreal Forest (Taiga)</h3>
    <p>Boreal forests are located just south of the tundra across large areas of North America and Eurasia. They cover about 11% of Earth\'s land area and are dominated by coniferous trees with needle-shaped leaves that minimise water loss in cold, dry conditions.</p>
    <h3>Classification by Human Modification</h3>
    <ul>
      <li><strong>Primary</strong> — native species, no visible human activity, ecological processes undisturbed.</li>
      <li><strong>Modified natural</strong> — native species, but with clearly visible human activity.</li>
      <li><strong>Semi-natural</strong> — native species established through planting or assisted natural regeneration.</li>
      <li><strong>Productive plantation</strong> — established mainly for production of wood or non-wood products.</li>
      <li><strong>Protective plantation</strong> — established mainly to provide environmental services such as erosion control.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Importance of Forests to the Global Ecosystem</h2>
    <ul>
      <li><strong>Water cycle</strong> — plants release water into the atmosphere through transpiration, affecting humidity and rainfall patterns.</li>
      <li><strong>Oxygen production</strong> — forests absorb carbon dioxide and release oxygen during photosynthesis.</li>
      <li><strong>Climate regulation</strong> — forests act as carbon sinks, absorbing CO₂ and reducing the greenhouse effect.</li>
      <li><strong>Soil protection</strong> — tree roots hold soil particles together and prevent erosion from rain and wind.</li>
      <li><strong>Biodiversity</strong> — forests are home to 80% of Earth\'s land animals and plants.</li>
      <li><strong>Economic value</strong> — forests supply timber, paper, pharmaceuticals, and food products.</li>
    </ul>
  </div>`,
  summary: [
    'Forests cover one-third of the Earth\'s surface and contain an estimated 3 trillion trees',
    'Three main forest types by latitude: tropical (high rainfall), temperate (deciduous, four seasons), and boreal (coniferous, cold)',
    'Forests are classified by human modification from primary (untouched) to productive or protective plantations',
    'PNG\'s forests are predominantly tropical and among the world\'s most biodiverse',
    'Forests regulate the water cycle, produce oxygen, store carbon, protect soil, and support biodiversity',
    'Forestry contributes significantly to the PNG economy through timber production and export revenue',
  ],
  quiz: [
    {q:'Which type of forest is characterised by deciduous hardwood trees that shed their leaves in autumn?', opts:['Tropical','Temperate','Boreal','Primary'], ans:1},
    {q:'What percentage of Earth\'s land animals and plants live in forests?', opts:['20%','50%','80%','99%'], ans:2},
    {q:'What is transpiration?', opts:['The process of trees absorbing nutrients from soil','The process of plants releasing water vapour into the atmosphere','The process of soil erosion under forests','The process of photosynthesis in forest plants'], ans:1},
    {q:'A primary forest is defined as one with:', opts:['Only introduced tree species','Clearly visible signs of human logging','Native species and no significant disturbance of ecological processes','Trees planted for commercial timber production'], ans:2},
    {q:'Boreal forests are dominated by which type of trees?', opts:['Broad-leafed deciduous trees','Coniferous trees with needle-shaped leaves','Tropical palms','Mangrove trees'], ans:1},
  ],
  furtherReading: [
    {url:'https://www.fao.org/forestry/en/',label:'FAO Forestry',desc:'Global forest resources, tropical forest conservation, and sustainable forest management.'},
  ]
},

'g9-forestry-technology': {
  title: 'Forestry Technology: Tools & Challenges',
  strand: 'Strand 4: Natural Resources · Unit 6', grade: 9, icon: '⚙️',
  lessons: ['Tools & Equipment in Forest Harvesting','Technologies Used in Forestry','Challenges & Solutions'],
  currentLesson: 0,
  objectives: [
    'Identify and discuss the tools, equipment, and devices used in the harvesting of forests',
    'Research and analyse technologies used in forestry and identify their problems',
    'Develop appropriate solutions to challenges associated with forestry technology'
  ],
  keyTerms: [
    {word:'Chainsaw',def:'A portable mechanical saw used for cutting down trees and cutting logs into lengths during selective harvesting.'},
    {word:'Skidder',def:'A large wheeled or tracked machine used to drag logs from the cutting site to a loading area.'},
    {word:'Log loader',def:'Heavy machinery used to lift and load logs onto trucks for transportation to processing facilities.'},
    {word:'Forest inventory',def:'A systematic survey of forest resources to determine timber volume, species composition, and forest health.'},
    {word:'Sustainable forestry',def:'Forestry practices that harvest timber at a rate at which forests can regenerate, protecting biodiversity and ecological function.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Tools and Equipment in Forest Harvesting</h2>
    <h3>Hand Tools</h3>
    <ul>
      <li><strong>Chainsaws</strong> — portable mechanical saws used to fell trees and cut logs. Used in selective and strip cutting.</li>
      <li><strong>Axes and machetes</strong> — used for clearing undergrowth, removing branches, and smaller cutting tasks.</li>
      <li><strong>Measuring tools</strong> — diameter tapes, clinometers, and hypsometers used to measure tree size and estimate timber volume.</li>
    </ul>
    <h3>Heavy Machinery</h3>
    <ul>
      <li><strong>Skidders</strong> — wheeled or tracked machines that drag felled logs from the cutting site to a loading area.</li>
      <li><strong>Forwarders</strong> — carry cut logs on a trailer bed rather than dragging them, reducing soil disturbance.</li>
      <li><strong>Log loaders</strong> — cranes or claw machines that lift and load logs onto trucks.</li>
      <li><strong>Bulldozers</strong> — used for road construction in forest areas to allow trucks and machinery to access timber.</li>
      <li><strong>Sawmills</strong> — facilities where logs are cut into planks and timber products. Can be portable or fixed.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Technologies Used in Forestry</h2>
    <ul>
      <li><strong>GPS and GIS mapping</strong> — used to map forest boundaries, plan harvesting routes, and monitor forest coverage over time.</li>
      <li><strong>Remote sensing and drones</strong> — aerial imaging used to survey large forest areas, identify disease, monitor deforestation, and plan conservation efforts.</li>
      <li><strong>Forest inventory software</strong> — programs used to calculate timber volume, track harvesting quotas, and manage replanting schedules.</li>
      <li><strong>Mechanised harvesting systems</strong> — combine felling, debranching, and log cutting in a single machine operation.</li>
    </ul>
    <h3>Advantages and Disadvantages</h3>
    <p><strong>Advantages:</strong> faster harvesting, reduced danger to workers, better monitoring and conservation, improved replanting management.</p>
    <p><strong>Disadvantages:</strong> high capital cost, heavy machinery compacts soil and damages roots, road construction fragments forest habitats, technology enables faster clear cutting.</p>
  </div>
  <div class="lesson-section">
    <h2>Solutions to Forestry Technology Challenges</h2>
    <ul>
      <li>Use <strong>reduced-impact logging</strong> techniques that minimise soil disturbance.</li>
      <li>Apply <strong>sustainable harvesting quotas</strong> enforced through government regulation and forest inventory data.</li>
      <li>Use <strong>portable sawmills</strong> that operate without heavy road construction, reducing habitat fragmentation.</li>
      <li>Combine <strong>traditional knowledge</strong> with modern technology to identify which trees to protect.</li>
      <li>Invest in <strong>replanting programmes</strong> to restore harvested areas with native species.</li>
    </ul>
  </div>`,
  summary: [
    'Forest harvesting uses both hand tools (chainsaws, axes) and heavy machinery (skidders, loaders, bulldozers)',
    'Modern technologies include GPS/GIS mapping, remote sensing, drones, and forest inventory software',
    'Advantages: faster harvesting, better monitoring, reduced danger to workers',
    'Disadvantages: high cost, soil compaction, habitat fragmentation, risk of accelerating deforestation',
    'Solutions include reduced-impact logging, sustainable harvesting quotas, and replanting programmes',
  ],
  quiz: [
    {q:'What is the purpose of a skidder in forestry?', opts:['It plants new trees after harvesting','It measures tree height and diameter','It drags felled logs from the cutting site to a loading area','It removes bark from logs before transport'], ans:2},
    {q:'Which technology allows foresters to survey large forest areas and detect disease from above?', opts:['Portable sawmills','GPS receivers','Drones and remote sensing','Skidder machines'], ans:2},
    {q:'What is one major disadvantage of using heavy machinery in forest harvesting?', opts:['Machinery is too slow for commercial logging','Machinery compacts soil and damages root systems','Machinery cannot cut logs into required lengths','Machinery is too quiet to operate safely'], ans:1},
    {q:'What is reduced-impact logging designed to do?', opts:['Remove all trees from a large area quickly','Minimise soil disturbance and damage to remaining trees','Use only hand tools to avoid machinery costs','Focus harvesting on young trees only'], ans:1},
    {q:'Forest inventory software is used mainly for:', opts:['Marketing timber products to buyers','Calculating timber volume and managing replanting schedules','Training chainsaw operators','Designing forest roads'], ans:1},
  ],
  furtherReading: [
    {url:'https://www.fao.org/forestry/en/',label:'FAO Forestry Technology',desc:'Forest management tools, harvesting technology, and sustainable forestry practices.'},
  ]
},

'g9-agri-imports-exports': {
  title: 'Agricultural Imports & Exports',
  strand: 'Strand 5: Agribusiness · Unit 2', grade: 9, icon: '🌏',
  lessons: ['The International Agribusiness Market','Agricultural Imports','Exporting Agricultural Products'],
  currentLesson: 0,
  objectives: [
    'Identify and discuss the processes and importance of agricultural imports and exports',
    'Describe the impact of imports and exports on agribusiness in Papua New Guinea',
    'Identify methods that agribusinesses might use to enter international markets'
  ],
  keyTerms: [
    {word:'Import',def:'Goods and services brought into a country from abroad for sale or use.'},
    {word:'Export',def:'Goods and services produced in one country and sold to buyers in another country.'},
    {word:'International market',def:'The global marketplace where goods and services are bought and sold across national borders.'},
    {word:'Indirect exporting',def:'Using a trading company or export management company to handle the logistics of exporting on behalf of an agribusiness.'},
    {word:'Direct exporting',def:'Where an agribusiness itself handles all the details of exporting — including research, distribution, and overseas contacts.'},
    {word:'Scale economies',def:'Cost advantages that a business gains by increasing its output — producing more reduces the average cost per unit.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Why International Markets Matter for Agribusiness</h2>
    <p>There are many reasons for agribusinesses to be interested in international markets. The exporting of agricultural products boosts employment within a country\'s economy — in production, wholesale and retail trade, services, food processing, and feed processing.</p>
    <p>Benefits of entering international markets include:</p>
    <ul>
      <li>Increased exports and sales revenue</li>
      <li>Ability to take advantage of scale economies</li>
      <li>Capture benefits of a global brand</li>
      <li>Reduce business risk by diversifying across markets</li>
      <li>Lower costs of production through efficient large-scale operations</li>
      <li>Access to lower-cost raw materials through international sourcing (imports)</li>
      <li>Broader access to credit and finance</li>
    </ul>
    <p>Technology — particularly internet, email, and mobile communication — has made small agribusinesses in PNG highly competitive with larger firms for emerging-market growth potential. Small agribusiness firms are often more flexible than large corporations, allowing them to adapt quickly to the changing demands of the international food industry.</p>
  </div>
  <div class="lesson-section">
    <h2>Two Approaches to Exporting</h2>
    <h3>1. Indirect Exporting</h3>
    <p>Indirect exporting uses a <strong>trading company or export management company</strong> to handle the logistics of exporting. These experts manage procedures and regulations, and use their established relationships with buyers and distributors to place the product in international markets. This is considered a low-risk strategy requiring lower investment — suited to first-time exporters and small agribusinesses. The main disadvantage is reduced profitability as the trading company takes a share.</p>
    <h3>2. Direct Exporting</h3>
    <p>Direct exporting is where the agribusiness itself handles all the details of exporting — conducting research, establishing contacts in the target country, and setting up its own distribution channels. Firms often open an overseas sales office to manage operations. Direct exporting involves higher investment but offers much greater profit potential and full control over product distribution and brand representation.</p>
  </div>`,
  summary: [
    'International trade in agriculture creates employment in production, processing, wholesale, retail, and services',
    'Key benefits: higher sales, scale economies, risk diversification, global brand building, and access to credit',
    'Indirect exporting uses a trading company to handle logistics — low risk and lower investment',
    'Direct exporting is handled by the agribusiness itself — higher investment but greater profit potential and control',
    'Technology has made it easier for small PNG agribusinesses to compete in international markets',
    'Flexibility and adaptability are key advantages that small agribusiness firms have in global markets',
  ],
  quiz: [
    {q:'What is indirect exporting?', opts:['The business opens its own office overseas','The business uses a trading company to handle exports on its behalf','The business avoids international markets','The business produces goods only for local sale'], ans:1},
    {q:'Which of the following is an advantage of direct exporting?', opts:['Lower investment cost','Less paperwork','Higher profit potential and full control over distribution','No need to conduct market research'], ans:2},
    {q:'Which of the following is a benefit of entering international markets for an agribusiness?', opts:['Reduced product quality standards','Higher domestic competition','Reduced risk by diversifying across markets','Fewer customers to serve'], ans:2},
    {q:'What has technology done for small agribusinesses seeking international markets?', opts:['Made it more expensive to trade globally','Made them highly competitive with larger firms','Reduced access to international buyers','Removed the need for export regulations'], ans:1},
    {q:'Agricultural exports primarily boost which sector of the economy?', opts:['Banking and finance','Mining','Employment in production and food processing','Tourism'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/markets-and-trade/en/',label:'FAO Markets & Trade',desc:'Agricultural marketing, trade systems, and international agribusiness resources from the FAO.'},
  ]
},

'g9-agribusiness-planning': {
  title: 'Planning & Managing an Agribusiness',
  strand: 'Strand 5: Agribusiness · Unit 3', grade: 9, icon: '📋',
  lessons: ['What is an Enterprise?','Types of Business Ownership','Planning an Agribusiness'],
  currentLesson: 0,
  objectives: [
    'Explain the meaning of enterprise and the role of the entrepreneur',
    'Differentiate between sole proprietorship, partnerships, and corporations as forms of business ownership',
    'Discuss and explain the process involved in planning and establishing an agribusiness'
  ],
  keyTerms: [
    {word:'Enterprise',def:'The act of planning a business, starting it, and running it — bringing together the factors of production and managing risk.'},
    {word:'Entrepreneur',def:'The person who organises and manages a business, taking on financial risk in exchange for profit.'},
    {word:'Sole proprietorship',def:'The simplest business structure, usually involving one individual who owns and operates the enterprise.'},
    {word:'Partnership',def:'A business owned and operated by two or more individuals who share management and liability.'},
    {word:'Corporation',def:'An independent legal entity separate from its owners, requiring compliance with more regulations and tax requirements.'},
    {word:'Business plan',def:'A written document that outlines the mission, objectives, policies, strategies, and budget of a planned business.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>What is an Enterprise?</h2>
    <p>Enterprise means to plan a business, to start it, and to run it. It involves bringing the factors of production together, assigning each its proper task, and paying them when the work is done. An enterprise implies not only running a business but also accepting the risk of loss. The person who undertakes all this work is called an <strong>entrepreneur</strong>. The two main functions of an entrepreneur are <strong>organising</strong> and <strong>risk-taking</strong>.</p>
  </div>
  <div class="lesson-section">
    <h2>Types of Business Ownership</h2>
    <h3>Sole Proprietorship</h3>
    <p>The simplest structure — usually involving one individual who owns and operates the enterprise. The owner receives all profits but is also fully personally liable for all debts. Suited to working alone.</p>
    <h3>Partnership</h3>
    <p>A business owned and operated by two or more individuals. Two varieties exist:</p>
    <ul>
      <li><strong>General partnership</strong> — all partners manage the company and share responsibility for its debts and obligations.</li>
      <li><strong>Limited partnership</strong> — has both general partners (who manage and assume liability) and limited partners (who serve as investors only, with no management control).</li>
    </ul>
    <h3>Corporation</h3>
    <p>A corporation is an independent legal entity, separate from its owners. It requires compliance with more regulations and tax requirements. However, it provides owners with limited personal liability and can raise capital more easily.</p>
  </div>
  <div class="lesson-section">
    <h2>Planning an Agribusiness</h2>
    <p>Planning is a decision-making process in which an organisation determines what courses of action to take over a period of time. A good business plan includes:</p>
    <ul>
      <li><strong>Mission or purpose</strong> — the basic reason the business exists.</li>
      <li><strong>Objectives or goals</strong> — specific, measurable end results the business aims to achieve.</li>
      <li><strong>Policies</strong> — guidelines that direct decision-making in recurring situations.</li>
      <li><strong>Strategies</strong> — comprehensive plans designed to achieve business objectives.</li>
      <li><strong>Rules</strong> — specific guides for what is and is not to be done. Breaches typically carry penalties.</li>
      <li><strong>Procedures</strong> — step-by-step guides describing how specific work should be performed.</li>
      <li><strong>Budgets</strong> — monetary expressions of plans, stating anticipated costs against income for a future period of time.</li>
    </ul>
  </div>`,
  summary: [
    'An enterprise is the process of planning, starting, and running a business, managed by an entrepreneur',
    'The two main functions of an entrepreneur are organising and risk-taking',
    'Sole proprietorship: one owner, simplest structure, full personal liability',
    'Partnership: two or more owners sharing management; general or limited varieties',
    'Corporation: independent legal entity, more complex, provides limited liability to owners',
    'A business plan includes mission, objectives, policies, strategies, rules, procedures, and budgets',
  ],
  quiz: [
    {q:'What are the two main functions of an entrepreneur?', opts:['Selling and marketing','Organising and risk-taking','Farming and harvesting','Budgeting and borrowing'], ans:1},
    {q:'In a limited partnership, what role do limited partners play?', opts:['They manage the day-to-day operations of the business','They share full liability for business debts','They serve as investors only with no management control','They act as the main decision-makers'], ans:2},
    {q:'Which business structure is an independent legal entity separate from its owners?', opts:['Sole proprietorship','General partnership','Limited partnership','Corporation'], ans:3},
    {q:'What is the purpose of a business budget?', opts:['To list all employees of the business','To state the anticipated costs against income for a future period','To describe the legal structure of the business','To record past sales data only'], ans:1},
    {q:'Which component of a business plan provides guidelines for staff decisions in recurring situations?', opts:['Mission','Objectives','Policies','Strategies'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/rural-employment/agricultural-entrepreneurship/en/',label:'FAO Agricultural Entrepreneurship',desc:'Business planning, entrepreneurship, and agribusiness management resources from the FAO.'},
  ]
},

'g10-crop-management': {
  title: 'Crop Management Systems & Practices',
  strand: 'Strand 1: Crops · Unit 3', grade: 10, icon: '🌾',
  lessons: ['Crop Management Practices','Crop Cultivation Principles','Organic Farming Principles'],
  currentLesson: 0,
  objectives: [
    'Describe crop management systems and practices used in different contexts',
    'Explain crop cultivation and management principles including pest control, irrigation, pruning, and fertilisation',
    'Describe the four guiding principles of organic farming'
  ],
  keyTerms: [
    {word:'Seedbed preparation',def:'The first step in crop management — preparing soil to the right texture and condition for seed germination.'},
    {word:'Irrigation',def:'The artificial application of water to the soil through systems of tubes, pumps, and sprays to supplement rainfall.'},
    {word:'Pruning',def:'Removal or reduction of parts of plant crops not required for growth or production; also helps prevent insect and disease damage.'},
    {word:'Pest management',def:'Reducing or eliminating unwanted organisms that threaten crop health and yield.'},
    {word:'Crop rotation',def:'Alternating different crops on the same land each season to preserve soil nutrients, reduce disease, and prevent erosion.'},
    {word:'Organic farming',def:'Farming based on the four principles of health, fairness, ecology, and care, avoiding synthetic chemicals.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Importance of Crop Management</h2>
    <p>Adoption of best crop management practices improves crop productivity and contributes to greater yields with improved quality. Crop management is the set of agricultural practices performed to improve the growth, development, and yield of crops. It begins with seedbed preparation and sowing of seeds, continues through crop maintenance, and ends with harvest, storage, and marketing.</p>
  </div>
  <div class="lesson-section">
    <h2>Key Crop Management Practices</h2>
    <ul>
      <li><strong>Seedbed preparation</strong> — soil must be prepared to the right texture and condition for good seed germination.</li>
      <li><strong>Planting</strong> — seeds should be sown at the correct depth (usually 1.5 to 2.0 inches) to ensure proper moisture for germination.</li>
      <li><strong>Fertilisation</strong> — soils should be tested for available nutrients before applying fertilisers.</li>
      <li><strong>Pest management</strong> — pesticides and cultural practices control pests that threaten crop yield and quality.</li>
      <li><strong>Irrigation</strong> — the artificial application of water, critical in dry regions to maintain moisture for crop production.</li>
      <li><strong>Pruning</strong> — removing parts of the plant not required for growth; also serves as preventive maintenance against insects and disease.</li>
      <li><strong>Drainage</strong> — proper removal of excess water prevents waterlogging and root disease.</li>
      <li><strong>Harvesting</strong> — yield and quality depend on the harvest management strategy and timing.</li>
      <li><strong>Post-harvest storage</strong> — proper storage conditions maintain forage and grain quality after harvest.</li>
    </ul>
    <h3>Additional Best Practices</h3>
    <ul>
      <li>Increase crop diversity across the farm</li>
      <li>Follow crop rotation to preserve soil health</li>
      <li>Add nutrients based on soil testing results and crop needs</li>
      <li>Keep accurate records of expenses and profits</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>The Four Principles of Organic Farming</h2>
    <p>Organic farming provides a vision for agriculture that inspires environmentally friendly cultivation. The four guiding principles are:</p>
    <ul>
      <li><strong>Health</strong> — organic agriculture sustains and enhances the health of soils, plants, animals, humans, and the planet as one indivisible whole.</li>
      <li><strong>Fairness</strong> — organic agriculture builds relationships that ensure fairness with regard to the common environment and opportunities for all.</li>
      <li><strong>Ecology</strong> — organic agriculture is based on living ecological systems and cycles. It includes recycling and caring for the ecosystem — protecting air, water, biodiversity, climate, and land.</li>
      <li><strong>Care</strong> — organic agriculture should be managed in a precautionary and responsible manner to protect the health and wellbeing of current and future generations.</li>
    </ul>
  </div>`,
  summary: [
    'Crop management begins with seedbed preparation and ends with harvest, storage, and marketing',
    'Key practices include fertilisation (based on soil testing), pest management, irrigation, pruning, and drainage',
    'Crop rotation alternates different crops each season to preserve soil nutrients and reduce disease risk',
    'Good record-keeping of expenses and profits is essential for a profitable farm business',
    'The four principles of organic farming are: Health, Fairness, Ecology, and Care',
    'Organic farming avoids synthetic chemicals and aims to sustain soil, plant, animal, and human health',
  ],
  quiz: [
    {q:'What is the correct depth for sowing most crop seeds to ensure proper moisture for germination?', opts:['0.5 inches','1.5 to 2.0 inches','3 to 4 inches','6 inches'], ans:1},
    {q:'Why should soils be tested before applying fertilisers?', opts:['To determine which crop to plant','To check if the soil is too wet','To identify available plant nutrients and avoid over-application','To check soil temperature'], ans:2},
    {q:'Which of the four principles of organic farming focuses on environmental protection and recycling?', opts:['Health','Fairness','Ecology','Care'], ans:2},
    {q:'What does pruning help prevent in addition to improving plant shape?', opts:['Soil erosion','Insect and disease damage','Waterlogging','Excessive fruit production'], ans:1},
    {q:'Which practice involves alternating different crops on the same land each season?', opts:['Irrigation','Strip cropping','Crop rotation','Monoculture'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/soils-portal/soil-management/en/',label:'FAO Crop Management',desc:'Crop management systems, soil health, and sustainable farming practices from the FAO.'},
  ]
},

'g10-plant-propagation': {
  title: 'Plant Propagation Technology',
  strand: 'Strand 1: Crops · Unit 4', grade: 10, icon: '🌱',
  lessons: ['Sexual Propagation','Asexual / Vegetative Propagation','Technology in Plant Propagation'],
  currentLesson: 0,
  objectives: [
    'Explain what plant propagation is and distinguish between sexual and asexual propagation',
    'Evaluate the advantages and disadvantages of different propagation methods',
    'Identify how technology has improved plant propagation in horticulture and crop farming'
  ],
  keyTerms: [
    {word:'Plant propagation',def:'The process of growing new plants from a variety of sources: seeds, cuttings, and other plant parts.'},
    {word:'Sexual propagation',def:'Propagation involving the union of pollen and egg, leading to seed formation. Also called seed propagation.'},
    {word:'Asexual propagation',def:'Propagation using vegetative parts of the plant (leaves, stems, roots) to produce plants identical to the parent.'},
    {word:'Tissue culture',def:'A propagation technique that grows new plants from small pieces of plant tissue in a laboratory environment.'},
    {word:'Clone',def:'A group of plants derived from the same parent plant by asexual propagation — all genetically identical to the parent.'},
    {word:'Heat propagator',def:'A device used in horticulture to maintain warmth and moisture in newly propagated plants, improving survival rate.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Sexual Propagation (Seed Propagation)</h2>
    <p>Sexual propagation involves the union of pollen and egg, leading to seed formation. It is an old, easy, simple, and effective technique for ornamental plants, vegetables, fruits, and medicinal plants.</p>
    <p><strong>Advantages:</strong> produces large numbers quickly; seeds can be handled in large numbers; can produce hybrids with desirable traits.</p>
    <p><strong>Disadvantages:</strong> some plants produce no viable seeds; some seeds are very difficult or slow to germinate; causes genetic variability — offspring may not be identical to the parent plant.</p>
  </div>
  <div class="lesson-section">
    <h2>Asexual Propagation (Vegetative Propagation)</h2>
    <p>Asexual propagation uses vegetative parts of plants — leaves, stems, roots, or modified organs — to produce new plants. It produces clones: plants genetically identical to the parent. Methods include cutting, division, layering, grafting, budding, and tissue culture.</p>
    <p><strong>Advantages:</strong> all offspring are true-to-type; suitable for plants that cannot be propagated from seeds; decreases time to flowering (especially grafting and budding).</p>
    <p><strong>Disadvantages:</strong> only a small number of plants can be produced from each parent (except tissue culture); requires significant labour.</p>
  </div>
  <div class="lesson-section">
    <h2>Tissue Culture</h2>
    <p>Tissue culture grows new plants from small pieces of plant tissue in a controlled laboratory environment.</p>
    <p><strong>Advantages:</strong> large numbers produced in a short time from a tiny amount of tissue; plants are more likely to be disease-free; can be done year-round regardless of season.</p>
    <p><strong>Disadvantages:</strong> requires more labour and higher cost; plants may be less resilient if not properly acclimatised; material must be carefully screened before culture.</p>
  </div>
  <div class="lesson-section">
    <h2>Technology in Plant Propagation</h2>
    <p>Technology has improved plant propagation in several important ways:</p>
    <ul>
      <li><strong>Vegetative crop solutions</strong> — used in fields, greenhouses, and laboratories to produce cuttings or transplants at scale.</li>
      <li><strong>Heat propagators</strong> — devices that maintain warmth and moisture in newly propagated plants, significantly improving survival rates.</li>
      <li><strong>Seed propagation mats</strong> — electric heated rubber mats that maintain consistent soil temperature for seedlings, allowing year-round gardening even in cold conditions.</li>
      <li><strong>Tissue culture expansion</strong> — most commonly applied to herbaceous ornamentals and fruits. Provides uniform, disease-free plants where virus infestations had previously been a serious problem.</li>
    </ul>
  </div>`,
  summary: [
    'Plant propagation grows new plants from seeds (sexual) or vegetative parts (asexual)',
    'Sexual propagation produces large numbers quickly but offspring may vary genetically',
    'Asexual propagation produces clones identical to the parent — best for maintaining desirable traits',
    'Tissue culture produces disease-free, uniform plants year-round from tiny amounts of plant tissue',
    'Heat propagators and seed mats use technology to maintain ideal conditions for plant establishment',
    'The main drive behind propagation technology is increasing food production to meet growing demand',
  ],
  quiz: [
    {q:'Which type of propagation produces plants that are genetically identical to the parent?', opts:['Sexual propagation','Seed propagation','Asexual (vegetative) propagation','Hybrid propagation'], ans:2},
    {q:'What is a disadvantage of sexual propagation?', opts:['It produces too many plants','Offspring may not be identical to the parent due to genetic variability','It requires laboratory equipment','It can only be done in certain seasons'], ans:1},
    {q:'What is the main advantage of tissue culture over conventional asexual propagation?', opts:['It is cheaper and requires less equipment','It produces large numbers of disease-free plants year-round from tiny amounts of tissue','It produces hybrids only','It does not require laboratory conditions'], ans:1},
    {q:'A heat propagator is used in plant propagation to:', opts:['Cut stems into uniform lengths','Maintain warmth and moisture in newly propagated plants','Test soil pH before planting','Apply fertilisers to seedlings'], ans:1},
    {q:'What is a clone in plant propagation?', opts:['A plant produced by cross-pollination','A plant that has been genetically modified in a laboratory','A group of plants derived from the same parent by asexual propagation','A seed-produced hybrid variety'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/horticulture/en/',label:'FAO Horticulture',desc:'Plant propagation, horticulture technology, and crop production from the FAO.'},
  ]
},

'g10-types-plants': {
  title: 'Types of Agricultural Plants',
  strand: 'Strand 1: Crops · Unit 5', grade: 10, icon: '🌺',
  lessons: ['Plantation Crops','Ornamental Plants','Bedding Plants & Classification'],
  currentLesson: 0,
  objectives: [
    'Identify and describe the major types of plantation crops and their uses',
    'Classify ornamental plants and explain their characteristics and roles in horticulture',
    'Describe the four categories of bedding plants and their cultivation contexts'
  ],
  keyTerms: [
    {word:'Plantation crop',def:'A large-scale commercial crop grown on a plantation. Major PNG plantation crops include coconut, oil palm, tea, coffee, and cocoa.'},
    {word:'Beverage crop',def:'Crops whose products are processed into beverages other than water — e.g., tea, coffee, and cocoa.'},
    {word:'Ornamental plant',def:'A plant grown for decorative purposes in landscaping, gardens, or indoor settings rather than for food or industrial use.'},
    {word:'Floriculture',def:'The cultivation of ornamental plants. Forms a major branch of horticulture.'},
    {word:'Herbaceous ornamental plant',def:'An ornamental plant with a soft, non-woody stem. Examples include annuals, biennials, perennials, and aquatic ornamentals.'},
    {word:'Bedding plant',def:'Plants used to create colourful displays in garden beds — categorised as hardy annuals, tender annuals, hardy biennials, and corms or tubers.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Plantation Crops</h2>
    <p>Plantation crops constitute a large group of commercial crops. The major plantation crops include coconut, oil palm, cashew, tea, coffee, and rubber; the minor plantation crops include cocoa. They are classified as follows:</p>
    <ul>
      <li><strong>Beverage crops</strong> — crops processed into beverages: tea, coffee, cocoa</li>
      <li><strong>Oil yielding crops</strong> — crops grown to extract oil: coconut, oil palm</li>
      <li><strong>Nuts</strong> — dry single-seeded fruits with high oil content: cashew</li>
      <li><strong>Industrial crops</strong> — crops used in industrial production: rubber</li>
      <li><strong>Masticatory crops</strong> — crops used for chewing: arecanut, betel vine</li>
    </ul>
    <p>In Papua New Guinea, oil palm, coconut, cocoa, and coffee are all significant plantation crops that contribute substantially to agricultural export revenue.</p>
  </div>
  <div class="lesson-section">
    <h2>Ornamental Plants</h2>
    <p>Ornamental plants are grown for decorative purposes. Their cultivation is called <strong>floriculture</strong>. They are divided into two main categories:</p>
    <h3>A. Herbaceous Ornamental Plants (soft-stemmed)</h3>
    <ul>
      <li><strong>Annuals</strong> — Winter season: Dahlia, Poppy, Dianthus, Marigold. Summer: Balsam, Cockscomb. All-season: Sunflower, Zinnia.</li>
      <li><strong>Biennials</strong> — Hollyhock, Sweet William.</li>
      <li><strong>Perennials</strong> — for flowers: Phlox, Gladiolus.</li>
      <li><strong>Aquatic ornamentals</strong> — Lotus, water lily, red water lily.</li>
      <li><strong>Orchids</strong> — Vanda, Dendrobium, Vanilla.</li>
    </ul>
    <h3>B. Woody Ornamental Plants (hard-stemmed)</h3>
    <ul>
      <li>Flowering shrubs: Rose, Jasmine, China rose</li>
      <li>Ornamental palms: Bottle palm, Fishtail palm, Oil palm, Chinese palm</li>
      <li>Creepers and climbers: Bougainvillea</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Bedding Plants</h2>
    <p>Bedding plants are categorised into four main groups:</p>
    <ul>
      <li><strong>Hardy annuals</strong> — Grown directly early in the season. Examples: poppy, sunflower, dianthus.</li>
      <li><strong>Tender annual (perennial) plants</strong> — Planted as young plants after frost. Examples: begonia, petunia, chrysanthemum, fuchsia.</li>
      <li><strong>Hardy biennial plants</strong> — Discarded after flowering. Examples: daisy, foxglove, cornflower, pansies.</li>
      <li><strong>Corms or tubers</strong> — Planted each year and lifted after the plant naturally dies. Examples: narcissus, hyacinth, gladiolus.</li>
    </ul>
  </div>`,
  summary: [
    'Major plantation crops in PNG include coconut, oil palm, cocoa, coffee, cashew, tea, and rubber',
    'Plantation crops are classified as beverage, oil-yielding, nut, industrial, or masticatory crops',
    'Ornamental plants are grown for decoration; their cultivation is called floriculture',
    'Herbaceous ornamentals have soft stems (annuals, biennials, perennials, aquatics); woody ornamentals have hard stems',
    'Bedding plants are categorised as hardy annuals, tender annuals, hardy biennials, and corms or tubers',
    'Key orchid genera in PNG include Vanda, Dendrobium, and Vanilla — all ornamentally important',
  ],
  quiz: [
    {q:'Which of the following is classified as a beverage crop?', opts:['Coconut','Oil palm','Cocoa','Rubber'], ans:2},
    {q:'What is the term for the cultivation of ornamental plants?', opts:['Pomology','Olericulture','Floriculture','Arboriculture'], ans:2},
    {q:'Which category of bedding plant is planted each year and lifted once the plant naturally dies?', opts:['Hardy annuals','Tender annuals','Hardy biennials','Corms or tubers'], ans:3},
    {q:'Which of the following is a woody ornamental plant?', opts:['Sunflower','Marigold','Bougainvillea','Water lily'], ans:2},
    {q:'What type of crop is rubber classified as?', opts:['Beverage crop','Masticatory crop','Industrial crop','Oil yielding crop'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/horticulture/en/',label:'FAO Horticulture',desc:'Plantation crops, ornamental horticulture, and floriculture resources from the FAO.'},
  ]
},

'g10-ornamental-cultivation': {
  title: 'Cultivation of Ornamental & Bedding Plants',
  strand: 'Strand 1: Crops · Unit 6', grade: 10, icon: '🌸',
  lessons: ['Cultivating Ornamental Plants','Propagating Ornamentals','Care & Maintenance'],
  currentLesson: 0,
  objectives: [
    'Describe and distinguish cultivation practices for ornamental and bedding plants in different environments',
    'Explain how ornamental plants are propagated and established',
    'Identify the key care and maintenance practices that keep ornamental plants healthy and attractive'
  ],
  keyTerms: [
    {word:'Floriculture',def:'The branch of horticulture dealing with the cultivation and management of ornamental plants for sale or for use in decoration.'},
    {word:'Pruning (ornamentals)',def:'Cutting back stems or branches of ornamental plants to maintain shape, encourage flowering, or remove diseased parts.'},
    {word:'Containerised planting',def:'Growing ornamental plants in pots or containers rather than open ground, allowing better control of soil conditions.'},
    {word:'Greenhouse cultivation',def:'Growing plants in a controlled glass or plastic enclosure that regulates temperature, humidity, and light.'},
    {word:'Deadheading',def:'Removing spent flowers from ornamental plants to encourage continued blooming and maintain the plant\'s appearance.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Cultivation of Ornamental Plants</h2>
    <p>The cultivation of ornamental plants is called <strong>floriculture</strong>. For plants to be considered ornamental, they require specific work and care — including pruning, training, and regular maintenance — to maintain their decorative appearance.</p>
    <p>Ornamental plants can be cultivated in a variety of settings:</p>
    <ul>
      <li><strong>Open ground gardens</strong> — planted directly in prepared garden beds with well-drained, nutrient-rich soil.</li>
      <li><strong>Containers and pots</strong> — allows ornamentals to be grown on patios, balconies, or indoors. Gives control over soil type, moisture, and feeding.</li>
      <li><strong>Greenhouses</strong> — controlled environments used for tropical and tender ornamentals that cannot survive outdoors in cooler climates.</li>
      <li><strong>Nurseries</strong> — commercial facilities where ornamentals are propagated and grown before sale to the public or for landscaping projects.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Propagating Ornamental Plants</h2>
    <ul>
      <li><strong>Seed propagation</strong> — suitable for many annuals and biennials (e.g., marigold, sunflower, zinnia).</li>
      <li><strong>Cuttings</strong> — a stem, leaf, or root cutting taken from the parent plant and placed in a rooting medium. Used for shrubs, roses, and perennials.</li>
      <li><strong>Division</strong> — clumping plants are dug up and divided into sections, each with roots attached, and replanted.</li>
      <li><strong>Layering</strong> — a stem is bent to the ground, partially buried, and allowed to root before being separated from the parent.</li>
      <li><strong>Grafting and budding</strong> — used for woody ornamentals such as roses and ornamental fruit trees.</li>
      <li><strong>Tissue culture</strong> — used commercially to produce large numbers of uniform, disease-free ornamentals (particularly orchids and ferns).</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Care and Maintenance of Ornamental Plants</h2>
    <ul>
      <li><strong>Watering</strong> — ornamentals need consistent moisture but must not be overwatered.</li>
      <li><strong>Fertilising</strong> — regular feeding with balanced fertilisers during the growing season promotes healthy growth and flowering.</li>
      <li><strong>Pruning and deadheading</strong> — removing spent flowers (deadheading) encourages continued blooming. Pruning maintains shape and removes diseased material.</li>
      <li><strong>Pest and disease control</strong> — ornamentals are susceptible to aphids, scale insects, fungal diseases, and root rot. Regular inspection and timely treatment prevents spread.</li>
      <li><strong>Mulching</strong> — applying organic mulch conserves soil moisture, suppresses weeds, and moderates soil temperature.</li>
      <li><strong>Staking and training</strong> — tall or climbing ornamentals require stakes, trellises, or frames for support.</li>
    </ul>
  </div>`,
  summary: [
    'The cultivation of ornamental plants is called floriculture — a major branch of horticulture',
    'Ornamentals can be grown in open ground, containers, greenhouses, or nurseries',
    'Propagation methods include seed sowing, cuttings, division, layering, grafting, budding, and tissue culture',
    'Tissue culture is used commercially for orchids and ferns to produce large numbers of disease-free plants',
    'Regular watering, fertilising, pruning, deadheading, and pest control are essential for ornamental plant health',
    'Deadheading — removing spent flowers — encourages ornamental plants to continue blooming',
  ],
  quiz: [
    {q:'What is floriculture?', opts:['The study of forest management','The branch of horticulture dealing with cultivation of ornamental plants','The science of crop rotation in agriculture','The processing of cut flowers only'], ans:1},
    {q:'Which propagation method involves bending a stem to the ground, partially burying it, and allowing it to root before separation?', opts:['Grafting','Division','Tissue culture','Layering'], ans:3},
    {q:'What is deadheading in ornamental plant care?', opts:['Removing dead plants from the garden','Removing spent flowers to encourage continued blooming','Cutting back all growth at the end of the season','Applying pesticides to control insects'], ans:1},
    {q:'Why are containers useful for growing ornamental plants?', opts:['They prevent plants from growing too tall','They allow better control of soil type, moisture, and feeding','They eliminate the need for fertilisers','They make plants grow faster than in open ground'], ans:1},
    {q:'Tissue culture is commercially used for which ornamental plants?', opts:['Sunflowers and marigolds','Roses and lawns','Orchids and ferns','Bedding annuals and biennials'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/horticulture/en/',label:'FAO Horticulture',desc:'Ornamental plant cultivation, floriculture, and horticultural production from the FAO.'},
  ]
},

'g10-horticulture-tech': {
  title: 'Technology in Horticulture Production',
  strand: 'Strand 1: Crops · Unit 7', grade: 10, icon: '💡',
  lessons: ['Processing & Preservation Technology','Packaging & Transportation','Marketing Technology & Regulation'],
  currentLesson: 0,
  objectives: [
    'Identify and explain how technology is used in the processing and preservation of horticulture products',
    'Describe packaging and transportation technology used for horticulture products',
    'Explain how technology is used in the marketing and regulation of horticulture products'
  ],
  keyTerms: [
    {word:'Post-harvest processing',def:'All steps taken after a crop is harvested to prepare it for sale — including cleaning, grading, packaging, and storage.'},
    {word:'Cold chain',def:'A temperature-controlled supply chain that keeps perishable horticultural products cold from harvest through to the consumer.'},
    {word:'Grading',def:'Sorting harvested produce into categories based on size, weight, colour, and quality — essential for commercial marketing.'},
    {word:'Modified atmosphere packaging',def:'Packaging technology that alters the gas composition inside a package to extend the shelf life of fresh produce.'},
    {word:'E-commerce',def:'Buying and selling goods and services online. Increasingly used by PNG farmers to reach direct buyers and markets.'},
    {word:'Food regulation',def:'Government rules that set standards for the quality, safety, labelling, and export of food and agricultural products.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Processing and Preservation Technology</h2>
    <p>Horticultural products are highly perishable. Technology is used to slow deterioration and extend shelf life.</p>
    <h3>Processing Technologies</h3>
    <ul>
      <li><strong>Washing and cleaning equipment</strong> — mechanical washers remove soil and pesticide residues from fruit and vegetables before packaging.</li>
      <li><strong>Grading and sorting machines</strong> — optical sensors and weight-based machines sort produce by size, colour, and quality.</li>
      <li><strong>Drying and dehydration</strong> — solar dryers and mechanical dryers remove moisture from fruits, vegetables, and spices to extend shelf life.</li>
      <li><strong>Juicing and processing</strong> — equipment to extract juice, make sauces, jams, and preserves from surplus or lower-grade fruit.</li>
    </ul>
    <h3>Preservation Technologies</h3>
    <ul>
      <li><strong>Refrigeration and cold storage</strong> — the most important preservation technology. Cold storage slows biological processes that cause spoilage.</li>
      <li><strong>Modified atmosphere packaging (MAP)</strong> — adjusts oxygen, carbon dioxide, and nitrogen levels inside packaging to slow ripening and decay.</li>
      <li><strong>Vacuum packaging</strong> — removes air from packaging to prevent oxidation and spoilage.</li>
      <li><strong>Wax coating</strong> — edible wax applied to fruits to reduce moisture loss and extend shelf life.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Packaging and Transportation Technology</h2>
    <ul>
      <li><strong>Corrugated cardboard boxes</strong> — the standard for packing and stacking fruit and vegetables for export. Ventilated to allow airflow.</li>
      <li><strong>Clamshell packs and flow-wrapping</strong> — used for small fruits, berries, and vegetables in retail settings.</li>
      <li><strong>Refrigerated transport (cool trucks and reefer containers)</strong> — maintain cold temperatures during transport. Essential for export of fresh produce from PNG.</li>
      <li><strong>Tracking systems</strong> — GPS and barcode systems track produce through the supply chain from farm to retailer.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Marketing Technology and Regulation</h2>
    <h3>Marketing Technology</h3>
    <ul>
      <li><strong>E-commerce platforms</strong> — online marketplaces allow farmers to list and sell products directly to buyers, reducing dependence on middlemen.</li>
      <li><strong>Social media marketing</strong> — Facebook and similar platforms are widely used in PNG to advertise fresh produce and connect with buyers.</li>
      <li><strong>Mobile money</strong> — payment apps allow farmers in remote areas to receive payment digitally.</li>
    </ul>
    <h3>Food Regulation</h3>
    <p>Government regulations set standards for the quality, safety, and labelling of horticulture products. In Papua New Guinea, the <strong>National Agriculture and Quarantine Inspection Authority (NAQIA)</strong> regulates the import and export of agricultural products, enforcing biosecurity rules and quality standards. Compliance with food safety regulations is essential for accessing export markets.</p>
  </div>`,
  summary: [
    'Post-harvest processing includes washing, grading, drying, and packaging to prepare produce for sale',
    'Cold storage is the most important preservation technology, slowing spoilage by keeping produce cold',
    'Modified atmosphere packaging (MAP) adjusts gas composition inside packaging to slow ripening and decay',
    'Refrigerated transport (cool trucks and reefer containers) maintains cold temperatures during delivery',
    'E-commerce and social media allow PNG farmers to sell directly to buyers, reducing reliance on middlemen',
    'NAQIA regulates PNG agricultural imports and exports, enforcing biosecurity and quality standards',
  ],
  quiz: [
    {q:'What is the cold chain?', opts:['A chain of farm suppliers for cold-climate crops','A temperature-controlled supply system that keeps produce cold from harvest to consumer','A method of freezing produce in the field','A government regulation on food storage'], ans:1},
    {q:'What does Modified Atmosphere Packaging (MAP) do?', opts:['Adds vitamins to packaged produce','Adjusts gas composition inside packaging to slow ripening and decay','Removes moisture from fresh produce through vacuum suction','Seals produce in wax coating to prevent bruising'], ans:1},
    {q:'Which technology allows farmers in PNG to receive payment for produce sold online?', opts:['Cold storage refrigeration','Barcode tracking systems','Mobile money platforms','Grading machines'], ans:2},
    {q:'What is the role of NAQIA in Papua New Guinea?', opts:['Managing rural farming cooperatives','Setting school curriculum standards for Agriculture','Regulating agricultural imports and exports and enforcing biosecurity','Providing loans to agribusiness operators'], ans:2},
    {q:'Which packaging type is standard for exporting fresh fruit and vegetables?', opts:['Vacuum bags','Clamshell packs','Ventilated corrugated cardboard boxes','Wax-coated paper wraps'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/horticulture/en/',label:'FAO Horticulture Technology',desc:'Post-harvest processing, packaging, and marketing technology for horticultural products.'},
  ]
},

'g10-agribusiness-startup': {
  title: 'Starting Up an Agribusiness',
  strand: 'Strand 5: Agribusiness · Unit 3', grade: 10, icon: '🚀',
  lessons: ['Managing Risk in Agribusiness','Sources of Start-up Capital','Managing Start-up Capital'],
  currentLesson: 0,
  objectives: [
    'Analyse and discuss the best practices of risk management for agribusiness',
    'Identify and explain the processes of obtaining start-up capital for an agribusiness',
    'Evaluate the strengths and weaknesses of different sources of finance for agribusiness start-up'
  ],
  keyTerms: [
    {word:'Production risk',def:'Risk arising from the dependence of crop and livestock performance on weather, pests, and disease — all beyond the farmer\'s control.'},
    {word:'Marketing risk',def:'Risk arising from unpredictable changes in prices and costs of farm products.'},
    {word:'Financial risk',def:'Risk arising when money is borrowed to finance the farm business — including uncertainty about future interest rates and ability to repay.'},
    {word:'Institutional risk',def:'Risk from unpredictable changes in the services provided by banks, cooperatives, and government extension services.'},
    {word:'Human risk',def:'Risk to the farm business caused by illness, death, accidents, or labour migration away from the farm.'},
    {word:'Start-up capital',def:'The initial finance needed to establish and begin operating a new business.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Sources of Risk in Agribusiness</h2>
    <p>The most common sources of risk in farming can be divided into five areas:</p>
    <ul>
      <li><strong>Production risk</strong> — Crop and livestock performance depends on biological processes affected by weather and pests. Low rainfall, drought, hail, or heavy rains could damage or wipe out crops. Pest or disease outbreaks can cause major losses.</li>
      <li><strong>Marketing risk</strong> — Changes in prices are beyond the control of any individual farmer. Supply and demand changes unexpectedly. When farmers commit resources to production, they do not know for certain what prices they will receive.</li>
      <li><strong>Financial risk</strong> — Occurs when money is borrowed to finance the farm business. Smallholder farmers who borrow at high interest rates may have difficulty with debt repayment when prices are low or yields are poor.</li>
      <li><strong>Institutional risk</strong> — Unpredictable changes in services from banks, cooperatives, marketing organisations, and government extension services. Government policy changes (subsidies, food quality regulations) can have a major impact on farm business performance.</li>
      <li><strong>Human and personal risk</strong> — Risks caused by illness, death, accidents, and labour migration. In PNG, migration away from rural areas can cause serious labour shortages for the farm.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Risk Management Strategies</h2>
    <ul>
      <li><strong>Diversification</strong> — growing multiple crops or combining crops and livestock to spread risk.</li>
      <li><strong>Crop insurance</strong> — financial products that compensate farmers for losses caused by weather events, pests, or disease.</li>
      <li><strong>Contract farming</strong> — agreeing a fixed price with a buyer before planting, reducing marketing risk.</li>
      <li><strong>Building financial reserves</strong> — maintaining savings to absorb losses in bad seasons.</li>
      <li><strong>Joining cooperatives</strong> — pooling resources and market access to reduce costs and improve bargaining power.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Obtaining and Managing Start-up Capital</h2>
    <p>Sources of start-up capital for an agribusiness include:</p>
    <ul>
      <li><strong>Personal savings</strong> — the most common source for small-scale farmers in PNG. No debt or interest involved, but limited in scale.</li>
      <li><strong>Family and community contributions</strong> — informal funding from family members or community groups. Common in PNG wantok networks.</li>
      <li><strong>Bank loans</strong> — formal credit from commercial banks. Requires collateral and a business plan. Interest payments are a financial risk if revenue is low.</li>
      <li><strong>Government grants and programmes</strong> — the PNG government and organisations such as the Small Business Development Corporation (SBDC) offer grants and subsidised loans.</li>
      <li><strong>Microfinance</strong> — small loans from microfinance institutions suited to smallholder farmers without traditional collateral.</li>
      <li><strong>NGO and development funding</strong> — non-government organisations sometimes provide start-up support for community agribusiness projects.</li>
    </ul>
    <p>Managing start-up capital wisely requires keeping detailed records of all expenditure, prioritising essential inputs, avoiding unnecessary debt, and planning cash flow to ensure the business can meet its obligations while waiting for the first harvest revenue.</p>
  </div>`,
  summary: [
    'The five sources of risk in agribusiness are: production, marketing, financial, institutional, and human risk',
    'Production risk arises from weather, pests, and disease affecting crop and livestock performance',
    'Marketing risk comes from unpredictable changes in product prices beyond the farmer\'s control',
    'Financial risk occurs when borrowed money cannot be repaid due to low yields or low prices',
    'Risk management strategies include diversification, insurance, contract farming, and joining cooperatives',
    'Sources of start-up capital include personal savings, family contributions, bank loans, government grants, and microfinance',
  ],
  quiz: [
    {q:'Which type of risk in agribusiness is caused by unpredictable changes in crop prices?', opts:['Production risk','Marketing risk','Financial risk','Institutional risk'], ans:1},
    {q:'A smallholder farmer borrows money at high interest rates. If yields are poor, what risk does this create?', opts:['Institutional risk','Human risk','Financial risk','Production risk'], ans:2},
    {q:'What is diversification as a risk management strategy?', opts:['Growing only one high-value crop','Borrowing from multiple lenders','Growing multiple crops or combining crops and livestock to spread risk','Selling produce to only one buyer'], ans:2},
    {q:'Which source of start-up capital involves no debt or interest?', opts:['Bank loans','Microfinance','Government grants','Personal savings'], ans:3},
    {q:'Human risk in agribusiness includes:', opts:['Drought and pest outbreaks','Changes in government agricultural policy','Illness, death, and labour migration away from the farm','Falling market prices for produce'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/rural-employment/agricultural-entrepreneurship/en/',label:'FAO Agribusiness',desc:'Agribusiness start-up, risk management, and capital management resources from the FAO.'},
  ]
},


'g10-animal-breeds': {
  title: 'Breeds of Monogastric & Polygastric Animals',
  strand: 'Strand 2: Animals · Unit 1', grade: 10, icon: '🐄',
  lessons: ['Characteristics of Monogastric & Polygastric Animals','Physiology: Digestive & Reproductive Systems','Online Marketing of Animal Products'],
  currentLesson: 0,
  objectives: [
    'Compare and discuss the characteristics which distinguish monogastric and polygastric animals',
    'Analyse and explain the physiology systems and functions of monogastric and polygastric animals',
    'Identify types of technology that enable online marketing of animal products'
  ],
  keyTerms: [
    {word:'Monogastric animal',def:'An animal with a single-chambered stomach that is omnivorous in feeding behaviour. Examples: pigs, rabbits.'},
    {word:'Polygastric animal',def:'An animal with a four-chambered stomach (ruminant) that is herbivorous in feeding behaviour. Examples: cattle, goats, sheep.'},
    {word:'Rumen',def:'The largest stomach chamber in polygastric (ruminant) animals, where microbial fermentation of plant material takes place.'},
    {word:'Skeletal system',def:'The system of bones that provides a framework for the body, protects vital organs, and allows movement.'},
    {word:'Reproductive system',def:'The biological system responsible for the survival of the species through production of offspring.'},
    {word:'Digital marketing',def:'The use of internet, computers, and social media to market and sell animal products to buyers online.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Characteristics of Monogastric and Polygastric Animals</h2>
    <p>The characteristics of monogastric and polygastric animals depend mainly on differences in their size and their digestive system.</p>
    <h3>Monogastric Animals</h3>
    <p>Monogastric animals have a single stomach compartment and many are omnivorous in their feeding behaviour — meaning they eat both plant matter and animal matter. Examples:</p>
    <ul>
      <li><strong>Pigs</strong> — eat both plant matter and animal matter</li>
      <li><strong>Rabbits</strong> — eat mainly plant matter</li>
    </ul>
    <p>Key characteristics of monogastric animals: single-chambered stomach; omnivores in eating habits.</p>
    <h3>Polygastric Animals</h3>
    <p>Polygastric animals have two or more storage compartment stomachs and are herbivorous in their feeding behaviour — meaning they consume mainly plant matter. Examples:</p>
    <ul>
      <li><strong>Cattle</strong> — farmed for meat and milk</li>
      <li><strong>Goats</strong> — farmed for meat and milk</li>
      <li><strong>Sheep</strong> — farmed for meat</li>
    </ul>
    <p>Key characteristics of polygastric animals: larger body size; four-chambered stomach; rumen is the largest chamber; more efficient digestive system; consume mainly plant matter.</p>
    <h3>Key Differences</h3>
    <ul>
      <li>Polygastrics are bigger in size compared to monogastric animals</li>
      <li>Polygastrics have a more efficient digestive system</li>
      <li>Polygastrics mainly consume plant matter; monogastrics are omnivorous</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Physiology: Skeletal, Digestive, and Reproductive Systems</h2>
    <p>Animal physiology is the scientific study of the life-supporting properties, functions, and processes of animals. The systems most important to a farmer are the skeletal, digestive, and reproductive systems.</p>
    <h3>Skeletal System</h3>
    <p>The skeletal system is made of bones. Its functions are: providing a framework for the body where muscles are attached; protecting vital organs; and allowing movement. Skeletal systems do not differ greatly between monogastric and polygastric animals, though the functions of individual bones may vary (e.g. wings in birds are used for flying).</p>
    <h3>Digestive System</h3>
    <p>The digestive systems of polygastric animals are quite different from monogastric animals. Sheep and cattle have four stomachs — the first is called the rumen. Animals with four stomachs are called ruminants or polygastric animals. Animals like pigs and poultry have a single stomach and cannot digest cellulose because they do not have a rumen.</p>
    <h3>Reproductive System</h3>
    <p>Reproduction is necessary for the survival of any species. Understanding animal reproductive physiology enables the development of reproductive technologies like artificial insemination, embryo transfer, and sexing semen. By studying developmental biology, farmers can better understand crucial developmental periods during gestation and make appropriate adjustments in feeding and management.</p>
  </div>
  <div class="lesson-section">
    <h2>Technology for Online Marketing of Animal Products</h2>
    <p>The livestock industry has become the most dynamic market globally, driven largely by demand growth and modern technology. More and more farmers are beginning to use technology and computers for marketing their products.</p>
    <p>Computer programs have been designed for convenience to farmers — breeders can evaluate data, generate annual production reports, and market their animal products through websites and social media. Key technologies for online marketing include:</p>
    <ul>
      <li><strong>Computers and internet</strong> — for accessing online marketplaces and communicating with buyers</li>
      <li><strong>Social media platforms</strong> — Facebook and similar platforms widely used in PNG to advertise live animals and animal products</li>
      <li><strong>Farm management software</strong> — programs that allow farmers to track production data and link production records to online sales</li>
      <li><strong>Mobile phones</strong> — allow farmers in remote areas to receive payment digitally and manage sales transactions</li>
    </ul>
    <p>The relationship between technology innovation, digital marketing, and livestock industry performance improves overall competitiveness both locally and internationally.</p>
  </div>`,
  summary: [
    'Monogastric animals have one stomach and are omnivorous (e.g. pigs, rabbits)',
    'Polygastric animals have four stomach chambers, are herbivorous, and are larger in size (e.g. cattle, goats, sheep)',
    'The rumen is the largest stomach chamber in polygastric ruminant animals',
    'The skeletal system provides a framework, protects organs, and allows movement',
    'Monogastrics cannot digest cellulose because they lack a rumen',
    'Online marketing of animal products uses social media, computers, farm software, and mobile payments',
  ],
  quiz: [
    {q:'Which of the following is a characteristic of polygastric animals?', opts:['Single-chambered stomach','Omnivorous feeding behaviour','Four-chambered stomach with rumen','Small body size'], ans:2},
    {q:'Why can pigs not live on cellulose as their main food source?', opts:['They are too small to digest grass','They do not have a rumen to ferment plant material','They prefer animal protein','Their teeth cannot grind plant material'], ans:1},
    {q:'What is the rumen?', opts:['The smallest stomach chamber in polygastric animals','The large intestine of monogastric animals','The largest stomach chamber in ruminant (polygastric) animals','A part of the skeletal system'], ans:2},
    {q:'What are the three main functions of the skeletal system?', opts:['Digestion, reproduction, and breathing','Providing framework, protecting organs, and allowing movement','Producing blood, filtering toxins, and storing fat','Absorbing nutrients, producing hormones, and pumping blood'], ans:1},
    {q:'Which technology is widely used in PNG for marketing animal products directly to buyers?', opts:['Television advertising','Social media platforms','Government trade fairs only','Print catalogues'], ans:1},
  ],
  furtherReading: [
    {url:'https://www.fao.org/animal-production/en/',label:'FAO Animal Production',desc:'Animal physiology, livestock management, and farm animal science from the FAO.'},
  ]
},

'g10-animal-physiology': {
  title: 'Animal Physiology: Digestive & Reproductive Systems',
  strand: 'Strand 2: Animals · Unit 1', grade: 10, icon: '🔬',
  lessons: ['Monogastric Digestive Physiology','Polygastric Digestive Physiology','Reproductive Physiology'],
  currentLesson: 0,
  objectives: [
    'Compare the digestive systems of monogastric and polygastric animals',
    'Describe the processes and functions in the digestive systems of different animal types',
    'Explain the reproductive estrus cycle and reproductive technologies in farm animals'
  ],
  keyTerms: [
    {word:'Physiology',def:'Derived from Greek — the study of nature or normal process or function. Animal physiology is the scientific study of the life-supporting functions of animals.'},
    {word:'Ruminant',def:'An animal with a four-chambered stomach (rumen, reticulum, omasum, abomasum) that digests food through microbial fermentation. Examples: cattle, goats, sheep.'},
    {word:'Cellulose',def:'The tough plant material that makes up cell walls. Polygastric animals can digest cellulose in the rumen; monogastric animals cannot.'},
    {word:'Estrus cycle',def:'The reproductive cycle in female mammals, characterised by periods of fertility (estrus) followed by periods of infertility.'},
    {word:'Artificial insemination',def:'A reproductive technology where sperm is introduced into the female reproductive tract without natural mating.'},
    {word:'Embryo transfer',def:'A reproductive technology where an embryo is removed from a donor animal and implanted into a recipient animal.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Monogastric Digestive System</h2>
    <p>Monogastric animals have a simple, single-chambered stomach. Food passes from the mouth, through the oesophagus, into the stomach where acid and enzymes begin breaking it down, then through the small intestine (where most nutrients are absorbed), and finally through the large intestine.</p>
    <p>Because monogastric animals have only one stomach chamber with no rumen, they cannot break down cellulose (the main structural component of plant cell walls). This means pigs and poultry cannot live on grass or high-fibre plant material as their sole food source — they require higher-quality feed with readily digestible nutrients.</p>
    <p>Monogastric animals include: pigs, rabbits, poultry (chickens, ducks, turkeys), and humans.</p>
  </div>
  <div class="lesson-section">
    <h2>Polygastric (Ruminant) Digestive System</h2>
    <p>Polygastric animals (ruminants) have a four-chambered stomach, allowing them to digest cellulose-rich plant material like grass, leaves, and crop residues. The four chambers are:</p>
    <ul>
      <li><strong>Rumen</strong> — the largest chamber. Microbial fermentation of cellulose takes place here, producing volatile fatty acids that provide energy to the animal.</li>
      <li><strong>Reticulum</strong> — the second chamber, which helps sort feed material. Heavy objects ingested accidentally (stones, wire) settle here.</li>
      <li><strong>Omasum</strong> — the third chamber, which absorbs water and further grinds feed material.</li>
      <li><strong>Abomasum</strong> — the fourth chamber, equivalent to the single stomach of monogastric animals. True enzymatic digestion takes place here.</li>
    </ul>
    <p>Ruminants regurgitate partially digested food (cud) and chew it again — this is called <em>rumination</em> or "chewing the cud." This further breaks down plant material before it passes to the omasum and abomasum.</p>
    <p>Polygastric animals include: cattle, goats, sheep, deer, and buffalo.</p>
  </div>
  <div class="lesson-section">
    <h2>Reproductive Physiology</h2>
    <p>Reproduction is necessary for the survival of any species. Understanding animal reproductive physiology is essential for effective farm management. Through improved understanding, reproductive technologies have been developed including:</p>
    <ul>
      <li><strong>Artificial insemination (AI)</strong> — sperm from a selected sire is introduced into the female without natural mating. Allows a single high-quality male to father many offspring and eliminates the need to keep a breeding male on every farm.</li>
      <li><strong>Embryo transfer</strong> — embryos are removed from a high-value donor female and implanted into surrogate recipient females. Allows a superior female to produce many more offspring than would be possible through natural reproduction.</li>
      <li><strong>Estrus synchronisation</strong> — hormonal treatments used to synchronise the reproductive cycles of a group of females, allowing them all to be mated or artificially inseminated at the same time.</li>
      <li><strong>Sexing of semen</strong> — technology that separates sperm carrying X chromosomes (producing females) from sperm carrying Y chromosomes (producing males), allowing farmers to choose the sex of offspring.</li>
    </ul>
    <p>By studying developmental biology, farmers can better understand crucial developmental periods during gestation and make appropriate adjustments in how animals are managed and fed during pregnancy.</p>
  </div>`,
  summary: [
    'Monogastric animals have one stomach and cannot digest cellulose — they need high-quality feed',
    'Polygastric (ruminant) animals have four stomach chambers: rumen, reticulum, omasum, and abomasum',
    'The rumen contains microbes that ferment cellulose, allowing ruminants to live on grass and plant material',
    'Rumination (chewing the cud) further breaks down plant material before it enters the abomasum',
    'Reproductive technologies include artificial insemination, embryo transfer, estrus synchronisation, and sexed semen',
    'These technologies allow farmers to improve livestock genetics and increase production efficiency',
  ],
  quiz: [
    {q:'In what order do the four stomach chambers of a ruminant occur?', opts:['Omasum, Rumen, Reticulum, Abomasum','Rumen, Reticulum, Omasum, Abomasum','Abomasum, Omasum, Reticulum, Rumen','Reticulum, Abomasum, Rumen, Omasum'], ans:1},
    {q:'What is the main function of the rumen?', opts:['Absorbing water from digested feed','Microbial fermentation of cellulose from plant material','Secreting digestive enzymes like the stomach','Grinding food with muscular contractions'], ans:1},
    {q:'Which reproductive technology allows one high-quality male to father many offspring without natural mating?', opts:['Embryo transfer','Estrus synchronisation','Artificial insemination','Sexing of semen'], ans:2},
    {q:'Why can polygastric animals survive on grass when monogastric animals cannot?', opts:['They have stronger teeth for grinding grass','They have microbes in their rumen that can ferment and digest cellulose','They need less energy than monogastric animals','They have a longer digestive tract'], ans:1},
    {q:'What is rumination?', opts:['The process of adding microbes to the rumen','The regurgitation and re-chewing of partially digested food (cud)','The absorption of nutrients in the small intestine','The fermentation of grain in the abomasum'], ans:1},
  ],
  furtherReading: [
    {url:'https://www.fao.org/animal-production/en/',label:'FAO Animal Production',desc:'Animal physiology, digestive systems, and reproductive science from the FAO.'},
  ]
},

'g10-animal-husbandry': {
  title: 'Animal Husbandry & Management Practices',
  strand: 'Strand 2: Animals · Unit 2', grade: 10, icon: '🐖',
  lessons: ['What is Animal Husbandry?','Livestock Management Systems','Approaches & Strategies for Animal Management'],
  currentLesson: 0,
  objectives: [
    'Explain what animal husbandry is and describe common husbandry practices for monogastric and polygastric animals',
    'Compare and contrast the three main livestock management systems',
    'Examine different approaches and strategies used by farmers to manage farmed animals'
  ],
  keyTerms: [
    {word:'Animal husbandry',def:'The management and care of animals in which the genetic qualities and behaviour of animals are developed for profit. Involves selective breeding and day-to-day care.'},
    {word:'Castration',def:'The removal of the testes from a male animal to prevent breeding and improve meat quality or animal behaviour.'},
    {word:'Weaning',def:'The process of separating young animals from their mothers and transitioning them to solid food.'},
    {word:'Mixed livestock production',def:'A management system that combines both agriculture and livestock, either intensively or extensively.'},
    {word:'Intensive farming',def:'A management system where animals are kept in confined conditions with high stocking density and high-level inputs.'},
    {word:'Extensive production system',def:'A management system where animals are kept free-range for part or all of their production cycle, relying more on natural resources.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>What is Animal Husbandry?</h2>
    <p>Animal husbandry refers to livestock raising and selective breeding. It is the management and care of animals in which the genetic qualities and behaviour of animals are further developed for profit. A large number of farmers depend upon animal husbandry for their livelihood.</p>
    <p>Common husbandry practices applied to both monogastric and polygastric animals include:</p>
    <ul>
      <li><strong>Castration</strong> — removal of testes from male animals to control breeding and improve meat quality</li>
      <li><strong>Dehorning</strong> — removal of horns from cattle and goats to prevent injury to animals and handlers</li>
      <li><strong>Vaccination</strong> — administration of vaccines to protect animals from disease</li>
      <li><strong>Weaning</strong> — separating young animals from their mothers at the appropriate time and transitioning them to solid feed</li>
      <li><strong>Balanced diet</strong> — providing appropriate feed with the correct nutritional balance</li>
      <li><strong>Watering</strong> — ensuring a constant supply of clean, fresh water</li>
      <li><strong>Disease control and prevention</strong> — monitoring animals for signs of illness and applying treatments promptly</li>
      <li><strong>Housing</strong> — providing shelter appropriate to the climate, providing adequate space, ventilation, and protection from predators</li>
      <li><strong>Avoiding overcrowding</strong> — overcrowding leads to disease spread, reduced growth, and injury</li>
    </ul>
    <h3>Benefits of Animal Husbandry</h3>
    <ul>
      <li>Proper management of animals ensures good food, shelter, and protection against disease</li>
      <li>Provides employment to large numbers of farmers, increasing living standards</li>
      <li>Helps develop high-yielding breeds through crossbreeding, increasing production of milk, eggs, and meat</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Three Main Livestock Management Systems</h2>
    <p>According to the FAO, there are three main livestock management systems:</p>
    <h3>1. Mixed Livestock Production</h3>
    <p>Mixed livestock production includes both agriculture and livestock and can be either intensive or extensive. These systems exploit both irrigated and non-irrigated land and are common in parts of America, Europe, and Asia. In PNG, most smallholder farmers use a mixed system — growing garden crops alongside raising pigs, chickens, or cattle.</p>
    <h3>2. Intensive Farming Systems ("Landless")</h3>
    <p>Intensive farming applies mainly to livestock. Intensive breeding farms look more like factories — large numbers of pigs, chickens, laying hens, or cattle are kept in confined spaces with high-level inputs. These are common in heavily populated areas where demand for meat and protein is very high. Intensive systems produce the most output per animal but require the most investment.</p>
    <h3>3. Extensive Production Systems</h3>
    <p>Extensive livestock production systems are systems in which animals are kept free-range for part or all of their production cycle. Animals depend more on natural pasture and require less purchased feed. These systems are lower cost but produce less output per animal. Traditional pig production in PNG, where pigs are kept free-range and find most of their own food, is an example of an extensive system.</p>
  </div>
  <div class="lesson-section">
    <h2>Approaches and Strategies for Animal Management</h2>
    <p>The management approach of livestock depends on the type of resources available and the farmer\'s choice. Effective management demands that all aspects of the life cycle receive appropriate husbandry attention. Key principles include:</p>
    <ul>
      <li>Always buy and select animals from a reliable source — preferably from a farm known to have minimal disease problems</li>
      <li>Pay special attention to factors that minimise stress, including good housing, handling, and feeding</li>
      <li>Aim for disease prevention rather than treatment after the fact</li>
      <li>Adopt a simple recording system to track animal performance, feed use, and health treatments</li>
    </ul>
    <p>For pig management specifically, key areas include: feeding, housing, care and control of diseases, and reproduction cycle and breeding stock management.</p>
    <p>Housing for birds in PNG must consider the climatic zone — coastal and lowland areas (below 1,000 m) require housing with maximum ventilation, while highland areas (above 1,000 m) require housing designed to conserve warmth, especially at night when temperatures fall below 18°C.</p>
  </div>`,
  summary: [
    'Animal husbandry is the management and care of animals for profit through selective breeding and day-to-day care',
    'Common husbandry practices include castration, dehorning, vaccination, weaning, feeding, watering, and housing',
    'The three main livestock management systems are: mixed production, intensive (landless), and extensive',
    'Extensive systems use free-range animals with low inputs; intensive systems use confinement with high inputs',
    'Effective management requires buying from reliable sources, minimising stress, and keeping simple records',
    'Housing in PNG must suit the climate — coastal areas need maximum ventilation; highlands need warmth retention',
  ],
  quiz: [
    {q:'What is the purpose of castration in animal husbandry?', opts:['To improve feed conversion','To remove horns and prevent injury','To prevent male animals from breeding and improve meat quality','To vaccinate animals against disease'], ans:2},
    {q:'Which livestock management system keeps animals free-range for part or all of their production cycle?', opts:['Intensive farming','Mixed livestock production','Extensive production system','Landless system'], ans:2},
    {q:'What is the main advantage of intensive livestock farming?', opts:['Lower cost of production','Animals are free to roam and find natural food','Highest output per animal with controlled conditions','Requires no purchased feed'], ans:2},
    {q:'What housing principle applies to poultry in the PNG highlands?', opts:['Maximum ventilation with large open windows','Housing designed to retain warmth especially at night','No housing needed as birds are free-range','Housing made from corrugated iron only'], ans:1},
    {q:'Why is keeping simple farm records important in animal husbandry?', opts:['It is required by law in PNG','It helps track animal performance, feed use, and health for better decision-making','It replaces the need for a veterinarian','It increases the market price of animals'], ans:1},
  ],
  furtherReading: [
    {url:'https://www.fao.org/livestock-systems/en/',label:'FAO Livestock Systems',desc:'Livestock management systems, animal husbandry practices, and smallholder farming resources.'},
  ]
},

'g10-animal-nutrition': {
  title: 'Animal Nutrition, Feeding & Health',
  strand: 'Strand 2: Animals · Unit 2', grade: 10, icon: '🌾',
  lessons: ['Principles of Animal Nutrition','Poultry Feeding & Water','Animal Diseases & Prevention'],
  currentLesson: 0,
  objectives: [
    'Identify the five key nutrients required in good quality animal feed',
    'Explain the importance of water and good quality feed in poultry production',
    'Describe the causes of poultry diseases and distinguish between infectious and non-infectious agents'
  ],
  keyTerms: [
    {word:'Protein',def:'One of the most important nutrients in poultry feed. Sources include soybeans, fish meal, oil seed cakes, insects, and legume leaves.'},
    {word:'Carbohydrates',def:'The largest source of energy for chickens. Sources include rice, root crops, starchy fruits, and seeds.'},
    {word:'Minerals',def:'Nutrients important for proper bone growth and egg production. Sources include eggshells, oyster shells, bone meal, and limestone.'},
    {word:'Vitamins',def:'Nutrients important for body functions. Found in fresh plant leaves, seeds, and fruits.'},
    {word:'Infectious agent',def:'A pathogen (bacteria, virus, parasite, or fungus) that causes disease by invading and harming the animal host.'},
    {word:'Newcastle disease',def:'A serious viral disease of poultry. Cannot be treated — vaccination is the only way to protect birds.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>The Five Key Nutrients in Animal Feed</h2>
    <p>Good quality animal feed contains five essential nutrients:</p>
    <ul>
      <li><strong>Protein</strong> — one of the most important parts of poultry feed. Protein is found in beans (soybeans, cowpeas, mung beans), fish meal, oil seed cakes (sesame cake, soya cake, cottonseed cake), insects, and leaves of legumes such as Leucaena, cassava leaves, and bean leaves.</li>
      <li><strong>Carbohydrates (starches)</strong> — the largest source of energy for chickens. Sources include rice, root crops, starchy fruits, and seeds.</li>
      <li><strong>Fats and oils</strong> — most grains have some fats and oils. Other sources include oil seed meals. Fats provide concentrated energy.</li>
      <li><strong>Minerals</strong> — important for proper bone growth and egg production. Sources include shells (eggshells, oyster shells, snail shells), bone meal (made by heating then crushing bones), and limestone products (lime is a good source of calcium).</li>
      <li><strong>Vitamins</strong> — important for body functions. Found in fresh plant leaves, seeds, and fruits.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Water and Feed in Poultry Production</h2>
    <h3>Water</h3>
    <p>Water is the most important part of poultry nutrition. Birds need a constant supply of fresh clean water — birds cannot lay eggs if they lack water. Only use water that you would drink yourself. Dirty water can make birds sick. Clean waterers regularly, especially in warmer climates where micro-organisms multiply more quickly.</p>
    <h3>Good Quality Feed</h3>
    <p>Good quality feed produces three key outcomes for poultry:</p>
    <ul>
      <li>Better health</li>
      <li>More eggs</li>
      <li>Birds grow faster</li>
    </ul>
    <p>Production can be classified by the type of product:</p>
    <ul>
      <li><strong>Meat breeds</strong> — great at producing meat but not efficient at egg production</li>
      <li><strong>Egg breeds</strong> — good egg production but poor meat production. Hens do not need males present to lay eggs.</li>
      <li><strong>Dual purpose breeds</strong> — produce both meat and eggs but at lower rates than specialist breeds</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Animal Diseases and Prevention</h2>
    <p>Poultry diseases can be caused by any condition that results in deviation from normal function. Diseases occur due to the interaction between three main factors: the <strong>agent</strong> (cause), the <strong>host</strong> (animal), and the <strong>environment</strong>.</p>
    <h3>Infectious Agents</h3>
    <ul>
      <li><strong>Bacteria</strong> — cause many diseases but can usually be treated with antibiotics</li>
      <li><strong>Viruses</strong> — cause diseases that cannot be treated. Prevention through vaccination is the only way to protect birds. Examples: Newcastle disease, fowl pox, Gumboro disease</li>
      <li><strong>Parasites</strong> — most can be treated with conventional medicine (anthelmintics) or traditional remedies</li>
      <li><strong>Fungi</strong> — no reliable treatment; antibiotics may help in some cases</li>
    </ul>
    <h3>Non-Infectious Agents</h3>
    <ul>
      <li><strong>Chemical</strong> — birds can come into contact with poisons when farms are not kept clean; poisons used to kill rodents; farm chemicals stored in chicken houses</li>
      <li><strong>Physical</strong> — injury to the bird from rough handling or equipment</li>
      <li><strong>Dietary deficiency</strong> — improper feed formulation or mixing leads to nutritional diseases</li>
    </ul>
    <h3>Host Factors</h3>
    <p>The following host factors affect an animal\'s vulnerability to disease: breed, age, sex, and immune status. The weaker the host, the more vulnerable it is to agents that cause stress and disease. Note that not all poultry health and production problems are caused by infectious agents — many can be traced to management factors.</p>
  </div>`,
  summary: [
    'The five key nutrients in animal feed are: protein, carbohydrates, fats and oils, minerals, and vitamins',
    'Water is the most important part of poultry nutrition — birds cannot lay eggs without a constant clean supply',
    'Poultry can be classified as meat breeds, egg breeds, or dual purpose breeds',
    'Diseases result from interaction between agent (pathogen), host (animal), and environment',
    'Viral diseases like Newcastle disease cannot be treated — vaccination is the only protection',
    'Non-infectious causes include chemical poisoning, physical injury, and dietary deficiency',
  ],
  quiz: [
    {q:'Which nutrient is the largest source of energy for chickens?', opts:['Protein','Carbohydrates','Minerals','Vitamins'], ans:1},
    {q:'What is the most important part of poultry nutrition?', opts:['Protein-rich feed','Mineral supplements','Fresh clean water','Vitamin injections'], ans:2},
    {q:'Why is vaccination the most important protection against Newcastle disease?', opts:['Newcastle disease can be cured with antibiotics','Newcastle disease is caused by a fungus','Newcastle disease is a viral disease that cannot be treated once contracted','Newcastle disease only affects older birds'], ans:2},
    {q:'Which of the following is a good source of minerals for poultry?', opts:['Rice bran and maize','Fresh plant leaves and fruits','Oyster shells, bone meal, and limestone','Fish meal and soybeans'], ans:2},
    {q:'What are the three factors that interact to cause animal disease?', opts:['Feed, water, and shelter','Agent, host, and environment','Breed, age, and immune status','Bacteria, viruses, and parasites'], ans:1},
  ],
  furtherReading: [
    {url:'https://www.fao.org/poultry-production-products/en/',label:'FAO Poultry',desc:'Poultry nutrition, disease management, and poultry production resources from the FAO.'},
  ]
},

'g10-animal-postharvest': {
  title: 'Post-Harvest Processing of Animal Products',
  strand: 'Strand 2: Animals · Unit 3', grade: 10, icon: '🥩',
  lessons: ['Food Processing Methods','Food Preservation Techniques','Benefits & Drawbacks of Processing'],
  currentLesson: 0,
  objectives: [
    'Explain the objectives and methods of food processing for animal products',
    'Describe food preservation techniques used to extend the shelf life of animal products',
    'Evaluate the benefits and drawbacks of food processing for animal product quality'
  ],
  keyTerms: [
    {word:'Food processing',def:'The process of transforming raw food items into a form that can be used or marketed — through physical and chemical processes such as mincing, cooking, canning, and packaging.'},
    {word:'Pasteurisation',def:'A heat treatment process used to kill harmful microorganisms in food products, especially milk. Named after Louis Pasteur.'},
    {word:'Drying',def:'A preservation method that removes moisture from food using sunlight or hot air, preventing microorganisms from growing.'},
    {word:'Cooling and refrigeration',def:'A preservation method that slows down microbial growth and enzyme activity to extend the shelf life of meat, dairy, and fish.'},
    {word:'Pickling',def:'A preservation method using an edible antimicrobial liquid (brine or acid). Can be fermentation-based or chemical.'},
    {word:'Shelf life',def:'The length of time a food product remains safe and suitable for consumption under recommended storage conditions.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>What is Food Processing?</h2>
    <p>Food processing is the process of transforming food items into a form that can be used. It covers the processing of raw materials into food via different physical and chemical processes. Various activities include mincing, cooking, canning, liquefaction, pickling, macerating, and emulsification.</p>
    <p>Processing takes clean harvested crops, or butchered and slaughtered animal products, and produces attractive, marketable, and in several cases, long-lasting food products. However, food processing can also lower the nutritional value of food and might include additives that affect health.</p>
    <h3>Objectives of Food Processing</h3>
    <ul>
      <li>Boosts the shelf life of food products</li>
      <li>Prevents food contamination</li>
      <li>Enables food storage and transportation</li>
      <li>Turns raw food materials into attractive, marketable products</li>
      <li>Provides employment to a large population</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Food Processing Methods for Animal Products</h2>
    <p>The following methods are applied for the proper processing of food:</p>
    <ul>
      <li>Peeling off outer layers of raw materials</li>
      <li>Chopping or slicing</li>
      <li>Mincing</li>
      <li>Fermentation</li>
      <li>Emulsification</li>
      <li>Cooking</li>
      <li>Mixing</li>
      <li>Pasteurisation (boiling milk to kill harmful microorganisms)</li>
      <li>Packaging</li>
      <li>Spray drying</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Food Preservation Techniques</h2>
    <p>Food preservation prevents the growth of fungi, bacteria, and microorganisms, and slows down oxidation of fats that would cause rancidity.</p>
    <ul>
      <li><strong>Drying</strong> — exposure to sunlight or hot air to evaporate moisture from food, preventing microorganisms from growing. One of the oldest and most traditional techniques used throughout Papua New Guinea.</li>
      <li><strong>Cooling and refrigeration</strong> — slows down the growth of microorganisms and enzyme activity responsible for rotting. Meat, dairy products, and fish are stored in a refrigerator, increasing their shelf life.</li>
      <li><strong>Freezing</strong> — one of the most common processes used domestically and commercially to preserve a wide range of foods.</li>
      <li><strong>Heating</strong> — most microorganisms and spores can be destroyed by applying sufficient heat. Example: boiling of milk (pasteurisation).</li>
      <li><strong>Pickling</strong> — preserving food in an edible antimicrobial liquid. Two types: fermentation pickling (bacteria in liquid produce organic preservation agents) and chemical pickling (food preserved in a liquid that destroys microorganisms).</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Benefits and Drawbacks of Food Processing</h2>
    <h3>Benefits</h3>
    <ul>
      <li>Reduces the number of harmful bacteria in food that can cause diseases (drying and pickling dehydrate food and alter pH, preventing harmful microorganism growth)</li>
      <li>Improves the shelf life of food products</li>
      <li>Reduces health inequalities and major health concerns by making safe food more accessible</li>
    </ul>
    <h3>Drawbacks</h3>
    <ul>
      <li>Processed food may contain artificial ingredients</li>
      <li>Processing foods to make them pleasant to eat can lead to overconsumption</li>
      <li>Processed foods are a major source of added sugar, which is associated with health risks</li>
      <li>Some processing reduces the nutritional value of food</li>
    </ul>
  </div>`,
  summary: [
    'Food processing transforms raw animal products into marketable food through physical and chemical processes',
    'Objectives of food processing: extend shelf life, prevent contamination, enable transport, create marketable products',
    'Drying is one of the oldest preservation techniques — it removes moisture to prevent microbial growth',
    'Refrigeration slows microorganism growth; freezing stops it — both extend the shelf life of meat, fish, and dairy',
    'Pickling preserves food in an antimicrobial liquid — either through fermentation or chemical means',
    'Benefits of processing include extended shelf life and food safety; drawbacks include reduced nutritional value',
  ],
  quiz: [
    {q:'What is the main purpose of food processing?', opts:['To make food taste better only','To transform raw materials into safe, marketable food products with extended shelf life','To remove all nutrients from food for easier storage','To replace traditional farming methods'], ans:1},
    {q:'Which preservation method removes moisture from food to prevent microbial growth?', opts:['Freezing','Pickling','Drying','Pasteurisation'], ans:2},
    {q:'What is pasteurisation?', opts:['Packing food in salt to preserve it','Applying heat to kill harmful microorganisms, especially in milk','Removing all moisture from food by exposure to sunlight','Smoking food to create a protective layer'], ans:1},
    {q:'Which of the following is a drawback of food processing?', opts:['It makes food safer to eat','It extends shelf life','Processed foods may contain added sugar and artificial ingredients','It allows food to be transported to markets'], ans:2},
    {q:'What type of pickling uses bacteria in a liquid to produce organic preservation agents?', opts:['Chemical pickling','Heat pickling','Fermentation pickling','Vacuum pickling'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/animal-production/en/',label:'FAO Animal Products',desc:'Post-harvest processing, preservation, and food safety for animal products from the FAO.'},
  ]
},

'g10-poultry-management': {
  title: 'Poultry Breeds, Management & Technology',
  strand: 'Strand 2: Animals · Unit 4-6', grade: 10, icon: '🐔',
  lessons: ['Breeds of Farmed Birds','Poultry Production Systems','Technology in Poultry Farming'],
  currentLesson: 0,
  objectives: [
    'Identify and categorize breeds of domesticated and farmed birds according to their characteristics, functions, and purposes',
    'Compare and contrast the four poultry production systems used in different environments',
    'Evaluate the impact of technology used in poultry farming on environments and people'
  ],
  keyTerms: [
    {word:'Class (poultry)',def:'A group of poultry breeds developed in a particular geographical area — e.g. American, Asiatic, Mediterranean, English classes.'},
    {word:'Breed (poultry)',def:'A group of birds that each possess a given set of physical features (body shape, skin colour, feathering) that are passed on to offspring.'},
    {word:'Variety',def:'A subdivision of a breed, differentiated by characteristics such as plumage colour, comb type, or presence of beard and muffs.'},
    {word:'Broiler',def:'A chicken bred specifically for meat production, growing rapidly to market weight.'},
    {word:'Layer',def:'A chicken bred specifically for egg production.'},
    {word:'Incubator',def:'A machine that maintains the temperature and humidity required to hatch fertilised eggs, replacing the need for a broody hen.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Breeds of Farmed Birds</h2>
    <p>Birds or chickens can be identified or classified through designated class, breed, variety, and strain.</p>
    <ul>
      <li><strong>Class</strong> — designates a group of breeds developed in a particular geographical area. Examples: American, Asiatic, Mediterranean, English.</li>
      <li><strong>Breed</strong> — a group of birds each possessing a given set of physical features (body shape, skin colour, feathered or non-feathered shanks) that are passed on to offspring.</li>
      <li><strong>Variety</strong> — a subdivision of a breed. Differentiated by plumage colour, comb type, and presence of beard and muffs.</li>
      <li><strong>Strain or line</strong> — families or breeding populations with common traits. Developed for egg production, meat production, or egg colour.</li>
    </ul>
    <p>Examples of farmed bird breeds and their purposes:</p>
    <ul>
      <li><strong>Jersey Giant</strong> (American class) — very heavy meat type. Largest breed in the American class. Also a fairly good layer.</li>
      <li><strong>New Hampshire Red</strong> (American class) — dual purpose, selected more for meat than eggs. Fast growing, relatively calm.</li>
      <li><strong>Langshan</strong> (Asiatic class) — general purpose for meat and eggs. Originated in China. Active and quick.</li>
      <li><strong>Australorp</strong> (English class) — generally a very good egg producer with a fairly meaty body. Popular backyard flock bird.</li>
      <li><strong>Leghorn</strong> (Mediterranean class) — egg-type chicken. Small, spritely bird noted for egg production. Good forager.</li>
      <li><strong>Norfolk Black</strong> — good for both meat and eggs. Medium sized; stags 7–8 kg, hens 4–5 kg.</li>
    </ul>
    <p>In PNG, both Zenag and Table Birds are major poultry farming companies producing broilers and eggs for local markets.</p>
  </div>
  <div class="lesson-section">
    <h2>Poultry Production Systems</h2>
    <p>Four poultry production systems can be distinguished, particularly in developing countries:</p>
    <ul>
      <li><strong>1. Free-range (unimproved backyard) system</strong> — scavenging birds with no regular water or feed, little or poor night shelter. Very low inputs. Common in rural PNG villages.</li>
      <li><strong>2. Improved backyard system</strong> — regular water, supplementary feeding, improved shelter, care of chicks in the first weeks, vaccination against Newcastle disease and other diseases (fowl pox, Gumboro disease, coccidiosis) when necessary.</li>
      <li><strong>3. Semi-intensive system</strong> — as per the improved backyard system, but with genetically improved breeds and balanced diets. Higher production levels.</li>
      <li><strong>4. Small-scale intensive system</strong> — further improvements in overall husbandry conditions. Confined housing, controlled feeding, disease prevention programme, and detailed record keeping.</li>
    </ul>
    <p>The choice of system is largely determined by the availability of resources and inputs (housing, cages, feed, drugs, time, and attention) and the socio-economic circumstances of the farmer.</p>
  </div>
  <div class="lesson-section">
    <h2>Technology in Poultry Farming</h2>
    <p>Farm technology includes all methods, equipment, and machinery used to improve farming enterprises. Examples of technologies and innovations used in poultry farming in PNG:</p>
    <ul>
      <li><strong>Hatcheries and incubators</strong> — PNG\'s two large poultry companies (Zenag and Table Birds) use incubators and hatcheries to produce day-old chicks at scale.</li>
      <li><strong>Battery cages</strong> — used for layers to make it efficient to collect eggs and manage large numbers of birds in confined spaces.</li>
      <li><strong>Automated feeders and waterers</strong> — self-refilling when low on feed or water, reducing labour requirements.</li>
      <li><strong>Lighting systems (brooders)</strong> — automatic switches that control light and warmth depending on temperature and humidity.</li>
      <li><strong>Thermal sensitive lights</strong> — lights that activate when an intruder approaches, serving as a security measure.</li>
      <li><strong>Locally produced feeds</strong> — feeds produced using locally grown crops like sweet potato (kaukau) and tapioca to reduce costs.</li>
    </ul>
    <h3>Processing Line Technology (Zenag and Table Birds)</h3>
    <p>The full processing chain uses: transport, electrical weighing machines, mechanical slaughter blades, hot baths for feather loosening, plucking machines, cutting and gutting equipment, chillers for storage, packaging machines, and refrigerated trucks for distribution.</p>
    <h3>Impact of Technology</h3>
    <p>Technology in poultry farming has positive and negative impacts. Natural environment impacts include air pollution from generator emissions and water pollution from chemical waste disposal. Socio-economic impacts include reduced need for labour (when automation replaces manual work), which can cause unemployment and social problems in communities that depended on farm work for income.</p>
  </div>`,
  summary: [
    'Poultry breeds are classified by class (geographic origin), breed (physical traits), variety (plumage/comb), and strain (production purpose)',
    'Four production systems: free-range, improved backyard, semi-intensive, and small-scale intensive — in order of increasing inputs',
    'The choice of system depends on available resources, inputs, and the farmer\'s socio-economic situation',
    'PNG poultry technology includes incubators, battery cages, automated feeders, brooders, and locally produced feeds',
    'Zenag and Table Birds use full mechanised processing lines from transport through to packaged retail products',
    'Technology impacts: positive (efficiency, lower cost) and negative (pollution, reduced labour, unemployment)',
  ],
  quiz: [
    {q:'What does "class" mean when classifying poultry breeds?', opts:['The production purpose of the bird (meat or eggs)','A group of breeds developed in a particular geographical area','The quality grade of the bird\'s eggs','The generation of the breeding line'], ans:1},
    {q:'Which poultry production system uses scavenging birds with no regular water or feed?', opts:['Small-scale intensive system','Semi-intensive system','Improved backyard system','Free-range (unimproved backyard) system'], ans:3},
    {q:'What are incubators used for in PNG\'s large poultry companies?', opts:['Storing packaged eggs for retail','Cooling slaughtered birds after processing','Producing day-old chicks at scale without broody hens','Heating poultry houses in cold highlands'], ans:2},
    {q:'What is one negative socio-economic impact of technology in poultry farming?', opts:['Higher cost of production','Technology reduces manual labour, potentially causing unemployment','Technology makes poultry farming less efficient','Technology increases the spread of disease'], ans:1},
    {q:'Which poultry breed is classified in the Mediterranean class and is noted for egg production?', opts:['Jersey Giant','Australorp','Leghorn','Langshan'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/poultry-production-products/production/en/',label:'FAO Poultry Production',desc:'Poultry breeds, production systems, and technology from the FAO.'},
  ]
},

'g10-aqua-environments': {
  title: 'Freshwater, Brackish & Saltwater Farming',
  strand: 'Strand 3: Aquaculture · Unit 1', grade: 10, icon: '🐠',
  lessons: ['Common Characteristics of Fish','Farming Environments','Benefits of Aquaculture'],
  currentLesson: 0,
  objectives: [
    'Identify common characteristics shared by all fish regardless of species',
    'Distinguish between freshwater, brackish, and saltwater farming environments and the animals farmed in each',
    'Describe the economic, environmental, and health benefits of aquaculture'
  ],
  keyTerms: [
    {word:'Cold-blooded (ectothermic)',def:'Unable to regulate body temperature internally. Fish rely on the surrounding water temperature for temperature regulation.'},
    {word:'Gills',def:'The respiratory organs of fish that allow them to absorb oxygen from water and release carbon dioxide.'},
    {word:'Swim bladder',def:'A specialized air-filled organ in fish that helps maintain stable buoyancy, preventing the fish from sinking or floating uncontrollably.'},
    {word:'Lateral line',def:'A sensory organ along the side of a fish containing small sensory hairs that detect underwater vibrations and help navigate in low-light or murky water.'},
    {word:'Monoculture',def:'A fish production system in which only one species is reared in the culture system.'},
    {word:'Polyculture',def:'A fish production system in which two or more different species are farmed together with different feeding habits and water column preferences.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Common Characteristics of Fish</h2>
    <p>Despite the thousands of different species with various adaptations, all fish share some common characteristics:</p>
    <ul>
      <li><strong>All fish are cold-blooded</strong> — they cannot regulate their body temperature internally. They rely on the outside environment for temperature regulation. Many species are extremely sensitive to temperature changes and can only exist within a specific temperature range.</li>
      <li><strong>Water habitats</strong> — all fish live in water (salt, fresh, or brackish water).</li>
      <li><strong>Gills to breathe</strong> — gills are a necessity for underwater life. They allow the fish to absorb oxygen from water and release carbon dioxide.</li>
      <li><strong>Swim bladders</strong> — all fish have a swim bladder, a specialised air-filled organ that maintains stable buoyancy in the water. It allows fish to sleep without sinking to the bottom.</li>
      <li><strong>Fins for movement</strong> — fins are almost universal in fish. Common types include the tail fin, side fins, dorsal fins, and anal fin.</li>
      <li><strong>Vision and sensory organs</strong> — many fish have excellent vision and can see colours. They also have nostrils to detect odours in water. The lateral line contains small sensory hairs that detect underwater vibrations, allowing navigation even in low light or murky water.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Freshwater, Brackish, and Saltwater Farming</h2>
    <p>A number of aquaculture practices are used worldwide in three types of environment:</p>
    <h3>Freshwater Farming</h3>
    <p>Farming of aquatic animals and plants in zero-salinity water. Mostly inland based. Common species: catla, rohu, tilapia, freshwater prawn, catfish, and rainbow trout. In PNG, freshwater aquaculture using ponds and small lakes is accessible to rural farming communities.</p>
    <h3>Brackish Water Farming</h3>
    <p>Farming in water with partial salinity, found near estuaries and river mouths where freshwater and saltwater mix. Milkfish, mullet, and prawns are commonly farmed in brackish water environments. Brackish water aquaculture is suited to coastal areas of PNG.</p>
    <h3>Saltwater Farming (Mariculture)</h3>
    <p>Farming in seawater, either in caged areas of the ocean, coastal ponds containing seawater, or net pens. Species include molluscs, prawns, shellfish, seaweed, and large fish species. Seaweed is used in cosmetics (collagen for facial creams) and food products.</p>
    <h3>Monoculture and Polyculture</h3>
    <p>In monoculture, only one fish species is reared (e.g. tilapia or catfish). In polyculture, two or more species are farmed together — species are chosen with different feeding habits and water column preferences to avoid competition, which gives higher yields than monoculture.</p>
  </div>
  <div class="lesson-section">
    <h2>Benefits of Aquaculture</h2>
    <h3>Economic Benefits</h3>
    <ul>
      <li><strong>Alternative food source</strong> — fish and seafood are high in protein, omega-3 fatty acids, and white meat that is healthier for the blood than red meat. Fish are also cheaper to rear as they convert feed into protein more efficiently than beef cattle.</li>
      <li><strong>Alternative fuel source</strong> — algae are being developed as alternative fuel sources. Algae produce lipids that can burn as clean fuel, potentially reducing dependence on fossil fuels.</li>
      <li><strong>Increased jobs</strong> — aquaculture provides labour for maintaining pools and harvesting organisms, especially in developing countries. It also frees fishermen to pursue other economic activities.</li>
    </ul>
    <h3>Environmental Benefits</h3>
    <ul>
      <li><strong>Barrier against pollution</strong> — molluscs (filter feeders) and seaweed clean water as it flows through them, protecting the sea from land-based pollution.</li>
      <li><strong>Reduces pressure on wild fish stocks</strong> — aquaculture provides an alternative source of seafood, allowing wild fish populations to recover from overfishing.</li>
    </ul>
    <h3>Health Benefits</h3>
    <p>Seafood consumption is associated with reduced risk of cardiovascular disease, cancer, and Alzheimer's disease. Aquaculture can make seafood cheaper and more accessible, particularly in regions that depend on imported seafood products.</p>
  </div>`,
  summary: [
    'All fish are cold-blooded, live in water, breathe through gills, have swim bladders for buoyancy, and use fins for movement',
    'The lateral line is a sensory organ that detects underwater vibrations for navigation in low-light conditions',
    'Three aquaculture environments: freshwater (inland), brackish water (estuaries and coast), and saltwater (mariculture)',
    'Polyculture farms multiple species together with different feeding habits, producing higher yields than monoculture',
    'Economic benefits: alternative protein source, job creation, and potential for algae-based fuel',
    'Environmental benefits: molluscs and seaweed clean water; aquaculture reduces overfishing pressure on wild stocks',
  ],
  quiz: [
    {q:'What does it mean that fish are cold-blooded?', opts:['Fish prefer cold water environments only','Fish cannot regulate their body temperature internally and rely on the surrounding water temperature','Fish produce their own body heat through metabolism','Fish can survive in both hot and cold environments without any change'], ans:1},
    {q:'What is the function of the swim bladder in fish?', opts:['To filter oxygen from water','To detect vibrations in the water','To maintain stable buoyancy so fish do not sink or float uncontrollably','To store nutrients absorbed from food'], ans:2},
    {q:'Which aquaculture environment is associated with estuaries where freshwater and saltwater mix?', opts:['Freshwater farming','Mariculture','Brackish water farming','Recirculating system farming'], ans:2},
    {q:'What is one environmental benefit of molluscs and seaweed in aquaculture?', opts:['They produce alternative fuel','They filter and clean water as it flows through them','They attract more wild fish to the area','They reduce the need for freshwater in fish farming'], ans:1},
    {q:'Why is fish generally cheaper to rear than beef cattle for protein production?', opts:['Fish do not need any feed','Fish convert feed into protein more efficiently than beef cattle','Fish farms require no labour or infrastructure','Fish can be caught wild without farming'], ans:1},
  ],
  furtherReading: [
    {url:'https://www.fao.org/fishery/en/aquaculture',label:'FAO Aquaculture',desc:'Aquaculture environments, fish species, and sustainable fish farming resources from the FAO.'},
  ]
},

'g10-aqua-management': {
  title: 'Aqua Farming Management Systems',
  strand: 'Strand 3: Aquaculture · Unit 2', grade: 10, icon: '🦈',
  lessons: ['Fish Farming Methods','Fish Management Practices','Preserving Aquatic Species & Environments'],
  currentLesson: 0,
  objectives: [
    'Explain the common methods used to produce fish in different aquaculture systems',
    'Identify good fish management practices including pond preparation, stocking, and harvesting',
    'Discuss different ways of preserving plant, animal, and fish species and sustaining aquatic environments'
  ],
  keyTerms: [
    {word:'Pond system',def:'The oldest type of fish farming, using earthen ponds or ditch systems with clay-based soils that can easily be diked to make enclosures.'},
    {word:'Open net pens',def:'A framework made from metal, wood, or bamboo floating on a water body, supporting a mesh enclosure for fish culture.'},
    {word:'Submersible net pens',def:'Fully submerged, closed cages placed underwater, providing shelter from the elements and reducing the risk of fish escape.'},
    {word:'Recirculating systems',def:'High-tech enclosed tank systems that continuously filter and recycle water, allowing fish to be raised indoors with no contact with wild stocks.'},
    {word:'Pond preparation',def:'The process of draining, drying, treating, and liming pond bottoms before stocking fish, to eliminate predators and condition the soil.'},
    {word:'Overfishing',def:'Harvesting fish so often and in such great numbers that the population becomes severely depleted, potentially leading to extinction.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Fish Farming Methods</h2>
    <p>There are four common methods of fish farming:</p>
    <ul>
      <li><strong>Pond system</strong> — the oldest type of fish farming, originating thousands of years ago. Pond farms include earthen ponds, ditch, or canal systems with clay-based soils that can easily be diked to make enclosures. Water is maintained through rain, canals, or bores.</li>
      <li><strong>Open net pens</strong> — a framework made from metal, wood, or bamboo that floats on the surface of a water body and supports a mesh enclosure. Fish farmers favour net pens because of their flexibility, versatility, and scale. They allow water to flow freely through, which helps deal with waste. They are anchored to the bottom or attached to a secure structure.</li>
      <li><strong>Submersible net pens</strong> — an alternative to open net pens. Instead of floating on the surface, these are fully underwater, often taking the form of a large closed-off cage. Being beneath the surface shelters them from the elements and reduces the chance that captive fish will escape.</li>
      <li><strong>Recirculating systems</strong> — essentially high-tech pond systems. Fish stocks are reared in a series of interconnected, fully controlled indoor tanks with virtually no chance of contact with wild stocks. Water is continuously filtered and recycled.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Fish Management Practices</h2>
    <p>Regardless of the specific system used, fish farming management involves six basic activities:</p>
    <ol>
      <li><strong>Pond preparation/conditioning</strong> — ponds are totally drained and dried before pesticides are applied to eliminate predators and wild species. Agricultural lime is applied to correct soil pH to at least 6.5. Organic or inorganic fertiliser is then applied to stimulate natural plankton growth before water is let in.</li>
      <li><strong>Stocking</strong> — introducing fish to the pond at appropriate stocking densities. Density varies by species and system (e.g. milkfish 2,000–5,000/ha; tilapia 5,000–20,000/ha).</li>
      <li><strong>Feeding and/or fertilisation</strong> — extensive ponds rely on natural food from regular fertilisation; intensive ponds use formulated feed. Semi-intensive ponds use a mix of both.</li>
      <li><strong>Water management</strong> — maintaining water quality including oxygen levels, temperature, salinity, and pH throughout the production cycle.</li>
      <li><strong>Pond maintenance</strong> — regular monitoring, repair of bunds/dikes, control of unwanted vegetation, and management of predators.</li>
      <li><strong>Harvesting</strong> — collecting fish at the end of the production cycle using appropriate gear and techniques.</li>
    </ol>
  </div>
  <div class="lesson-section">
    <h2>Preserving Aquatic Species and Environments</h2>
    <p>Aquatic organisms face serious threats from overfishing, climate change, pollution, and oil spills.</p>
    <ul>
      <li><strong>Overfishing</strong> — harvesting a particular type of fish so frequently and in such great numbers that the population becomes severely depleted, risking endangerment and potential extinction. Overfishing affects the human food supply, the fishing industry, and the environment.</li>
      <li><strong>Climate change</strong> — marine organisms have disappeared from their habitats at twice the rate of wildlife on land due to global warming. Rising sea temperatures destroy coral reefs and disrupt marine ecosystems.</li>
      <li><strong>Pollution</strong> — aquatic life suffers when toxins and waste reduce dissolved oxygen levels in water bodies, harming fish and other aquatic organisms.</li>
    </ul>
    <h3>Methods of Preservation</h3>
    <ul>
      <li>Drying, salting, pickling, and smoking — ancient fish preservation methods still widely used today</li>
      <li>Freezing and canning — modern techniques that have taken on large importance for commercial fish preservation</li>
      <li>Fish curing — includes drying, salting, and smoking. Fish are first cleaned, scaled, and eviscerated before curing.</li>
    </ul>
  </div>`,
  summary: [
    'Four common fish farming methods: pond systems, open net pens, submersible net pens, and recirculating systems',
    'Six fish management activities: pond preparation, stocking, feeding/fertilisation, water management, maintenance, and harvesting',
    'Pond preparation involves draining, drying, applying pesticide, liming to pH 6.5, and fertilising before stocking',
    'Aquatic species face threats from overfishing, climate change, and pollution',
    'Ancient fish preservation methods include drying, salting, pickling, and smoking',
    'Modern preservation methods include freezing and canning, widely used for commercial fish products',
  ],
  quiz: [
    {q:'Which fish farming system keeps fish in fully enclosed, submerged underwater cages?', opts:['Open net pens','Pond system','Submersible net pens','Recirculating systems'], ans:2},
    {q:'What is the purpose of applying agricultural lime during pond preparation?', opts:['To kill all fish before restocking','To correct soil pH and bring it up to at least 6.5','To add nitrogen nutrients for fish growth','To colour the water so fish are easier to see'], ans:1},
    {q:'What is overfishing?', opts:['Farming too many fish species in one pond','Harvesting fish so often and in such numbers that the population becomes severely depleted','Using too much feed in an intensive fish farm','Releasing farmed fish into wild water bodies'], ans:1},
    {q:'Which modern fish preservation method has largely replaced older traditional methods?', opts:['Salting and smoking','Drying in sunlight','Freezing and canning','Pickling in brine'], ans:2},
    {q:'What is the main advantage of recirculating fish farming systems?', opts:['They require no electricity or technology','Fish are kept entirely indoors with no contact with wild stocks and water is continuously recycled','They use the largest ponds of any fish farming system','They are the cheapest system to build and operate'], ans:1},
  ],
  furtherReading: [
    {url:'https://www.fao.org/fishery/en/aquaculture',label:'FAO Aquaculture Management',desc:'Fish farming management systems, pond preparation, and sustainable aquaculture practices.'},
  ]
},

'g10-capture-fishery': {
  title: 'Capture Fishery: Harvesting & Management',
  strand: 'Strand 4: Natural Resources · Unit 1-2', grade: 10, icon: '🎣',
  lessons: ['Harvesting Methods & Gear','Capture Fishery Management Systems','Fishery Regulation & Monitoring'],
  currentLesson: 0,
  objectives: [
    'Explain the different methods and gears used to harvest capture fish in inland and marine waters',
    'Identify and describe capture fishery management systems used in different places and environments',
    'Discuss fishery regulation and monitoring practices used to ensure sustainable fisheries'
  ],
  keyTerms: [
    {word:'Capture fishery',def:'The harvesting of fish and other aquatic organisms from wild stocks in their natural habitats, as distinct from aquaculture.'},
    {word:'Static gear',def:'Fishing gear that is placed in one position and left to capture fish that approach it. Examples: gillnets, setlines, traps.'},
    {word:'Mobile gear',def:'Fishing gear that is actively moved or used to encircle fish. Examples: cast nets, trawls, seines.'},
    {word:'Total Allowable Catch (TAC)',def:'A fishery management tool that establishes the maximum fishing limit for each species controlled under a management plan for a specific time period.'},
    {word:'Maximum Sustainable Yield (MSY)',def:'The maximum amount of fish that can be harvested from a stock without reducing the long-term ability of that stock to regenerate.'},
    {word:'Monitoring, Control and Surveillance (MCS)',def:'An integral component of fisheries management involving the collection and analysis of fishing data, enforcement of regulations, and supervision of fishing activity.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Harvesting Methods and Gear</h2>
    <p>Many types of fishing gear exist to exploit inland and marine waters. The choice of gear depends on the characteristics of the water body, the target species, the season, the value of the fish, and the cost of the gear.</p>
    <h3>Three Main Categories of Fishing Gear</h3>
    <ul>
      <li><strong>Passive gear</strong> — gear in which the fish comes to the gear. Examples: gillnets, setlines, traps, brush parks, fish holes, lift nets.</li>
      <li><strong>Active gear</strong> — gear in which the gear engulfs the fish. Examples: trawls, seines, cast nets, dip netting, electric fishing.</li>
      <li><strong>Other methods</strong> — rod and line, poisons, explosives, fish parks and holes.</li>
    </ul>
    <h3>Harvesting in Inland Waters</h3>
    <p>In inland fisheries there is a much greater dependence on static gears such as gillnets or barrier traps, and small individually operated active gears such as cast nets. Gear choices are affected by: water depth, characteristics of the lake or river bed, target species and their habitat, season and flow regime, and the value of the fish.</p>
    <h3>Harvesting in Marine Waters</h3>
    <p>In marine fisheries, the most important commercially used methods are purse seining and trawling. These highly mechanised methods are rare in inland waters. Marine fishing vessels use GPS technology, acoustic fish detection, and satellite-based remote sensing to locate fish schools efficiently.</p>
  </div>
  <div class="lesson-section">
    <h2>Capture Fishery Management Systems</h2>
    <p>The goal of fisheries management is to produce sustainable biological, social, and economic benefits from renewable aquatic resources. Fishery management systems aim to achieve optimal and sustainable utilisation of fishery resources while safeguarding the ecosystem.</p>
    <p>Management is directed at maintaining a stock size that gives the Maximum Sustainable Yield (MSY) through various regulations aimed at controlling fishing effort and mortality. When fisheries are assessed, the certification body checks that:</p>
    <ul>
      <li>An effective legal or customary framework is in place that recognises the rights of people who depend on fishing for food and livelihoods</li>
      <li>Management objectives are consistent with Fisheries Standards</li>
      <li>Effective consultation and decision-making processes are in place</li>
      <li>A system exists to effectively enforce management rules</li>
      <li>The performance of the management system is regularly evaluated</li>
    </ul>
    <h3>Fishery Management Tools</h3>
    <ul>
      <li><strong>Total Allowable Catch (TAC)</strong> — establishes maximum fishing limits for each species during a specific timeframe</li>
      <li><strong>Fishing effort limits</strong> — restrictions on number of trips, hooks used, kilometres of nets, or number of boats</li>
      <li><strong>Size limits</strong> — minimum and maximum legal sizes for fish caught. Lets fish reach maturity, complete breeding cycles, and contribute to sustainable stocks</li>
      <li><strong>Gear restrictions</strong> — control minimum net mesh size, allow only specific gear types in particular fisheries</li>
      <li><strong>Access controls</strong> — commercial fishing licences and permits that define harvest rights and place limits on authorised harvesters</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Fishery Regulation and Monitoring</h2>
    <p><strong>Fishery regulation</strong> is a set of rules and laws governing the exploitation and other practices of fishery resources, especially in open-access waters.</p>
    <p><strong>Monitoring practices</strong> involve the collection, measurement, and analysis of fishing activity.</p>
    <p>Capture Fishery Monitoring, Control and Surveillance (MCS) programs generally include:</p>
    <ul>
      <li><strong>Monitoring</strong> — collection and analysis of catches, species composition, fishing effort, discards, and area of operation</li>
      <li><strong>Control</strong> — specification of terms and conditions under which resources can be harvested</li>
      <li><strong>Surveillance</strong> — checking and supervising fishing activity to ensure national legislation and management measures are observed</li>
    </ul>
    <p>Modern monitoring tools include: video cameras on vessels, GPS tracking of fishing locations, satellite-based monitoring systems, human observers on fishing trips, vessel logbooks (required by law for all licensed commercial fishing operations), and satellite-based tracking devices (mandatory on all commercial fishing vessels in many countries).</p>
  </div>`,
  summary: [
    'Passive fishing gear (gillnets, traps, setlines) waits for fish to approach; active gear (trawls, cast nets, seines) is moved to encircle fish',
    'Inland fisheries rely heavily on static gear; marine fisheries use mechanised purse seining and trawling',
    'Fishery management aims to achieve Maximum Sustainable Yield while protecting the ecosystem',
    'Key management tools: Total Allowable Catch, effort limits, size limits, gear restrictions, and fishing licences',
    'MCS programs involve monitoring (data collection), control (rules), and surveillance (enforcement)',
    'Modern monitoring uses GPS tracking, video cameras, satellite systems, and mandatory vessel logbooks',
  ],
  quiz: [
    {q:'Which type of fishing gear waits in one position for fish to approach it?', opts:['Active gear','Mobile gear','Static (passive) gear','Towed gear'], ans:2},
    {q:'What is the goal of the Total Allowable Catch (TAC) management tool?', opts:['To establish the maximum fishing limit for each species during a specific period','To ban all commercial fishing in protected areas','To regulate the size of fishing vessels allowed in national waters','To set the minimum price for fish at market'], ans:0},
    {q:'Why are size limits important in fishery management?', opts:['To ensure only large fish are eaten','To let fish reach maturity, complete breeding cycles, and contribute to sustainable stocks','To reduce the cost of fishing operations','To prevent small boats from catching large fish'], ans:1},
    {q:'What does MCS stand for in fisheries management?', opts:['Marine Catch Standards','Maximum Catch Sustainability','Monitoring, Control and Surveillance','Marine Conservation System'], ans:2},
    {q:'Which fishing method is most commonly used in marine commercial fisheries?', opts:['Handlining from canoes','Cast nets from the shoreline','Purse seining and trawling','Brush traps and fish holes'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/fishery/en/',label:'FAO Fisheries',desc:'Capture fishery management, regulation, and sustainable harvesting resources from the FAO.'},
  ]
},

'g10-aqua-tech': {
  title: 'Technology in Aquaculture & Capture Fishery',
  strand: 'Strand 3 & 4: Aquaculture & NRM · Unit 3', grade: 10, icon: '📡',
  lessons: ['Fish Harvest Technology','Fish Processing Technology','Advantages & Disadvantages of Technology'],
  currentLesson: 0,
  objectives: [
    'Explain how technology is used in fish farming, harvesting, and preservation in different environments',
    'Describe the steps involved in processing fish products for commercial purposes',
    'Evaluate the advantages and disadvantages of using technology in capture fishery'
  ],
  keyTerms: [
    {word:'Fish harvest technology',def:'Equipment and practices used for finding, catching, handling, and distributing fish from capture fisheries or aquaculture.'},
    {word:'GPS (Global Positioning System)',def:'Satellite-based technology used for navigation and tracking of fishing vessel locations, improving safety and monitoring.'},
    {word:'Acoustic fish detection',def:'Technology that uses sound waves (sonar) to locate schools of fish underwater.'},
    {word:'Filleting',def:'The process of cutting the flesh of a fish into strips (fillets) parallel to the backbone, producing a boneless product.'},
    {word:'Responsible fishing technology',def:'Fishery technology that achieves specific management objectives with minimum damaging side effects on the ecosystem.'},
    {word:'LED fishing lights',def:'Energy-efficient lights attached to fishing nets that can attract target species while guiding non-target species away to safety.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Fish Harvest Technology</h2>
    <p>Fish harvest technology provides employment and economic benefits to large sections of societies. It encompasses various processes of catching aquatic organisms, from the simplest gathering of organisms to the most highly sophisticated systems used to capture large tuna and whales.</p>
    <p>The most significant technological developments supporting the evolution of fish harvest technology are:</p>
    <ul>
      <li><strong>Developments in craft technology</strong> — mechanisation of propulsion, gear, and catch handling</li>
      <li><strong>Introduction of synthetic gear materials</strong> — nylon and other synthetic fibres that are stronger, lighter, and more durable than natural materials</li>
      <li><strong>Developments in acoustic fish detection</strong> — sonar systems that locate fish schools underwater; satellite-based remote sensing</li>
      <li><strong>Electronic navigation and position fixing</strong> — GPS technology that has positively influenced the safety of fishermen, providing better communication, navigation, and emergency rescue systems (GMDSS)</li>
      <li><strong>Awareness of responsible fishing</strong> — technology developed to ensure sustainability, protect biodiversity, and improve energy efficiency</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Fish Processing Technology</h2>
    <p>When fish are captured or harvested for commercial purposes, they need preprocessing to be delivered to the next part of the marketing chain in a fresh and undamaged condition. There are four main preprocessing steps:</p>
    <ul>
      <li><strong>Handling the catch</strong> — transferring catch from fishing gear to the vessel; sorting and grading; bleeding, gutting, and washing; chilling; and storing until landing. The key rule: kill fish immediately after catching, cut off the head and gills, wash with clean running water, then put fish on ice in insulated boxes. Get fish to the landing area as fast as possible.</li>
      <li><strong>Removal of scales</strong> — wash the fish, cut off the head, then use a sharp knife to scrape scales toward the head. Turn the fish and scale the other side.</li>
      <li><strong>Cutting (gutting)</strong> — removing the guts (intestines). Gutting should be carried out regardless of the preservation method to be used. Wash thoroughly with clean running water after gutting.</li>
      <li><strong>Filleting</strong> — cutting the flesh into strips parallel to the backbone. Fillets may be with or without skin. Fillets are dipped in brine to enhance appearance, reduce drip, and add a salty flavour. They are then packaged and frozen at -35°C to -40°C and stored at -23°C.</li>
    </ul>
    <h3>Fish Preservation Technology</h3>
    <p>Fish preservation methods used in different environments include: control of temperature through refrigeration and freezing; control of water activity through drying, salting, and smoking; physical control of microbial loads through canning; and chemical control through biopreservation and fermentation.</p>
  </div>
  <div class="lesson-section">
    <h2>Advantages and Disadvantages of Technology in Capture Fishery</h2>
    <p>Each fishery technology has advantages and disadvantages that should be balanced in a protective approach. Responsible fishery technology achieves specific management objectives with the minimum damaging side effects.</p>
    <h3>Advantages</h3>
    <ul>
      <li>More efficient and economically viable fishing operations — e.g., LED lights attached to nets can attract the right catch and guide non-target species to safety</li>
      <li>Reduction of physical labour required by fishers</li>
      <li>Improved access to fishery resources</li>
      <li>Empowers small-scale fishers with market information, allowing better business decisions</li>
      <li>Improves fisheries management practices and seafood traceability, giving consumers better information</li>
    </ul>
    <h3>Disadvantages</h3>
    <ul>
      <li><strong>Overfishing</strong> — improved technology combined with increased demand and poor management can exhaust fish populations or cause stocks to collapse completely</li>
      <li><strong>Habitat damage</strong> — heavy or large fishing gear can harm the environment. Dredging and bottom trawling impact the sea-floor habitat; in areas with sensitive deep-sea corals, gear can cause long-term damage</li>
      <li><strong>Cost</strong> — technology used in capture fishery is costly, making it inaccessible to many small-scale fishers in developing countries</li>
    </ul>
  </div>`,
  summary: [
    'Key fish harvest technologies include acoustic fish detection, GPS navigation, synthetic gear materials, and mechanised propulsion',
    'GPS has improved the safety of fishermen through better navigation and emergency rescue systems',
    'Four main fish preprocessing steps: handling, scale removal, gutting, and filleting',
    'Fish preservation methods include temperature control (refrigeration, freezing), drying, salting, smoking, and canning',
    'Technology advantages: efficiency, reduced labour, empowers small-scale fishers, better management data',
    'Technology disadvantages: risk of overfishing, habitat damage from trawling, and high cost',
  ],
  quiz: [
    {q:'What is the purpose of GPS technology in capture fishery?', opts:['To automatically catch fish without human involvement','To improve navigation, vessel safety, and monitoring of fishing locations','To measure the depth of fish ponds','To process and fillet fish on board the vessel'], ans:1},
    {q:'What is filleting?', opts:['Removing scales from the outside of the fish','Cutting fish flesh into strips parallel to the backbone','Drying fish in sunlight to preserve it','Freezing whole fish at -35°C'], ans:1},
    {q:'What is one advantage of LED lights attached to fishing nets?', opts:['They illuminate the entire ocean floor','They attract the right target species while guiding non-target species away','They replace the need for sonar fish detection','They reduce the cost of fishing vessel fuel'], ans:1},
    {q:'Which fishing practice can cause long-term damage to deep-sea coral habitats?', opts:['Handlining','Gillnet fishing','Bottom trawling','Cast net fishing'], ans:2},
    {q:'At what temperature should fish fillets be frozen for preservation?', opts:['0°C to 5°C','10°C to 15°C','-35°C to -40°C','-5°C to -10°C'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/fishery/en/',label:'FAO Fishery Technology',desc:'Fish harvesting technology, processing, and sustainable fisheries management from the FAO.'},
  ]
},

'g10-forests-types': {
  title: 'Tropical Forests & Their Characteristics',
  strand: 'Strand 4: Natural Resources · Unit 4', grade: 10, icon: '🌴',
  lessons: ['Types of Tropical Forests','Forestry Types & Systems','Agroforestry & Community Forestry'],
  currentLesson: 0,
  objectives: [
    'Investigate and analyse the harvesting of tropical forests in different contexts',
    'Categorize and examine different types of forestry according to their characteristics, elements, functions, and purposes',
    'Distinguish between agroforestry and community forestry and explain their characteristics and benefits'
  ],
  keyTerms: [
    {word:'Tropical forest',def:'A closed canopy forest growing within 28 degrees north or south of the equator, receiving more than 200 cm of rainfall per year.'},
    {word:'Selective logging',def:'A harvesting method where only high-value tree species are felled for timber, leaving the majority of trees in place.'},
    {word:'Agroforestry',def:'A system where trees or shrubs are grown in the same land management unit as agricultural crops or animals, gaining from positive interactions.'},
    {word:'Silvopastoral system',def:'A type of agroforestry that combines domesticated animals and forestry on the same land.'},
    {word:'Community forestry',def:'A system where local people are directly involved in forestry activities, with a focus on meeting local needs and maintaining local livelihoods.'},
    {word:'Sustainable Forest Management (SFM)',def:'Management of forests according to the principles of sustainable development, balancing ecological, economic, and socio-cultural objectives.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Types of Tropical Forests</h2>
    <p>Tropical forests are closed canopy forests growing within 28 degrees north or south of the equator. They receive more than 200 cm of rainfall per year, either seasonally or throughout the year. Different categories of tropical forests include:</p>
    <ul>
      <li><strong>Evergreen</strong> — receive rain year-round and have no dry season</li>
      <li><strong>Seasonal</strong> — have evergreen vegetation with a short dry season</li>
      <li><strong>Dry</strong> — have a long dry season during which trees lose their leaves</li>
      <li><strong>Montane (cloud forests)</strong> — receive most precipitation from mist or fog rising from the lowlands</li>
      <li><strong>Tropical and subtropical coniferous</strong> — have dry and warm climates with conifers adapted to variable weather</li>
      <li><strong>Sub-tropical</strong> — located north and south of tropical forests; trees adapted to resist summer drought</li>
    </ul>
    <h3>Harvesting of Tropical Forests</h3>
    <p>Large areas of tropical forest are still being harvested unsustainably — through logging, hunting, or collection of non-timber forest products. In most tropical forests managed for sustainable timber production, harvesting is selective: between two and twenty stems are removed from each hectare of forest, once every few decades. When done carefully, this leaves over 90% of the trees in place.</p>
    <p>However, clearcut logging of natural forests in the tropics also occurs when farmers and ranchers expand cropland and pastures. With selective logging, only high-value species are felled for timber, but many smaller trees are damaged in the process.</p>
  </div>
  <div class="lesson-section">
    <h2>Types of Forestry</h2>
    <p>Forestry is the practice of managing forest lands for various uses including commercial, agricultural, and public. Trees grown on farms serve various purposes: timber production, shade and shelter, groundwater control, prevention of nutrient pollution, erosion prevention, scenic enhancement, and nature conservation.</p>
    <h3>Agroforestry</h3>
    <p>Agroforestry is a system where trees or shrubs are grown in the same land management unit as agricultural crops or animals. There are three main types:</p>
    <ul>
      <li><strong>Agrisilvicultural system</strong> — a combination of crops and trees</li>
      <li><strong>Silvopastoral system</strong> — a combination of domesticated animals and forestry</li>
      <li><strong>Agrosylvopastoral system</strong> — a combination of trees, animals, and crops</li>
    </ul>
    <p>Agroforestry is similar to intercropping and can result in higher overall yields and reduced operational costs. When selecting tree species for agroforestry, they should not compete with crops for soil moisture, nutrients, or sunlight, should have a high survival rate, and should grow quickly and be easy to manage.</p>
    <h3>Functions and Benefits of Agroforestry</h3>
    <ul>
      <li>Maintenance of soil fertility through organic matter inputs, nitrogen fixation, and nutrient recycling</li>
      <li>Conservation of water through greater infiltration and reduced surface runoff</li>
      <li>Carbon capture through silvopastoral systems</li>
      <li>Biodiversity conservation in fragmented landscapes</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Community Forestry</h2>
    <p>Community forestry is where local people are involved in forestry activities. It ranges from woodlots providing wood and other forest products for local needs, to growing trees at the farm level to provide cash crops, to the activities of forest-dwelling communities managing their traditional forest resources.</p>
    <p>Key characteristics of community forestry:</p>
    <ul>
      <li>Willingness by forestry professionals to enter partnership with local people</li>
      <li>A shift from centralized agency management to decentralized management and shared decision-making with local forest users</li>
      <li>Technologies are reoriented to focus benefits on local communities</li>
      <li>Cooperation with community-based organisations representing local interests</li>
    </ul>
    <p>Community forestry comprises three main elements: provision of fuel and essential goods at the household level; provision of food and the environmental conditions for continued food production; and generation of income and employment in the rural community. As the FAO stated, forestry for community development must be "forestry for the people and involving the people."</p>
  </div>`,
  summary: [
    'Tropical forests grow within 28 degrees of the equator and receive more than 200 cm of rainfall per year',
    'Six tropical forest types: evergreen, seasonal, dry, montane, subtropical coniferous, and sub-tropical',
    'Sustainable selective logging removes 2–20 stems per hectare every few decades, leaving over 90% of trees intact',
    'Agroforestry combines trees with crops (agrisilvicultural), animals (silvopastoral), or both (agrosylvopastoral)',
    'Community forestry involves local people in management, focusing on local needs, income, and food security',
    'Agroforestry benefits: soil fertility, water conservation, carbon capture, and biodiversity conservation',
  ],
  quiz: [
    {q:'What type of tropical forest receives precipitation mainly from mist or fog rising from the lowlands?', opts:['Evergreen forest','Dry forest','Montane (cloud) forest','Sub-tropical forest'], ans:2},
    {q:'In sustainable selective logging of tropical forests, approximately how many stems are removed per hectare?', opts:['200 to 500 stems','50 to 100 stems','2 to 20 stems','All trees are removed'], ans:2},
    {q:'What is a silvopastoral agroforestry system?', opts:['A combination of crops and trees only','A combination of domesticated animals and forestry','A combination of trees, crops, and animals','A system of forest management without any farming'], ans:1},
    {q:'What is the central purpose of community forestry according to the FAO?', opts:['Maximum commercial timber production for export','Conservation of forests with no human use','Forestry for the people and involving the people, starting from the grassroots','Government management of all forest resources'], ans:2},
    {q:'Which of the following is a benefit of agroforestry systems?', opts:['Increases soil erosion by removing trees','Reduces biodiversity by planting only one tree species','Maintains soil fertility through organic matter inputs and nitrogen fixation','Reduces crop yields by competing for sunlight and water'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/forestry/en/',label:'FAO Forestry',desc:'Tropical forest types, agroforestry systems, and community forestry resources from the FAO.'},
  ]
},

'g10-forest-management': {
  title: 'Forest Management & Monitoring Systems',
  strand: 'Strand 4: Natural Resources · Unit 5', grade: 10, icon: '📊',
  lessons: ['Sustainable Forest Management','Forest Regulation in PNG','Forest Monitoring Systems'],
  currentLesson: 0,
  objectives: [
    'Explain what sustainable forest management is and describe its three main pillars',
    'Describe forest regulation in Papua New Guinea including the Forestry Act',
    'Identify and explain forest monitoring systems and practices used in different environments'
  ],
  keyTerms: [
    {word:'Sustainable Forest Management (SFM)',def:'Management of forests according to the principles of sustainable development, keeping a balance between ecological, economic, and socio-cultural pillars.'},
    {word:'Ecosystem approach',def:'A conceptual framework for resolving ecosystem issues through scientific reasoning, protecting the environment and its inhabitants from harm.'},
    {word:'Forest regulation',def:'Laws governing activities in designated forest lands, particularly with respect to forest management and timber harvesting.'},
    {word:'Timber permit',def:'A legal authorization issued under the Forestry Act 1993 that allows forest industry activities on specified land areas in PNG.'},
    {word:'Forest monitoring',def:'The ongoing assessment of the technical, environmental, and social performance and impacts of forest management.'},
    {word:'Auditing (forestry)',def:'A complementary component to monitoring — a periodic, formal evaluation of whether management objectives are being achieved.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Sustainable Forest Management</h2>
    <p>Sustainable forest management (SFM) is the management of forests according to the principles of sustainable development. It deals with the administrative, economic, legal, social, technical, and scientific aspects of managing natural and planted forests.</p>
    <p>SFM must keep the balance between three main pillars:</p>
    <ul>
      <li><strong>Ecological</strong> — protecting biodiversity, ecosystem services (water, soil, climate), and the long-term health of the forest</li>
      <li><strong>Economic</strong> — producing timber and other forest products to generate income and support livelihoods</li>
      <li><strong>Socio-cultural</strong> — meeting the cultural, spiritual, and social needs of communities that depend on forests</li>
    </ul>
    <p>Successfully achieving sustainable forest management provides integrated benefits ranging from safeguarding local livelihoods to protecting biodiversity, reducing rural poverty, and mitigating some effects of climate change.</p>
    <h3>Ecosystem Approach</h3>
    <p>The ecosystem approach is a conceptual framework for resolving ecosystem issues through scientific reasoning. It incorporates humans, the economy, and ecology into the solution of any given environmental problem, aiming to preserve the Earth and its inhabitants from potential permanent damage while maximising long-term productive capacity.</p>
  </div>
  <div class="lesson-section">
    <h2>Forest Regulation in Papua New Guinea</h2>
    <p>In Papua New Guinea, forest industry activities are carried out under the <strong>Forestry Act 1993</strong> under either a timber permit, a timber authority, or a license. The Head of State, acting on advice, may make regulations prescribing matters including:</p>
    <ul>
      <li>The management of National forests and forests on government land, including the regulation of cutting, removal, and sawing of timber</li>
      <li>The forms of timber permits, timber authorities, and licenses — including the manner of applying for, granting, and registering them</li>
      <li>The procedure for the sale of forest produce by auction or tender</li>
      <li>The assessing of royalty on forest produce and the payment and distribution of royalties</li>
      <li>The fees and deposits to be paid with any application or tender</li>
      <li>The rate and amounts of rents, fees, dues, and charges payable in respect of timber permits and licenses</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Forest Monitoring Systems</h2>
    <p>Effective monitoring is essential for sustainable forest management. An important distinction exists between monitoring and auditing, which are complementary components of a monitoring system.</p>
    <p><strong>Monitoring</strong> can be defined as the ongoing assessment of the technical, environmental, and social performance and impacts of management. A monitoring system organises monitoring so that it is efficient and easy to implement.</p>
    <p>Monitoring systems vary in sophistication — from simple measuring tools and paper-based recording to advanced electronic equipment. The most important thing is not how sophisticated a system is, but whether information is collected, reviewed, and used efficiently to ensure effective management.</p>
    <p>Principles for effective and cost-efficient forest monitoring:</p>
    <ul>
      <li>Keep monitoring focused on forest management — on what you really need to know</li>
      <li>Whenever possible, use simple and cheap methods</li>
      <li>Use resources already available in the company or organisation</li>
      <li>Wherever appropriate, use easily applied indirect approaches</li>
    </ul>
    <h3>Modern Forest Monitoring Technology</h3>
    <p>In recent years, the prevention and monitoring of forest fires has become a global concern. Traditional forest fire monitoring includes ground patrolling, watching towers, aerial patrolling, long-distance video monitoring, and satellite monitoring. Advanced technology now includes sensor-based detection systems that detect smoke or fire and transmit data wirelessly to a receiver unit for immediate response.</p>
  </div>`,
  summary: [
    'Sustainable Forest Management balances three pillars: ecological, economic, and socio-cultural',
    'The ecosystem approach incorporates humans, economy, and ecology to solve environmental problems sustainably',
    'In PNG, forest activities operate under the Forestry Act 1993 through timber permits, timber authorities, or licences',
    'Forest monitoring is the ongoing assessment of technical, environmental, and social management performance',
    'Monitoring and auditing are complementary — monitoring is ongoing; auditing is a periodic formal evaluation',
    'Modern forest fire monitoring uses sensors, satellites, drones, and wireless transmission systems',
  ],
  quiz: [
    {q:'What are the three main pillars of Sustainable Forest Management?', opts:['Timber, water, and wildlife','Ecological, economic, and socio-cultural','Commercial, residential, and industrial','Production, processing, and marketing'], ans:1},
    {q:'Under what legislation are forest industry activities in Papua New Guinea regulated?', opts:['The PNG Environment Act 1999','The Forestry Act 1993','The Land Act 1996','The Mining Act 1992'], ans:1},
    {q:'What is the main difference between forest monitoring and auditing?', opts:['Monitoring is done by the government; auditing is done by companies','Monitoring is ongoing assessment; auditing is a periodic formal evaluation','Monitoring uses technology; auditing uses traditional methods only','Monitoring only covers timber production; auditing covers all forest activities'], ans:1},
    {q:'Which of the following is a principle of cost-efficient forest monitoring?', opts:['Use the most expensive and sophisticated equipment available','Hire external consultants for all monitoring activities','Keep monitoring focused on what you really need to know and use simple methods when possible','Monitor every tree in the management area monthly'], ans:2},
    {q:'What do modern forest fire monitoring systems detect and transmit?', opts:['Animal movements and biodiversity data','Timber volumes and royalty payments','Smoke or fire data via wireless sensor networks','Rainfall and soil moisture levels'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/forestry/en/',label:'FAO Sustainable Forestry',desc:'Sustainable forest management, forest regulation, and monitoring systems from the FAO.'},
  ]
},

'g10-forest-conservation': {
  title: 'Preserving & Sustaining Forests',
  strand: 'Strand 4: Natural Resources · Unit 5', grade: 10, icon: '🌿',
  lessons: ['Conservation of Forests','Forest Preservation Methods','Sustainable Forestry Practices'],
  currentLesson: 0,
  objectives: [
    'Explain what forest conservation is and describe the threats that make conservation necessary',
    'Identify different ways of preserving and sustaining forests in different environments',
    'Describe sustainable forestry practices that allow forests to be used without being permanently destroyed'
  ],
  keyTerms: [
    {word:'Forest conservation',def:'The preservation and protection of forests from destruction, including the reversal of deforestation and environmental pollution.'},
    {word:'Controlled deforestation',def:'Managing the rate and extent of tree felling so that forests are not cleared faster than they can regenerate.'},
    {word:'Afforestation',def:'The process of planting trees in an area to increase forest cover, balance the ecosystem, and reduce the effects of deforestation.'},
    {word:'Fire lane',def:'A cleared strip of land created in a forest to act as a barrier to prevent fire from spreading from one area to another.'},
    {word:'Slash and burn farming',def:'A farming practice where vegetation is cut down and burned to clear land for agriculture. Harmful to forest ecosystems.'},
    {word:'Shifting agriculture',def:'A farming practice where cultivated land is left fallow after a few years and new forest areas are cleared. Can cause permanent deforestation.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>What is Forest Conservation?</h2>
    <p>Conservation of the forest means saving the forest environment from destruction. Forest conservation is the preservation and protection of forests. It also involves the reversal of deforestation and environmental pollution. The preservation of all natural resources is absolutely essential for the balance of our ecosystem.</p>
    <p>Forests face threats from human activities including: agriculture expansion (clearing land for farms and pastures), transport infrastructure development (road building through forested areas), unsustainable logging, air pollution, and intentional burning of forests.</p>
  </div>
  <div class="lesson-section">
    <h2>Ways of Preserving and Sustaining Forests</h2>
    <h3>Controlled Deforestation</h3>
    <p>While deforestation cannot be avoided completely, it must be controlled. Young and immature trees should not be felled. Large-scale commercial deforestation must be avoided. Adapting practices such as clear-cutting in rotation with natural regeneration, or selective cutting, will be beneficial in the long run. Sustainable use of the forest means harvesting at the rate at which forests can regenerate.</p>
    <h3>Protection Against Forest Fires</h3>
    <p>Forest fires are one of the most common and deadly causes of forest loss. They can start due to natural causes (lightning) or accidents caused by humans, or even intentionally. Once a fire spreads in a forest it is very difficult to control. Precautions include:</p>
    <ul>
      <li>Making fire lanes — cleared strips that act as barriers to stop fire spreading</li>
      <li>Spreading fire retardant chemicals in high-risk areas</li>
      <li>Clearing out dry leaves and dead trees that act as fuel</li>
      <li>Early warning monitoring systems using sensors and drones</li>
    </ul>
    <h3>Afforestation</h3>
    <p>Afforestation is the process of planting more trees in an area to increase forest cover. It can be done through manual transplantation or fresh plantation of native tree species. It is an attempt to balance our ecosystem and reduce the effects of deforestation and environmental pollution of all types.</p>
    <h3>Better Farming Practices</h3>
    <p>Slash and burn farming, overgrazing by cattle, and shifting agriculture are all farming practices that are harmful to the environment and particularly to forests. These practices must be kept under control and replaced with sustainable alternatives such as:</p>
    <ul>
      <li>Agroforestry — integrating trees with crops and animals to reduce the pressure to clear new forest land</li>
      <li>Permanent field agriculture — farming the same land continuously using soil improvement techniques rather than clearing new forest areas</li>
      <li>Community forest management — giving local communities rights and responsibility for sustainably managing their forest resources</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Papua New Guinea and Forest Conservation</h2>
    <p>Papua New Guinea is home to some of the world\'s largest and most biodiverse tropical forests. PNG\'s forests cover approximately 70% of the country\'s land area and are home to thousands of plant and animal species found nowhere else on Earth.</p>
    <p>Key conservation challenges in PNG include: large-scale commercial logging concessions, land clearing for oil palm plantations, shifting cultivation by smallholder farmers, and illegal logging in protected areas. Conservation efforts are supported through: community-based forest management agreements, protected area networks, REDD+ programs (Reducing Emissions from Deforestation and Forest Degradation), and PNG government forestry regulations under the Forestry Act 1993.</p>
  </div>`,
  summary: [
    'Forest conservation means preserving and protecting forests from destruction and reversing deforestation',
    'Threats include agriculture expansion, road building, unsustainable logging, pollution, and burning',
    'Controlled deforestation means harvesting at the rate forests can regenerate, avoiding clear-cutting young trees',
    'Fire lanes, fire retardant chemicals, and early monitoring systems protect against forest fires',
    'Afforestation increases forest cover through planting native trees to restore degraded areas',
    'Sustainable alternatives to slash-and-burn include agroforestry and permanent field agriculture',
  ],
  quiz: [
    {q:'What is the main goal of forest conservation?', opts:['Clearing forests for agriculture and development','Saving forests from destruction and reversing deforestation','Maximising timber production from all forest areas','Replacing natural forests with commercial plantations'], ans:1},
    {q:'What is a fire lane in forest management?', opts:['A road used by fire trucks in urban areas','A cleared strip of land that acts as a barrier to prevent fire from spreading','A chemical sprayed on trees to make them fire-resistant','A zone where controlled burning is allowed'], ans:1},
    {q:'What is afforestation?', opts:['The cutting down of old trees to make room for new growth','The process of planting trees in an area to increase forest cover','The removal of invasive tree species from a forest','The practice of burning forest undergrowth to stimulate tree growth'], ans:1},
    {q:'Which farming practice is most harmful to forest ecosystems in PNG?', opts:['Agroforestry with permanent tree crops','Permanent field agriculture with soil improvement','Slash and burn farming and shifting agriculture','Community-based forest management'], ans:2},
    {q:'PNG\'s forests cover approximately what percentage of the country\'s land area?', opts:['30%','50%','70%','90%'], ans:2},
  ],
  furtherReading: [
    {url:'https://www.fao.org/forestry/en/',label:'FAO Forest Conservation',desc:'Forest conservation, afforestation, and sustainable forest management resources from the FAO.'},
  ]
},

'g10-forestry-tech': {
  title: 'Forestry Technology: Harvesting & Processing',
  strand: 'Strand 4: Natural Resources · Unit 6', grade: 10, icon: '🪵',
  lessons: ['Forest Monitoring & Preservation Technology','Forest Harvesting Technology','Processing Forest Products'],
  currentLesson: 0,
  objectives: [
    'Investigate and explain forest monitoring and preservation technology used in different environments',
    'Identify the tools and equipment used in harvesting and processing forest products',
    'Evaluate the strengths and weaknesses of technology used in forestry'
  ],
  keyTerms: [
    {word:'Forest protection',def:'A branch of forestry concerned with the preservation or improvement of a forest and the prevention and control of damage from natural or man-made causes.'},
    {word:'Remote sensing',def:'The use of satellite or aerial imagery to collect information about forest cover, deforestation, and forest health from a distance.'},
    {word:'Forest fire monitoring',def:'Systems and technology used to detect, track, and respond to wildfires in forest areas, including satellite monitoring, aerial patrolling, and sensor-based detection.'},
    {word:'Sawmill',def:'A facility where logs are cut into planks, boards, and other timber products using mechanical saws.'},
    {word:'Chainsaw',def:'A portable mechanical saw powered by a petrol or electric motor, used to fell trees and cut logs during harvesting operations.'},
    {word:'Reduced-impact logging',def:'A set of forestry practices designed to minimise the environmental impact of timber harvesting while maintaining commercial viability.'},
  ],
  content: `
  <div class="lesson-section">
    <h2>Forest Monitoring and Preservation Technology</h2>
    <p>Forests are among the most important resources for human survival and social development, protecting the balance of the earth's ecology. There is a need to design smart and efficient forest monitoring systems.</p>
    <p>Forest protection is a branch of forestry concerned with the preservation or improvement of forests and the prevention and control of damage from natural or man-made causes — including fire, animals, insects, fungi, injurious plants, and adverse climatic conditions.</p>
    <h3>Forest Fire Monitoring Technology</h3>
    <p>In recent years, prevention and monitoring of forest fires has become a global concern. Traditional forest fire monitoring measures include:</p>
    <ul>
      <li>Ground patrolling by forest rangers</li>
      <li>Watching towers providing elevated visual surveillance</li>
      <li>Aerial patrolling by aircraft or helicopters</li>
      <li>Long-distance video monitoring using cameras</li>
      <li>Satellite monitoring — detecting heat signatures and smoke from space</li>
    </ul>
    <p>Advanced technology now includes sensor-based detection systems that detect smoke or fires using sensors. Data from the sensors is processed in a microcontroller and transmitted wirelessly to a receiver unit, enabling immediate response.</p>
    <h3>Remote Sensing and GIS</h3>
    <ul>
      <li><strong>Satellite imagery</strong> — used to monitor forest cover change, identify deforestation hot-spots, and track forest fires across large areas</li>
      <li><strong>Drones (UAVs)</strong> — used for detailed aerial surveys of forest health, timber volume estimation, and post-fire assessment</li>
      <li><strong>GPS mapping</strong> — enables precise mapping of forest boundaries, logging roads, and protected areas</li>
      <li><strong>GIS (Geographic Information Systems)</strong> — software platforms that integrate satellite data, GPS data, and other information to produce detailed forest maps</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Forest Harvesting Technology</h2>
    <p>Forest harvesting requires a range of tools depending on the scale of the operation and the harvesting method used:</p>
    <h3>Hand Tools</h3>
    <ul>
      <li><strong>Chainsaws</strong> — portable mechanical saws for felling trees and cutting logs. Used in selective cutting and strip cutting operations.</li>
      <li><strong>Axes and machetes</strong> — used for clearing undergrowth, removing branches, and smaller cutting tasks.</li>
      <li><strong>Diameter tapes and hypsometers</strong> — measuring tools used to estimate tree diameter and height for timber volume calculations.</li>
    </ul>
    <h3>Heavy Machinery</h3>
    <ul>
      <li><strong>Skidders</strong> — wheeled or tracked machines that drag felled logs from the cutting site to loading areas, reducing manual labour.</li>
      <li><strong>Forwarders</strong> — carry logs on a trailer rather than dragging them, causing less soil compaction.</li>
      <li><strong>Log loaders</strong> — cranes or claw machines that lift and load logs onto trucks for transport to sawmills.</li>
      <li><strong>Bulldozers</strong> — used for road construction in forest areas to allow vehicle and machinery access.</li>
    </ul>
    <h3>Forest Processing Technology</h3>
    <ul>
      <li><strong>Sawmills</strong> — fixed or portable facilities where logs are cut into planks, boards, and timber products. Portable sawmills can operate without heavy road construction.</li>
      <li><strong>Wood chippers</strong> — machines that process small-diameter wood and branches into wood chips for paper production or biomass energy.</li>
      <li><strong>Kilns</strong> — drying chambers that remove moisture from sawn timber to prevent warping and improve strength and durability.</li>
    </ul>
  </div>
  <div class="lesson-section">
    <h2>Strengths and Weaknesses of Forestry Technology</h2>
    <h3>Strengths</h3>
    <ul>
      <li>Increases speed and volume of timber harvesting operations</li>
      <li>Reduces physical danger to workers through mechanisation</li>
      <li>Enables better monitoring and conservation through remote sensing and GIS</li>
      <li>Improves accuracy of forest inventories and replanting schedules</li>
      <li>Sensor-based fire detection allows faster response to forest fires</li>
    </ul>
    <h3>Weaknesses</h3>
    <ul>
      <li>High capital cost of machinery is beyond the reach of small-scale operators and PNG rural communities</li>
      <li>Heavy machinery compacts soil, damages root systems, and leaves tracks that cause erosion</li>
      <li>Road construction for machinery access fragments forest habitats, increasing threats to biodiversity</li>
      <li>Technology enables faster harvesting — if not managed carefully, this can accelerate unsustainable deforestation</li>
      <li>Requires skilled operators and regular maintenance, which may not be available in remote PNG locations</li>
    </ul>
    <p>The solution is to apply <strong>reduced-impact logging</strong> techniques that minimise soil disturbance and damage to remaining trees, combined with sustainable harvesting quotas enforced through government regulation and forest inventory data.</p>
  </div>`,
  summary: [
    'Forest protection covers prevention and control of damage from fire, insects, fungi, animals, and climatic conditions',
    'Forest fire monitoring uses ground patrols, watch towers, aerial surveillance, satellites, and wireless sensor networks',
    'Remote sensing, drones, GPS, and GIS software enable large-scale forest monitoring without physical access to every area',
    'Harvesting tools include chainsaws, axes, skidders, forwarders, log loaders, and bulldozers',
    'Sawmills, wood chippers, and kilns process logs into usable timber products',
    'Strengths: efficiency, worker safety, better monitoring; Weaknesses: high cost, soil compaction, habitat fragmentation',
  ],
  quiz: [
    {q:'What is the purpose of a hypsometer in forestry?', opts:['To measure tree height for timber volume calculation','To detect fire and smoke in forest areas','To drill holes in trees for sap collection','To compact soil after logging operations'], ans:0},
    {q:'Which technology transmits fire and smoke detection data wirelessly to a receiver unit for immediate response?', opts:['Chainsaw GPS systems','Satellite-only monitoring','Sensor-based detection systems with wireless microcontrollers','Ground patrol radio communications'], ans:2},
    {q:'What is an advantage of portable sawmills over fixed sawmills in PNG forestry?', opts:['They produce higher quality timber products','They can operate without heavy road construction, reducing habitat fragmentation','They are cheaper to purchase and operate','They process larger logs than fixed sawmills'], ans:1},
    {q:'Which of the following is a weakness of using heavy machinery in forest harvesting?', opts:['Heavy machinery improves worker safety','Machinery enables better monitoring of forest health','Heavy machinery compacts soil and damages root systems','Machinery reduces the speed of timber harvesting'], ans:2},
    {q:'What does remote sensing allow foresters to do?', opts:['Operate chainsaws from a safe distance','Monitor forest cover change and detect deforestation from satellites without physical access to every area','Process logs into timber products more efficiently','Calculate the market price of timber products'], ans:1},
  ],
  furtherReading: [
    {url:'https://www.fao.org/forestry/en/',label:'FAO Forestry Technology',desc:'Forest monitoring technology, harvesting tools, and sustainable forestry practices from the FAO.'},
  ]
},

}; // end LESSONS

/* ══════════════════════════════════════════
   STRAND DATA
   ══════════════════════════════════════════ */

const STRANDS_9 = [
  {
    id:'crops9', strand:'Strand 1', name:'Crops', icon:'🌾', bg:'#e8f5e2', color:'#3a7d2c',
    desc:'Soil science, crop types, farming practices, horticulture, and technology used in crop production.',
    topics:[
      {id:'g9-soil-formation',title:'Unit 1 — Soil: Types & Formation',icon:'🌱',bg:'#e8f5e2',desc:'What soil is made of, how it forms, and the physical and chemical properties of different soil types.',status:'available',lessons:4},
      {id:'g9-types-crops',title:'Unit 2 — Types of Crops & Their Environments',icon:'🌽',bg:'#fdf3d6',desc:'The different types of crops, where they grow best, and the environmental conditions they need.',status:'available',lessons:3},
      {id:'g9-crop-farming',title:'Unit 3 — Crop Farming Practices & Management',icon:'🚜',bg:'#e8f5e2',desc:'How crops are planted, managed, and harvested — different farming methods and crop management systems.',status:'available',lessons:3},
      {id:'g9-crop-technology',title:'Unit 4 — Crop Farming Technology',icon:'⚙️',bg:'#e0f2fe',desc:'The tools and technologies used in crop cultivation and management — and the advantages and disadvantages.',status:'available',lessons:3},
      {id:'g9-horticulture',title:'Unit 5 — Types of Plants: Introduction to Horticulture',icon:'🍅',bg:'#fdf3d6',desc:'Introduction to horticulture: fruit trees, vegetables, and spice crops — how they are cultivated and processed.',status:'available',lessons:4},
      {id:'g9-pomology-olericulture',title:'Unit 6 — Plant Farming Practices (Pomology & Olericulture)',icon:'🌿',bg:'#e8f5e2',desc:'Cultivation and management of pomology (fruit growing), olericulture (vegetable growing), ornamental plants, and arboriculture.',status:'available',lessons:4},
      {id:'g9-horticulture-technology',title:'Unit 7 — Technology in Horticulture',icon:'💡',bg:'#e0f2fe',desc:'How technology is used to improve cultivation, processing, and marketing of horticulture plants.',status:'available',lessons:3},
    ]
  },
  {
    id:'animals9', strand:'Strand 2', name:'Animals', icon:'🐄', bg:'#f5ece4', color:'#7c4a1e',
    desc:'Monogastric and polygastric animals, their characteristics, care, poultry farming, and management systems.',
    topics:[
      {id:'g9-monogastric-polygastric',title:'Unit 1 — Monogastric & Polygastric Animals',icon:'🐷',bg:'#f5ece4',desc:'What monogastric animals and polygastric (ruminant) animals are — and how they differ.',status:'available',lessons:3},
      {id:'g9-animal-anatomy',title:'Unit 2 — Anatomy of Farm Animals',icon:'🐄',bg:'#e8f5e2',desc:'The body systems of monogastric and polygastric animals — how their digestive systems work.',status:'available',lessons:3},
      {id:'g9-animal-farming',title:'Unit 3 — Animal Farming Practices & Management',icon:'🏠',bg:'#fdf3d6',desc:'How farm animals are housed, fed, and cared for — extensive, semi-intensive, and intensive systems.',status:'available',lessons:4},
      {id:'g9-poultry-types',title:'Unit 4 — Types of Poultry & Their Behaviour',icon:'🐔',bg:'#f5ece4',desc:'Domesticated and farmed birds — their characteristics, behaviours, purposes, and how they are kept.',status:'available',lessons:3},
      {id:'g9-poultry-farming',title:'Unit 5 — Poultry Farming Principles & Systems',icon:'🥚',bg:'#e8f5e2',desc:'Free-range, semi-intensive, and intensive poultry systems and how each is practised.',status:'available',lessons:3},
    ]
  },
  {
    id:'aqua9', strand:'Strand 3', name:'Aquaculture', icon:'🐟', bg:'#e0f2fe', color:'#0369a1',
    desc:'Fish farming in freshwater, brackish, and saltwater environments. Aqua farming practices and technology.',
    topics:[
      {id:'g9-intro-aquaculture',title:'Unit 1 — Introduction to Aquaculture',icon:'🐟',bg:'#e0f2fe',desc:'What aquaculture is, why it matters in Papua New Guinea, and the types of environments.',status:'available',lessons:3},
      {id:'g9-aqua-farming-systems',title:'Unit 2 — Aqua Farming Systems & Practices',icon:'🌊',bg:'#e8f5e2',desc:'How fish and aquatic plants are farmed in freshwater, brackish, and saltwater environments.',status:'available',lessons:4},
      {id:'g9-aqua-technology',title:'Unit 3 — Gears & Technology in Aqua Farming',icon:'⚓',bg:'#e0f2fe',desc:'The equipment and technology used in aquaculture — and how technology improves fish farming.',status:'available',lessons:3},
    ]
  },
  {
    id:'nrm9', strand:'Strand 4', name:'Natural Resource Management', icon:'🌳', bg:'#dcfce7', color:'#16a34a',
    desc:'Forestry, forest types, land management, sustainable harvesting practices, and resource protection.',
    topics:[
      {id:'g9-forests',title:'Unit 1 — Types of Forests & Forest Resources',icon:'🌳',bg:'#dcfce7',desc:'The different types of forests in Papua New Guinea, their characteristics, and the resources they provide.',status:'available',lessons:3},
      {id:'g9-forest-harvesting',title:'Unit 2 — Forest Harvesting Practices',icon:'🪓',bg:'#fdf3d6',desc:'Selective cutting, clear cutting, and strip cutting — how timber is harvested and the environmental consequences.',status:'available',lessons:3},
      {id:'g9-forest-management',title:'Unit 3 — Forest Management & Conservation',icon:'♻️',bg:'#dcfce7',desc:'How forests are managed sustainably and the importance of protecting forest ecosystems.',status:'available',lessons:3},
      {id:'g9-forestry-technology',title:'Unit 4 — Forestry Technology',icon:'🔧',bg:'#e0f2fe',desc:'The tools and technologies used in forest harvesting — and their strengths and weaknesses.',status:'available',lessons:2},
    ]
  },
  {
    id:'agri9', strand:'Strand 5', name:'Agribusiness', icon:'📊', bg:'#fdf3d6', color:'#c8900a',
    desc:'Starting and managing an agricultural business — economics, imports and exports, and business planning.',
    topics:[
      {id:'g9-agribusiness-economics',title:'Unit 1 — Economic Principles in Agribusiness',icon:'💰',bg:'#fdf3d6',desc:'What agribusiness is and how micro and macroeconomic principles apply to farming businesses.',status:'available',lessons:3},
      {id:'g9-agri-imports-exports',title:'Unit 2 — Agricultural Imports & Exports',icon:'🚢',bg:'#e8f5e2',desc:'The role of imports and exports in Papua New Guinea — how global trade affects local farming.',status:'available',lessons:3},
      {id:'g9-agribusiness-planning',title:'Unit 3 — Planning & Managing an Agribusiness',icon:'📋',bg:'#fdf3d6',desc:'Entrepreneurship, types of business ownership, and how to write a basic agribusiness plan.',status:'available',lessons:4},
    ]
  },
];

const STRANDS_10 = [
  {
    id:'crops10', strand:'Strand 1', name:'Crops', icon:'🌾', bg:'#e8f5e2', color:'#3a7d2c',
    desc:'Soil improvement, crop classification, crop management systems, plant propagation technology, and horticulture.',
    topics:[
      {id:'g10-soil-improvement',title:'Unit 1 — Soil Improvement Practices',icon:'🌱',bg:'#e8f5e2',desc:'Natural and artificial techniques to improve soil — and strategies to sustain soil fertility over time.',status:'available',lessons:3},
      {id:'g10-crop-classification',title:'Unit 2 — Crop Classification',icon:'🌾',bg:'#fdf3d6',desc:'How crops are classified by growing cycle, species, season, land type, and type of product.',status:'available',lessons:3},
      {id:'g10-crop-management',title:'Unit 3 — Crop Management Systems & Practices',icon:'🚜',bg:'#e8f5e2',desc:'Different crop management systems used in various contexts and principles of effective crop cultivation.',status:'available',lessons:4},
      {id:'g10-plant-propagation',title:'Unit 4 — Plant Propagation Technology',icon:'🌿',bg:'#e0f2fe',desc:'How technology improves plant propagation — and its impact on plant anatomy and physiology.',status:'available',lessons:3},
      {id:'g10-types-plants',title:'Unit 5 — Types of Agricultural Plants',icon:'🪴',bg:'#f5ece4',desc:'Plantation crops, ornamental plants, and bedding plants — benefits, functions, and classification.',status:'available',lessons:3},
      {id:'g10-ornamental-cultivation',title:'Unit 6 — Cultivation of Ornamental & Bedding Plants',icon:'🌸',bg:'#fce7f3',desc:'How ornamental and bedding plants are cultivated, processed, and marketed.',status:'available',lessons:3},
      {id:'g10-horticulture-tech',title:'Unit 7 — Technology in Horticulture Production',icon:'💡',bg:'#e0f2fe',desc:'Post-harvest technology, processing, packaging, transportation, and marketing.',status:'available',lessons:3},
    ]
  },
  {
    id:'animals10', strand:'Strand 2', name:'Animals', icon:'🐄', bg:'#f5ece4', color:'#7c4a1e',
    desc:'Animal breeds and physiology, husbandry, post-harvest technology, and online marketing of animal products.',
    topics:[
      {id:'g10-animal-breeds',title:'Unit 1 — Breeds of Monogastric & Polygastric Animals',icon:'🐷',bg:'#f5ece4',desc:'Classification of pig, goat, sheep, and cattle breeds — their characteristics and purposes.',status:'available',lessons:4},
      {id:'g10-animal-physiology',title:'Unit 2 — Animal Physiology: Digestive & Reproductive Systems',icon:'🔬',bg:'#e8f5e2',desc:'How digestive and reproductive systems of farm animals work — including the oestrous cycle.',status:'available',lessons:4},
      {id:'g10-animal-husbandry',title:'Unit 3 — Animal Husbandry & Management Practices',icon:'🏠',bg:'#fdf3d6',desc:'Extensive, semi-intensive, and intensive management systems and day-to-day husbandry.',status:'available',lessons:4},
      {id:'g10-animal-nutrition',title:'Unit 4 — Animal Nutrition, Feeding & Health',icon:'🌿',bg:'#e8f5e2',desc:'How animals are fed, grazing land management, and how animal health and housing are maintained.',status:'available',lessons:3},
      {id:'g10-animal-postharvest',title:'Unit 5 — Post-Harvest Processing of Animal Products',icon:'🥩',bg:'#f5ece4',desc:'Technology used to process, preserve, and package animal products.',status:'available',lessons:3},
      {id:'g10-poultry-management',title:'Unit 6 — Poultry Breeds, Management & Technology',icon:'🐔',bg:'#fdf3d6',desc:'Breeds of domesticated birds, poultry production systems, and technology impact.',status:'available',lessons:4},
    ]
  },
  {
    id:'aqua10', strand:'Strand 3', name:'Aquaculture', icon:'🐟', bg:'#e0f2fe', color:'#0369a1',
    desc:'Freshwater, brackish, and saltwater aqua farming — systems, capture fishery, sustainability, and technology.',
    topics:[
      {id:'g10-aqua-environments',title:'Unit 1 — Freshwater, Brackish & Saltwater Farming',icon:'💧',bg:'#e0f2fe',desc:'How fish and aquatic plants are cultivated in different water environments.',status:'available',lessons:4},
      {id:'g10-aqua-management',title:'Unit 2 — Aqua Farming Management Systems',icon:'🌊',bg:'#e8f5e2',desc:'Fish and aqua plant farming management systems and sustainable practices.',status:'available',lessons:4},
      {id:'g10-capture-fishery',title:'Unit 3 — Capture Fishery: Harvesting & Management',icon:'🎣',bg:'#e0f2fe',desc:'How capture fish and other aquatic organisms are harvested and managed.',status:'available',lessons:3},
      {id:'g10-aqua-tech',title:'Unit 4 — Technology in Aquaculture & Capture Fishery',icon:'⚙️',bg:'#fdf3d6',desc:'Technology for farming, harvesting, processing, and preserving fish.',status:'available',lessons:3},
    ]
  },
  {
    id:'nrm10', strand:'Strand 4', name:'Natural Resource Management', icon:'🌳', bg:'#dcfce7', color:'#16a34a',
    desc:'Tropical forestry, forest management, regulation and monitoring, preservation technology.',
    topics:[
      {id:'g10-forests-types',title:'Unit 1 — Tropical Forests & Their Characteristics',icon:'🌴',bg:'#dcfce7',desc:'Types of tropical forests in PNG — farm forestry, agroforestry, community forestry, and silviculture.',status:'available',lessons:3},
      {id:'g10-forest-management',title:'Unit 2 — Forest Management & Monitoring Systems',icon:'📋',bg:'#e8f5e2',desc:'Sustainable forest management — ecosystem approach, regulations, and monitoring practices.',status:'available',lessons:3},
      {id:'g10-forest-conservation',title:'Unit 3 — Preserving & Sustaining Forests',icon:'♻️',bg:'#dcfce7',desc:'Why forest preservation matters and the ways forests can be sustained.',status:'available',lessons:3},
      {id:'g10-forestry-tech',title:'Unit 4 — Forestry Technology: Harvesting & Processing',icon:'🔧',bg:'#e0f2fe',desc:'Technology for monitoring, preserving, processing, and marketing forestry products.',status:'available',lessons:2},
    ]
  },
  {
    id:'agri10', strand:'Strand 5', name:'Agribusiness', icon:'📊', bg:'#fdf3d6', color:'#c8900a',
    desc:'Risk management, marketing strategies, sales, and obtaining and managing start-up capital.',
    topics:[
      {id:'g10-agribusiness-risk',title:'Unit 1 — Managing Risk in Agribusiness',icon:'⚠️',bg:'#fdf3d6',desc:'Sources of risk and uncertainty in farming businesses — and strategies to manage and reduce them.',status:'available',lessons:3},
      {id:'g10-agribusiness-marketing',title:'Unit 2 — Agribusiness Communication & Marketing',icon:'📣',bg:'#e8f5e2',desc:'Markets, marketing principles, sales strategies, and the components of an effective sales process.',status:'available',lessons:3},
      {id:'g10-agribusiness-startup',title:'Unit 3 — Starting Up an Agribusiness',icon:'🚀',bg:'#fdf3d6',desc:'How to obtain start-up capital, manage it, and launch a farming business.',status:'available',lessons:3},
    ]
  },
];

const POSTS = [
  {title:'What is Soil and Why Does It Matter?',cat:'Grade 9 — Crops',icon:'🌱',bg:'#e8f5e2',date:'May 5, 2026',read:'5 min',ex:'Soil is much more than dirt. It is a living system that determines whether crops will thrive or fail. Understanding soil composition, physical properties, and chemical properties is a foundation for all crop farming.',id:'g9-soil-formation',grade:9,ref:'https://www.fao.org/soils-portal/en/',refLabel:'FAO Soils Portal'},
  {title:'Monogastric vs Polygastric Animals — What is the Difference?',cat:'Grade 9 — Animals',icon:'🐷',bg:'#f5ece4',date:'Apr 22, 2026',read:'4 min',ex:'Pigs and cattle are both farm animals — but their digestive systems are completely different. Understanding the distinction between monogastric and polygastric animals is essential for Grade 9 Animal Science.',id:'g9-monogastric-polygastric',grade:9,ref:'https://www.fao.org/animal-production/en/',refLabel:'FAO Animal Production'},
  {title:'An Introduction to Aquaculture in Papua New Guinea',cat:'Grade 9 — Aquaculture',icon:'🐟',bg:'#e0f2fe',date:'Apr 10, 2026',read:'5 min',ex:'Papua New Guinea has some of the richest aquatic environments in the world. Aquaculture — the farming of fish and aquatic plants — is a growing industry that plays an important role in food security.',id:'g9-intro-aquaculture',grade:9,ref:'https://www.fao.org/fishery/en/aquaculture',refLabel:'FAO Aquaculture'},
  {title:'Soil Improvement — Natural vs Artificial Techniques',cat:'Grade 10 — Crops',icon:'🌿',bg:'#dcfce7',date:'Mar 28, 2026',read:'5 min',ex:'Grade 10 students go beyond understanding soil — they need to know how to improve it. From composting and green manuring to lime application and inorganic fertilisers, soil improvement is central to sustainable crop farming.',id:'g10-soil-improvement',grade:10,ref:'https://www.fao.org/soils-portal/soil-management/en/',refLabel:'FAO Soil Management'},
  {title:'What is Agribusiness? A Plain Language Guide',cat:'Grade 9 & 10 — Agribusiness',icon:'📊',bg:'#fdf3d6',date:'Mar 14, 2026',read:'4 min',ex:'Agribusiness is not just farming — it covers everything from production to marketing to finance. This guide explains economic principles, supply and demand, and how they apply to farming businesses in Papua New Guinea.',id:'g9-agribusiness-economics',grade:9,ref:'https://www.fao.org/rural-employment/en/',refLabel:'FAO Agribusiness Resources'},
  {title:'Forest Types in Papua New Guinea',cat:'Grade 9 — Natural Resources',icon:'🌳',bg:'#dcfce7',date:'Feb 28, 2026',read:'5 min',ex:"Papua New Guinea is home to some of the world\'s most biodiverse forests. This article covers the major forest types — tropical rainforest, monsoon forest, mangrove, and grassland — and the resources each provides.",id:'g9-forests',grade:9,ref:'https://www.fao.org/forestry/en/',refLabel:'FAO Forestry'},
  {title:'Pomology, Olericulture & Ornamental Horticulture',cat:'Grade 9 — Crops (Unit 6)',icon:'🌿',bg:'#e8f5e2',date:'Feb 14, 2026',read:'5 min',ex:'The horticulture industry covers three main areas: pomology (fruit growing), olericulture (vegetable growing), and ornamental horticulture. Each has distinct management practices, cultivation techniques, and markets.',id:'g9-pomology-olericulture',grade:9,ref:'https://www.fao.org/horticulture/en/',refLabel:'FAO Horticulture'},
  {title:'Technology in Horticulture Production',cat:'Grade 9 — Crops (Unit 7)',icon:'💡',bg:'#e0f2fe',date:'Jan 30, 2026',read:'4 min',ex:'Technology is changing how horticulture products are grown, preserved, and marketed in Papua New Guinea — from irrigation systems and pest control to E-Commerce and digital marketing tools for small farmers.',id:'g9-horticulture-technology',grade:9,ref:'https://www.fao.org/digital-agriculture/en/',refLabel:'FAO Digital Agriculture'},
];

const TAGS = ['Soil Science','Crops','Horticulture','Farm Animals','Aquaculture','Forestry','Agribusiness','Grade 9','Grade 10','PNG Agriculture','Poultry','Fish Farming'];

/* ══════════════════════════════════════════
   STATE
   ══════════════════════════════════════════ */
let currentGrade = 9;
let currentLessonId = null;
let quizAnswers = {};
let quizSubmitted = false;

function setGrade(g){
  const url = new URL(window.location.href);
  url.pathname = '/topics.html';
  url.searchParams.set('grade', g);
  window.location.href = url.toString();
}

/* ══════════════════════════════════════════
   NAVIGATION
   ══════════════════════════════════════════ */
function nav(page){
  const pageMap = {
    'home': '/',
    'modules': '/topics.html',
    'blog': '/resources.html',
    'about': '/about.html',
    'careers': '/careers.html',
    'contact': '/contact.html',
    'privacy': '/privacy.html',
    'terms': '/terms.html'
  };
  if (pageMap[page]) {
    window.location.href = pageMap[page];
  }
}

/* ══════════════════════════════════════════
   MODULES
   ══════════════════════════════════════════ */
function filterGrade(g){
  currentGrade = g;
  document.querySelectorAll('.grade-tab').forEach(t=>t.classList.toggle('active',+t.dataset.grade===g));
  renderModules(g);
}

function renderModules(grade){
  const strands = grade===9 ? STRANDS_9 : STRANDS_10;
  const el = document.getElementById('modules-content');
  if(!el) return;
  el.innerHTML = strands.map(s=>`
    <div class="strand-section">
      <div class="strand-header">
        <div class="strand-header-icon" style="background:${s.bg}">${s.icon}</div>
        <div>
          <h2>${s.strand}: ${s.name}</h2>
          <p>${s.desc}</p>
        </div>
      </div>
      <div class="topics-grid">
        ${s.topics.map(t=>`
          <article class="topic-card${t.status==='coming'?' locked':''}" ${t.status==='available'&&t.id?`onclick="openLesson('${t.id}')"`:''}>
            <div class="tc-thumb" style="background:${t.bg}">
              ${t.icon}
              <span class="tc-status ${t.status}">${t.status==='available'?'Available':'In Progress'}</span>
            </div>
            <div class="tc-body">
              <h3>${t.title}</h3>
              <p>${t.desc}</p>
            </div>
            <div class="tc-foot">
              <div class="tc-meta">📖 ${t.lessons} lessons</div>
              ${t.status==='available'&&t.id
                ? `<button class="tc-btn" onclick="event.stopPropagation();openLesson('${t.id}')">Start →</button>`
                : `<button class="tc-btn locked-btn" disabled>In Progress</button>`}
            </div>
          </article>
        `).join('')}
      </div></a>`).join("");
}

/* ══════════════════════════════════════════
   LESSON PAGE
   ══════════════════════════════════════════ */
/* ── LOGO COLOR SWITCHER ── */
const STRAND_COLORS = {
  'Crops':       '#3a7d2c',
  'Animals':     '#c47c00',
  'Aquaculture': '#0891b2',
  'NRM':         '#166534',
  'Agribusiness':'#7c3aed'
};
const DEFAULT_COLOR = '#3a7d2c';

function setLogoColor(color){
  const bg    = document.getElementById('logo-bg');
  const stem  = document.getElementById('logo-stem');
  const leaf1 = document.getElementById('logo-leaf1');
  const leaf2 = document.getElementById('logo-leaf2');
  const lab   = document.getElementById('lab-text');
  if(bg)    bg.setAttribute('fill', color);
  if(stem)  stem.setAttribute('stroke', color);
  if(leaf1) leaf1.setAttribute('stroke', color);
  if(leaf2) leaf2.setAttribute('stroke', color);
  if(lab)   lab.style.color = color;
  // Update favicon
  const faviconSVG = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' rx='18' fill='${color}'/><text y='.9em' font-size='72' x='12'>🌾</text></svg>`;
  let link = document.querySelector("link[rel~='icon']");
  if(link) link.href = 'data:image/svg+xml,' + encodeURIComponent(faviconSVG);
}

function getStrandColor(strandStr){
  if(!strandStr) return DEFAULT_COLOR;
  const s = strandStr.toLowerCase();
  if(s.includes('crop'))  return STRAND_COLORS['Crops'];
  if(s.includes('animal')) return STRAND_COLORS['Animals'];
  if(s.includes('aqua'))  return STRAND_COLORS['Aquaculture'];
  if(s.includes('nrm') || s.includes('natural')) return STRAND_COLORS['NRM'];
  if(s.includes('agribusiness')) return STRAND_COLORS['Agribusiness'];
  return DEFAULT_COLOR;
}

function openLesson(id){ window.location.href = '/lessons/' + id + '.html'; }
  currentLessonId = id;
  quizAnswers = {};
  quizSubmitted = false;
  setLogoColor(getStrandColor(L.strand));

  // Find prev/next available lessons in same grade
  const strands = L.grade === 9 ? STRANDS_9 : STRANDS_10;
  const allAvailable = strands.flatMap(s=>s.topics).filter(t=>t.status==='available'&&t.id);
  const idx = allAvailable.findIndex(t=>t.id===id);
  const prevId = idx > 0 ? allAvailable[idx-1].id : null;
  const nextId = idx < allAvailable.length-1 ? allAvailable[idx+1].id : null;

  // Build quiz HTML
  const quizHTML = L.quiz.map((q,qi)=>`
    <div class="quiz-q" id="qq-${qi}">
      <p>${qi+1}. ${q.q}</p>
      <div class="quiz-opts">
        ${q.opts.map((opt,oi)=>`
          <label class="qopt" id="qopt-${qi}-${oi}">
            <input type="radio" name="q${qi}" value="${oi}" onchange="selectAnswer(${qi},${oi})"/> ${opt}
          </label>
        `).join('')}
      </div></a>`).join("");

  // Build terms HTML
  const termsHTML = L.keyTerms.map(t=>`
    <div class="term"><span class="term-word">${t.word}</span><span class="term-def">${t.def}</span></div>
  `).join('');

  // Build summary HTML
  const summaryHTML = L.summary.map(s=>`<li>${s}</li>`).join('');

  // Build lesson tabs HTML
  const lessonTabsHTML = L.lessons.map((l,i)=>`
    <span class="chip${i===0?' chip-g':''}" style="cursor:default">${l}</span>
  `).join('');

  const html = `
    <div class="lesson-breadcrumb">
      <span onclick="nav('home')">Home</span>
      <span class="sep">›</span>
      <span onclick="setGrade(${L.grade});nav('modules')">Grade ${L.grade} Topics</span>
      <span class="sep">›</span>
      <span style="color:var(--ink)">${L.title}</span>
    </div>

    <div class="lesson-header">
      <div class="lesson-strand-badge">${L.icon} ${L.strand} · Grade ${L.grade}</div>
      <h1>${L.title}</h1>
      <div class="lesson-meta-row">
        <span>📖 ${L.lessons.length} lessons</span>
        <span>🇵🇬 Papua New Guinea Curriculum</span>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">${lessonTabsHTML}</div>
    </div>

    <div class="lesson-body">
      <div class="lesson-objectives">
        <h3>Learning Objectives</h3>
        <ul>${L.objectives.map(o=>`<li>${o}</li>`).join('')}</ul>
      </div>

      ${L.content}

      <div class="key-terms">
        <h3>Key Terms</h3>
        <div class="term-list">${termsHTML}</div>
      </div>

      <div class="summary-box">
        <h3>📝 Summary — What You Should Know</h3>
        <ul>${summaryHTML}</ul>
      </div>

      ${L.furtherReading ? `
      <div class="key-terms" style="border-color:var(--blue);margin-top:0">
        <h3 style="color:var(--blue)">Further Reading</h3>
        <div style="display:flex;flex-direction:column;gap:10px">
          ${L.furtherReading.map(r=>`
            <a href="${r.url}" target="_blank" rel="noopener noreferrer" style="display:flex;align-items:flex-start;gap:10px;font-size:.87rem;color:var(--ink2);transition:color .18s" onmouseover="this.style.color='var(--blue)'" onmouseout="this.style.color='var(--ink2)'">
              <span style="color:var(--blue);flex-shrink:0">↗</span>
              <span><strong style="color:var(--blue)">${r.label}</strong> — ${r.desc}</span>
            </a>
          `).join('')}
        </div>
      </div>` : ''}

      <div class="quiz-section" id="quiz-section">
        <div class="quiz-header">
          <div class="quiz-icon">❓</div>
          <div>
            <h2>Check Your Understanding</h2>
            <p style="font-size:.8rem;color:var(--ink3);margin:2px 0 0">Answer all questions then submit to see how you did.</p>
          </div>
        </div>
        ${quizHTML}
        <button class="btn btn-primary btn-sm" id="quiz-submit-btn" onclick="submitQuiz()" style="margin-top:14px">Submit Answers →</button>
        <div class="quiz-result" id="quiz-result"></div>
      </div>

      <div class="lesson-nav">
        <button class="lesson-nav-btn" onclick="${prevId?`openLesson('${prevId}')`:'void(0)'}" ${!prevId?'disabled':''}>
          ← Previous Topic
        </button>
        <button class="btn btn-ghost btn-sm" onclick="setGrade(${L.grade});nav('modules')">All Topics</button>
        <button class="lesson-nav-btn" onclick="${nextId?`openLesson('${nextId}')`:'void(0)'}" ${!nextId?'disabled':''}>
          Next Topic →
        </button>
      </div>

      <div style="padding-bottom:60px"></div>
    </div>
  `;

  document.getElementById('lesson-content').innerHTML = html;
  nav('lesson');
}

function selectAnswer(qi, oi){
  quizAnswers[qi] = oi;
}

function submitQuiz(){
  const L = LESSONS[currentLessonId];
  if(!L) return;
  const total = L.quiz.length;
  const answered = Object.keys(quizAnswers).length;
  if(answered < total){ toast('⚠️',`Please answer all ${total} questions first`); return; }

  quizSubmitted = true;
  let correct = 0;

  L.quiz.forEach((q,qi)=>{
    const selected = quizAnswers[qi];
    const isCorrect = selected === q.ans;
    if(isCorrect) correct++;

    q.opts.forEach((_,oi)=>{
      const el = document.getElementById(`qopt-${qi}-${oi}`);
      if(!el) return;
      el.classList.add('revealed');
      if(oi === q.ans) el.classList.add('correct');
      else if(oi === selected && !isCorrect) el.classList.add('wrong');
    });
  });

  const pct = Math.round((correct/total)*100);
  const pass = pct >= 60;
  const resultEl = document.getElementById('quiz-result');
  resultEl.className = `quiz-result ${pass?'pass':'fail'}`;
  resultEl.textContent = pass
    ? `✅ Great work! You scored ${correct}/${total} (${pct}%). Well done!`
    : `You scored ${correct}/${total} (${pct}%). Review the lesson content above and try again.`;
  resultEl.style.display = 'block';
  document.getElementById('quiz-submit-btn').style.display = 'none';

  scrollTo({top:document.getElementById('quiz-section').getBoundingClientRect().top+scrollY-80,behavior:'smooth'});
}

/* ══════════════════════════════════════════
   BLOG
   ══════════════════════════════════════════ */
function renderBlogPreview(){
  const g = document.getElementById('blog-preview');
  if(!g) return;
  g.innerHTML = POSTS.slice(0,3).map(p=>`
    <article class="topic-card" style="cursor:pointer" onclick="openLesson('${p.id}')">
      <div class="tc-thumb" style="background:${p.bg}">${p.icon}</div>
      <div class="tc-body">
        <div class="blog-meta"><span class="chip">${p.cat}</span><span style="font-size:.7rem;color:var(--ink3)">${p.read} read</span></div>
        <h3>${p.title}</h3>
        <p>${p.ex.slice(0,100)}…</p>
        <span class="blog-read">Read →</span>
      </div>
    </article>
  `).join('');
}

function renderBlogFull(){
  const g = document.getElementById('blog-main');
  if(!g) return;
  g.innerHTML = POSTS.map(p=>`
    <article class="blc" style="cursor:pointer" onclick="openLesson('${p.id}')">
      <div class="blc-thumb" style="background:${p.bg}">${p.icon}</div>
      <div class="blc-body">
        <div class="blog-meta"><span class="chip">${p.cat}</span><span style="font-size:.7rem;color:var(--ink3)">${p.date}</span><span style="font-size:.7rem;color:var(--ink3)">${p.read} read</span></div>
        <h3>${p.title}</h3>
        <p>${p.ex}</p>
        <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-top:10px">
          <span class="blog-read">Read lesson →</span>
          ${p.ref?`<a href="${p.ref}" target="_blank" rel="noopener noreferrer" onclick="event.stopPropagation()" style="font-size:.74rem;color:var(--ink3);display:inline-flex;align-items:center;gap:3px;transition:color .18s" onmouseover="this.style.color='var(--green)'" onmouseout="this.style.color='var(--ink3)'">↗ ${p.refLabel}</a>`:''}
        </div>
      </div>
    </article>
  `).join('');
  const t = document.getElementById('sw-tags');
  if(t) t.innerHTML = TAGS.map(tag=>`<span class="chip" style="cursor:pointer;margin-bottom:4px">${tag}</span>`).join('');
}

/* ══════════════════════════════════════════
   SEARCH
   ══════════════════════════════════════════ */
function buildSearchIndex(){
  const items = [];
  [...STRANDS_9,...STRANDS_10].forEach(s=>{
    s.topics.filter(t=>t.status==='available'&&t.id).forEach(t=>{
      items.push({id:t.id,title:t.title,meta:`Grade ${s.name==='Crops'&&s.id.includes('9')?9:s.id.includes('9')?9:10} · ${s.strand}: ${s.name}`,icon:t.icon,grade:s.id.includes('10')?10:9});
    });
  });
  return items;
}
const SEARCH_INDEX = buildSearchIndex();

document.getElementById('search-input').addEventListener('input', function(){
  const q = this.value.toLowerCase().trim();
  const results = q.length < 2
    ? SEARCH_INDEX.slice(0,5)
    : SEARCH_INDEX.filter(i=>i.title.toLowerCase().includes(q));
  const el = document.getElementById('s-results');
  if(!results.length){ el.innerHTML='<div style="padding:14px 16px;font-size:.84rem;color:var(--ink3)">No results found.</div>'; return; }
  el.innerHTML = results.map(r=>`
    <a href="/lessons/${r.id}.html" class="sri">
      <div class="sri-ic">${r.icon}</div>
      <div><div class="sri-t">${r.title}</div><div class="sri-m">Grade ${r.grade} · ${r.meta.split('·')[1]||''}</div></div></a>`).join("");
});

// Populate default results
document.getElementById('s-results').innerHTML = SEARCH_INDEX.slice(0,5).map(r=>`
  <a href="/lessons/${r.id}.html" class="sri">
    <div class="sri-ic">${r.icon}</div>
    <div><div class="sri-t">${r.title}</div><div class="sri-m">Grade ${r.grade}</div></div></a>`).join("");

document.getElementById('search-trigger').addEventListener('click',()=>{
  document.getElementById('search-overlay').classList.add('open');
  setTimeout(()=>document.getElementById('search-input').focus(),100);
});
document.getElementById('search-close').addEventListener('click',closeSearch);
document.getElementById('search-overlay').addEventListener('click',e=>{ if(e.target.id==='search-overlay') closeSearch(); });
function closeSearch(){ document.getElementById('search-overlay').classList.remove('open'); }

/* ══════════════════════════════════════════
   MOBILE MENU
   ══════════════════════════════════════════ */
const ham = document.getElementById('hamburger');
const drawer = document.getElementById('mobile-drawer');
ham.addEventListener('click',()=>{
  ham.classList.toggle('open');
  drawer.classList.toggle('open');
  ham.setAttribute('aria-expanded', drawer.classList.contains('open'));
});
function closeDrawer(){ ham.classList.remove('open'); drawer.classList.remove('open'); ham.setAttribute('aria-expanded','false'); }

function filterCareers(strand, btn){
  document.querySelectorAll('#career-filter .cf-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('#career-grid .career-card').forEach(card => {
    card.style.display = (strand === 'all' || card.dataset.strand === strand) ? '' : 'none';
  });
}

/* ══════════════════════════════════════════
   DARK MODE
   ══════════════════════════════════════════ */
let dark=false;
document.getElementById('theme-toggle').addEventListener('click',()=>{
  dark=!dark;
  document.documentElement.setAttribute('data-theme',dark?'dark':'light');
  document.getElementById('t-icon').textContent=dark?'☀️':'🌙';
  document.getElementById('t-lbl').textContent=dark?'Light':'Dark';
});

/* ══════════════════════════════════════════
   LAZY-LOAD ADSENSE (uncomment when approved)
   ══════════════════════════════════════════ */
// window.addEventListener('load', function() {
//   var s = document.createElement('script');
//   s.async = true;
//   s.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7249885633789743';
//   s.crossOrigin = 'anonymous';
//   document.head.appendChild(s);
// });

/* ══════════════════════════════════════════
   SCROLL
   ══════════════════════════════════════════ */
window.addEventListener('scroll',()=>{
  document.getElementById('navbar').classList.toggle('scrolled',scrollY>20);
  document.getElementById('back-top').classList.toggle('visible',scrollY>300);
},{ passive: true });

/* ══════════════════════════════════════════
   MISC
   ══════════════════════════════════════════ */
document.addEventListener('keydown',e=>{ if(e.key==='Escape'){ closeSearch(); closeDrawer(); } });
document.getElementById('announce-close').addEventListener('click',()=>document.getElementById('announce-bar').style.display='none');

function toast(ic,msg){
  document.getElementById('t-ic2').textContent=ic;
  document.getElementById('t-msg2').textContent=msg;
  const t=document.getElementById('toast');
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),3200);
}

async function submitForm(){
  const n=document.getElementById('fn').value;
  const l=document.getElementById('fl').value;
  const e=document.getElementById('fe').value;
  const r=document.getElementById('fg2').value;
  const m=document.getElementById('fm').value;
  if(!n||!e){ toast('⚠️','Please fill in your name and email.'); return; }
  const btn=document.querySelector('#cform .btn-primary');
  btn.textContent='Sending…';btn.disabled=true;
  document.getElementById('cform').style.opacity='.6';
  try{
    const res=await fetch('https://formspree.io/f/mojbeweo',{
      method:'POST',
      headers:{'Accept':'application/json','Content-Type':'application/json'},
      body:JSON.stringify({name:n+' '+l,email:e,role:r,message:m})
    });
    if(res.ok){
      document.getElementById('cform').style.display='none';
      document.getElementById('form-ok').classList.add('show');
      toast('✅','Message sent!');
    } else {
      throw new Error('Server error');
    }
  } catch(err){
    toast('⚠️','Something went wrong. Please try again.');
    btn.textContent='Send Message →';btn.disabled=false;
    document.getElementById('cform').style.opacity='1';
  }
}

function backToTop(){
  try{ window.scrollTo({top:0,behavior:'smooth'}); }
  catch(e){ document.documentElement.scrollTop=0; document.body.scrollTop=0; }
}

/* ══════════════════════════════════════════
   SCROLL REVEAL
   ══════════════════════════════════════════ */
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if(e.isIntersecting){
      e.target.classList.add('revealed');
      revealObserver.unobserve(e.target);
    }
  });
}, { threshold: 0.08, rootMargin: '0px 0px -32px 0px' });

function initReveal(){
  document.querySelectorAll('[data-reveal]').forEach(el => {
    el.classList.remove('revealed');
    revealObserver.observe(el);
  });
  // Also stagger-reveal cards that are immediately visible
  setTimeout(() => {
    document.querySelectorAll('[data-reveal]').forEach(el => {
      const rect = el.getBoundingClientRect();
      if(rect.top < window.innerHeight) el.classList.add('revealed');
    });
  }, 60);
}

// Parallax disabled for performance

/* INIT */

function submitLessonQuiz() {
    const quizSection = document.getElementById('quiz-section');
    if(!quizSection) return;
    const questions = quizSection.querySelectorAll('.quiz-q');
    let correct = 0;
    let total = questions.length;
    let allAnswered = true;

    questions.forEach((q, i) => {
        const selected = q.querySelector('input[type="radio"]:checked');
        if(!selected) { allAnswered = false; return; }
        const ans = parseInt(q.dataset.ans);
        const val = parseInt(selected.value);

        q.querySelectorAll('.qopt').forEach((opt, oi) => {
            opt.classList.add('revealed');
            if(oi === ans) opt.classList.add('correct');
            else if(oi === val && val !== ans) opt.classList.add('wrong');
        });

        if(val === ans) correct++;
    });

    if(!allAnswered) { alert('Please answer all questions first'); return; }

    const pct = Math.round((correct/total)*100);
    const resultEl = document.getElementById('quiz-result');
    if(resultEl) {
        resultEl.className = 'quiz-result ' + (pct >= 60 ? 'pass' : 'fail');
        resultEl.innerHTML = pct >= 60 ? '✅ Great work! You scored ' + correct + '/' + total + ' (' + pct + '%). Well done!' : 'You scored ' + correct + '/' + total + ' (' + pct + '%). Review the content and try again.';
        resultEl.style.display = 'block';
    }
    const submitBtn = document.getElementById('quiz-submit-btn');
    if(submitBtn) submitBtn.style.display = 'none';
}

(function initMPA() {
    const path = window.location.pathname;
    if (path === '/' || path.endsWith('index.html') || path === '') {
        if (typeof renderBlogPreview === 'function') renderBlogPreview();
    } else if (path.includes('topics.html')) {
        const urlParams = new URLSearchParams(window.location.search);
        const grade = parseInt(urlParams.get('grade')) || 9;
        if (typeof filterGrade === 'function') filterGrade(grade);
    } else if (path.includes('resources.html')) {
        if (typeof renderBlogFull === 'function') renderBlogFull();
    }
    if (typeof initReveal === 'function') initReveal();
})();
